package org.siloserver.silo.tv.ui.screens.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import org.siloserver.silo.tv.ui.components.rememberTvDialogInitialFocus
import org.siloserver.silo.tv.ui.components.tvDialogSurface
import org.siloserver.silo.tv.ui.theme.AccentPreset
import org.siloserver.silo.tv.ui.theme.TvAccent
import org.siloserver.silo.tv.ui.theme.TvSelected

/** Picker row id for the "choose your own colour" entry. */
private const val CustomOptionId = TvAccent.CustomId

/** Picker row id for "follow the accent" in the Selected Color picker. */
private const val MatchOptionId = TvSelected.MatchId

private const val CustomLabel = "Custom color…"

/** The accent's name for the Settings row; a custom pick shows its palette name. */
internal fun accentDisplayName(): String =
    if (TvAccent.selectedId == TvAccent.CustomId) TvColorPalette.nameOf(TvAccent.customColor) ?: "Custom" else TvAccent.label

/** The selected colour's name for the Settings row; a custom pick shows its palette name. */
internal fun selectedDisplayName(): String =
    if (TvSelected.selectedId == TvSelected.CustomId) TvColorPalette.nameOf(TvSelected.customColor) ?: "Custom" else TvSelected.label

/**
 * Settings → General → Cards & Posters → Accent Color: the colour list, each
 * with the selected colour that pairs with it, plus a grid behind
 * "Custom color…". Selecting a colour applies it straight away.
 */
@Composable
internal fun TvAccentColorPicker(onDismiss: () -> Unit) {
    var showGrid by remember { mutableStateOf(false) }
    val options = remember(TvAccent.customColor) {
        AccentPreset.entries.map { preset ->
            PickerOption(
                id = preset.id,
                label = preset.label,
                swatch = preset.color,
                pairSwatch = preset.selectedFill,
            )
        } + PickerOption(
            id = CustomOptionId,
            label = CustomLabel,
            swatch = TvAccent.customColor,
        )
    }
    if (showGrid) {
        TvColorGrid(
            currentColor = TvAccent.customColor.takeIf { TvAccent.selectedId == TvAccent.CustomId },
            onSelect = { color ->
                TvAccent.selectCustom(color)
                onDismiss()
            },
            onDismiss = { showGrid = false },
        )
    } else {
        TvSettingsPickerSheet(
            title = "Accent Color",
            options = options,
            selectedId = TvAccent.selectedId,
            onSelect = { id ->
                val preset = AccentPreset.fromId(id)
                if (preset != null) {
                    TvAccent.select(preset)
                    onDismiss()
                } else {
                    showGrid = true
                }
            },
            onDismiss = onDismiss,
        )
    }
}

/**
 * Settings → General → Cards & Posters → Selected Color. It follows the accent
 * unless the viewer picks another colour here.
 */
@Composable
internal fun TvSelectedColorPicker(onDismiss: () -> Unit) {
    var showGrid by remember { mutableStateOf(false) }
    val options = remember(TvSelected.customColor) {
        listOf(PickerOption(id = MatchOptionId, label = "Matches accent")) +
            AccentPreset.entries.map { preset ->
                PickerOption(
                    id = preset.id,
                    label = preset.label,
                    swatch = TvSelected.strokeFor(preset.selectedFill),
                )
            } + PickerOption(
            id = CustomOptionId,
            label = CustomLabel,
            swatch = TvSelected.customColor,
        )
    }
    if (showGrid) {
        TvColorGrid(
            currentColor = TvSelected.customColor.takeIf { TvSelected.selectedId == TvSelected.CustomId },
            onSelect = { color ->
                TvSelected.selectCustom(color)
                onDismiss()
            },
            onDismiss = { showGrid = false },
        )
    } else {
        TvSettingsPickerSheet(
            title = "Selected Color",
            options = options,
            selectedId = TvSelected.selectedId,
            onSelect = { id ->
                val preset = AccentPreset.fromId(id)
                when {
                    id == MatchOptionId -> {
                        TvSelected.matchAccent()
                        onDismiss()
                    }
                    preset != null -> {
                        TvSelected.select(preset)
                        onDismiss()
                    }
                    else -> showGrid = true
                }
            },
            onDismiss = onDismiss,
        )
    }
}

private val PairTileShape = RoundedCornerShape(4.dp)

/** A small tile previewing the selected colour that pairs with a colour option. */
@Composable
internal fun TvPairTile(color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(width = 30.dp, height = 14.dp)
            .background(color, PairTileShape)
            .border(1.dp, Color.White.copy(alpha = 0.30f), PairTileShape),
    )
}

private const val GridColumns = 10
private val SwatchSize = 34.dp
private val GridHeight = SwatchSize * TvColorPalette.Rows + 8.dp * (TvColorPalette.Rows - 1) + 8.dp

@Composable
private fun TvColorGrid(
    currentColor: Color?,
    onSelect: (Color) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    val initialFocus = remember { FocusRequester() }
    val palette = TvColorPalette.colors
    // Start on the colour already in use when it is part of the grid.
    val initialIndex = palette.indexOfFirst { it.color == currentColor }.coerceAtLeast(0)
    var focusedName by remember { mutableStateOf(palette[initialIndex].name) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.88f)),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                modifier = Modifier
                    .width(470.dp)
                    .tvDialogSurface()
                    .padding(horizontal = 18.dp, vertical = 16.dp)
                    .then(rememberTvDialogInitialFocus(initialFocus)),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Custom Color",
                        style = MaterialTheme.typography.displaySmall.copy(fontSize = 21.sp, lineHeight = 25.sp),
                        color = Color.White,
                    )
                    Text(
                        text = focusedName,
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 15.sp, lineHeight = 20.sp),
                        color = Color.White.copy(alpha = 0.60f),
                    )
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(GridColumns),
                    // Rows of SwatchSize plus the gaps and padding; the grid would otherwise fill the screen.
                    modifier = Modifier.height(GridHeight),
                    contentPadding = PaddingValues(4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(palette.size, key = { it }) { index ->
                        val entry = palette[index]
                        ColorSwatch(
                            color = entry.color,
                            selected = entry.color == currentColor,
                            onFocused = { focusedName = entry.name },
                            onClick = { onSelect(entry.color) },
                            modifier = if (index == initialIndex) Modifier.focusRequester(initialFocus) else Modifier,
                        )
                    }
                }
            }
        }
    }
}

/**
 * One grid cell. Focus is a white ring so it reads against any colour,
 * including the accent that is currently applied.
 */
@Composable
private fun ColorSwatch(
    color: Color,
    selected: Boolean,
    onFocused: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    LaunchedEffect(isFocused) { if (isFocused) onFocused() }
    Box(
        modifier = modifier
            .size(SwatchSize)
            .border(
                width = 2.dp,
                color = if (isFocused) Color.White else Color.Transparent,
                shape = CircleShape,
            )
            .padding(4.dp)
            .background(color, CircleShape)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .semantics { contentDescription = if (selected) "Selected color" else "Color" },
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = null,
                tint = if (color.luminance() > 0.5f) Color.Black.copy(alpha = 0.75f) else Color.White,
                modifier = Modifier.size(14.dp),
            )
        }
    }
}

/** A small filled circle showing [color], used before a colour option's label. */
@Composable
internal fun TvColorDot(color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(18.dp)
            .background(color, CircleShape)
            .border(1.dp, Color.White.copy(alpha = 0.30f), CircleShape),
    )
}
