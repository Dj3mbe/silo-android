package org.siloserver.silo.tv.ui.theme

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb

/**
 * The fill and outline that mark the current choice: the open top-bar tab, the
 * chosen season, the highlighted row in a menu. It is deliberately a different
 * hue from the focus accent, so "this is selected" and "the cursor is here"
 * never look alike.
 *
 * By default it follows the accent: every [AccentPreset] carries the
 * [AccentPreset.selectedFill] that pairs with it. The viewer can override it
 * with another preset's fill or a colour of their own.
 *
 * Read it through [SelectedFill] and [SelectedStroke]. It is backed by Compose
 * state, so changing the choice recolours the open screen at once.
 */
object TvSelected {
    /** [selectedId] while the colour follows the accent. */
    const val MatchId = "match"

    /** [selectedId] when the viewer chose their own colour. */
    const val CustomId = "custom"

    private const val PrefsName = "tv_appearance"
    private const val KeySelectedId = "selected_id"
    private const val KeyCustomColor = "selected_custom_argb"

    /** A custom colour is blended into this so white labels stay readable on any pick. */
    private val FillBase = Color(0xFF14161B)

    private var prefs: SharedPreferences? = null

    /** [MatchId], [CustomId], or the id of the [AccentPreset] whose pair is used. */
    var selectedId by mutableStateOf(MatchId)
        private set

    /** The viewer's own colour; used when [selectedId] is [CustomId]. */
    var customColor by mutableStateOf(Color(0xFF4F7CE0))
        private set

    val fill: Color
        get() = when (selectedId) {
            MatchId -> fillFor(TvAccent.selectedId, TvAccent.customColor)
            else -> fillFor(selectedId, customColor)
        }

    val stroke: Color
        get() = strokeFor(fill)

    val label: String
        get() = when (selectedId) {
            MatchId -> "Matches accent"
            CustomId -> "Custom"
            else -> AccentPreset.fromId(selectedId)?.label ?: "Matches accent"
        }

    private fun fillFor(id: String, custom: Color): Color =
        if (id == CustomId) {
            lerp(FillBase, custom, 0.45f)
        } else {
            (AccentPreset.fromId(id) ?: TvAccent.DefaultPreset).selectedFill
        }

    /** The outline: the fill, lightened so it reads against the dark background. */
    fun strokeFor(fill: Color): Color = lerp(fill, Color.White, 0.55f)

    /** Loads the saved choice. Call once from [android.app.Application.onCreate]. */
    fun init(context: Context) {
        val stored = context.getSharedPreferences(PrefsName, Context.MODE_PRIVATE)
        prefs = stored
        if (stored.contains(KeyCustomColor)) {
            customColor = Color(stored.getInt(KeyCustomColor, customColor.toArgb()))
        }
        val savedId = stored.getString(KeySelectedId, null)
        if (savedId == MatchId || savedId == CustomId || AccentPreset.fromId(savedId) != null) {
            selectedId = savedId!!
        }
    }

    fun matchAccent() {
        selectedId = MatchId
        prefs?.edit()?.putString(KeySelectedId, MatchId)?.apply()
    }

    fun select(preset: AccentPreset) {
        selectedId = preset.id
        prefs?.edit()?.putString(KeySelectedId, preset.id)?.apply()
    }

    fun selectCustom(color: Color) {
        customColor = color
        selectedId = CustomId
        prefs?.edit()
            ?.putString(KeySelectedId, CustomId)
            ?.putInt(KeyCustomColor, color.toArgb())
            ?.apply()
    }
}
