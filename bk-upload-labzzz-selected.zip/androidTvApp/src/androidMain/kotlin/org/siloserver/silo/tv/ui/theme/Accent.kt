package org.siloserver.silo.tv.ui.theme

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

/**
 * The colour of focus rings, selection outlines and loading indicators.
 *
 * Read it through [FocusAccent] wherever a highlight is drawn. It is backed by
 * Compose state, so changing the accent recolours the open screen at once.
 */
enum class AccentPreset(val id: String, val label: String, val color: Color) {
    /** Plain white, the stock Silo highlight. */
    Default("default", "Default", SiloOnSurface),
    Gold("gold", "Gold", Color(0xFFDEB565)),
    RoyalPurple("royal_purple", "Royal Purple", Color(0xFF8A4FFF)),
    IceBlue("ice_blue", "Ice Blue", Color(0xFF6EC8FF)),
    Emerald("emerald", "Emerald", Color(0xFF34C784)),
    Crimson("crimson", "Crimson", Color(0xFFEB4052)),
    ;

    companion object {
        fun fromId(id: String?): AccentPreset? = entries.firstOrNull { it.id == id }
    }
}

/**
 * The accent chosen on this TV. Device-local: it is stored in
 * [SharedPreferences] and read once at launch, so the first frame already
 * uses the saved colour.
 */
object TvAccent {
    /** The preset used until the viewer picks another. */
    val DefaultPreset = AccentPreset.Gold

    /** [selectedId] when the viewer chose their own colour. */
    const val CustomId = "custom"

    private const val PrefsName = "tv_appearance"
    private const val KeySelectedId = "accent_id"
    private const val KeyCustomColor = "accent_custom_argb"

    private var prefs: SharedPreferences? = null

    /** Id of the selected [AccentPreset], or [CustomId]. */
    var selectedId by mutableStateOf(DefaultPreset.id)
        private set

    /** The viewer's own colour; shown as the accent when [selectedId] is [CustomId]. */
    var customColor by mutableStateOf(AccentPreset.RoyalPurple.color)
        private set

    val color: Color
        get() = if (selectedId == CustomId) {
            customColor
        } else {
            AccentPreset.fromId(selectedId)?.color ?: DefaultPreset.color
        }

    val label: String
        get() = if (selectedId == CustomId) {
            "Custom"
        } else {
            (AccentPreset.fromId(selectedId) ?: DefaultPreset).label
        }

    /** Loads the saved choice. Call once from [android.app.Application.onCreate]. */
    fun init(context: Context) {
        val stored = context.getSharedPreferences(PrefsName, Context.MODE_PRIVATE)
        prefs = stored
        if (stored.contains(KeyCustomColor)) {
            customColor = Color(stored.getInt(KeyCustomColor, customColor.toArgb()))
        }
        val savedId = stored.getString(KeySelectedId, null)
        if (savedId != null && (savedId == CustomId || AccentPreset.fromId(savedId) != null)) {
            selectedId = savedId
        }
    }

    fun select(preset: AccentPreset) {
        selectedId = preset.id
        prefs?.edit()?.putString(KeySelectedId, preset.id)?.apply()
    }

    fun selectCustom(color: Color) {
        customColor = color
        selectedId = CustomId
        prefs?.edit()
            ?.putString(KeySelectedId, CustomId)
            ?.putInt(KeyCustomColor, color.toArgb())
            ?.apply()
    }
}

/** The current accent, for focus rings and loading indicators. */
val FocusAccent: Color
    get() = TvAccent.color
