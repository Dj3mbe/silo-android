package org.siloserver.silo.tv.ui.screens.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import org.siloserver.silo.tv.ui.components.rememberTvDialogInitialFocus
import org.siloserver.silo.tv.ui.components.tvDialogSurface
import org.siloserver.silo.tv.ui.theme.AccentPreset
import org.siloserver.silo.tv.ui.theme.SelectedPreset
import org.siloserver.silo.tv.ui.theme.TvAccent
import org.siloserver.silo.tv.ui.theme.TvSelected

/** Picker row id for the "choose your own colour" entry; presets use [AccentPreset.id]. */
private const val CustomOptionId = TvAccent.CustomId

/**
 * Settings → General → Accent Color: the preset list, plus a colour grid
 * behind "Custom color…". Selecting a colour applies it straight away.
 */
@Composable
internal fun TvAccentColorPicker(onDismiss: () -> Unit) {
    var showGrid by remember { mutableStateOf(false) }
    val options = remember(TvAccent.customColor) {
        AccentPreset.entries.map { preset ->
            PickerOption(
                id = preset.id,
                label = preset.label,
                detail = if (preset == AccentPreset.Default) "Plain white highlight, as in stock Silo" else null,
                swatch = preset.color,
            )
        } + PickerOption(
            id = CustomOptionId,
            label = "Custom color…",
            swatch = TvAccent.customColor,
        )
    }
    if (showGrid) {
        TvColorGrid(
            currentColor = TvAccent.customColor.takeIf { TvAccent.selectedId == TvAccent.CustomId },
            onSelect = { color ->
                TvAccent.selectCustom(color)
                onDismiss()
            },
            onDismiss = { showGrid = false },
        )
    } else {
        TvSettingsPickerSheet(
            title = "Accent Color",
            options = options,
            selectedId = TvAccent.selectedId,
            onSelect = { id ->
                val preset = AccentPreset.fromId(id)
                if (preset != null) {
                    TvAccent.select(preset)
                    onDismiss()
                } else {
                    showGrid = true
                }
            },
            onDismiss = onDismiss,
        )
    }
}

/**
 * Settings → General → Selected Color: the presets, plus the same colour grid
 * behind "Custom color…". Selecting a colour applies it straight away.
 */
@Composable
internal fun TvSelectedColorPicker(onDismiss: () -> Unit) {
    var showGrid by remember { mutableStateOf(false) }
    val options = remember(TvSelected.customColor) {
        SelectedPreset.entries.map { preset ->
            PickerOption(id = preset.id, label = preset.label, swatch = preset.stroke)
        } + PickerOption(
            id = TvSelected.CustomId,
            label = "Custom color…",
            swatch = TvSelected.customColor,
        )
    }
    if (showGrid) {
        TvColorGrid(
            currentColor = TvSelected.customColor.takeIf { TvSelected.selectedId == TvSelected.CustomId },
            onSelect = { color ->
                TvSelected.selectCustom(color)
                onDismiss()
            },
            onDismiss = { showGrid = false },
        )
    } else {
        TvSettingsPickerSheet(
            title = "Selected Color",
            options = options,
            selectedId = TvSelected.selectedId,
            onSelect = { id ->
                val preset = SelectedPreset.fromId(id)
                if (preset != null) {
                    TvSelected.select(preset)
                    onDismiss()
                } else {
                    showGrid = true
                }
            },
            onDismiss = onDismiss,
        )
    }
}

/** A small filled circle showing [color], used before a colour option's label. */
@Composable
internal fun TvColorDot(color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(18.dp)
            .background(color, CircleShape)
            .border(1.dp, Color.White.copy(alpha = 0.30f), CircleShape),
    )
}

private const val GridColumns = 8
private val SwatchSize = 34.dp
private const val PaletteRows = 5
private val GridHeight = SwatchSize * PaletteRows + 8.dp * (PaletteRows - 1) + 8.dp

/**
 * Hue by tone: eight hues across and five tones down (light, vivid, medium,
 * dark, deep), so the grid covers the range without a numeric picker that is
 * awkward to drive with a remote.
 */
private val CustomPalette: List<Color> = buildList {
    val hues = listOf(350f, 20f, 48f, 120f, 165f, 205f, 255f, 300f)
    val tones = listOf(
        0.35f to 1.00f,
        0.90f to 1.00f,
        0.80f to 0.80f,
        0.90f to 0.55f,
        0.85f to 0.35f,
    )
    for ((saturation, value) in tones) {
        for (hue in hues) add(Color.hsv(hue, saturation, value))
    }
}

@Composable
private fun TvColorGrid(
    currentColor: Color?,
    onSelect: (Color) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    val initialFocus = remember { FocusRequester() }
    // Start on the colour already in use when it is part of the grid.
    val initialIndex = CustomPalette.indexOf(currentColor).coerceAtLeast(0)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.88f)),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                modifier = Modifier
                    .width(380.dp)
                    .tvDialogSurface()
                    .padding(horizontal = 18.dp, vertical = 16.dp)
                    .then(rememberTvDialogInitialFocus(initialFocus)),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    text = "Custom Color",
                    style = MaterialTheme.typography.displaySmall.copy(fontSize = 21.sp, lineHeight = 25.sp),
                    color = Color.White,
                )
                LazyVerticalGrid(
                    columns = GridCells.Fixed(GridColumns),
                    // PaletteRows of SwatchSize plus the gaps and padding; the grid would otherwise fill the screen.
                    modifier = Modifier.height(GridHeight),
                    contentPadding = PaddingValues(4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(CustomPalette.size, key = { it }) { index ->
                        val color = CustomPalette[index]
                        ColorSwatch(
                            color = color,
                            selected = color == currentColor,
                            onClick = { onSelect(color) },
                            modifier = if (index == initialIndex) Modifier.focusRequester(initialFocus) else Modifier,
                        )
                    }
                }
            }
        }
    }
}

/**
 * One grid cell. Focus is a white ring so it reads against any colour,
 * including the accent that is currently applied.
 */
@Composable
private fun ColorSwatch(
    color: Color,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = modifier
            .size(SwatchSize)
            .border(
                width = 2.dp,
                color = if (isFocused) Color.White else Color.Transparent,
                shape = CircleShape,
            )
            .padding(4.dp)
            .background(color, CircleShape)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .semantics { contentDescription = if (selected) "Selected color" else "Color" },
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = null,
                tint = if (color.luminance() > 0.5f) Color.Black.copy(alpha = 0.75f) else Color.White,
                modifier = Modifier.size(14.dp),
            )
        }
    }
}
