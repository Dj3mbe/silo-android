package org.siloserver.silo.tv.ui.theme

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb

/**
 * The fill and outline that mark the current choice: the open top-bar tab, the
 * chosen season, the ticked row in a menu. It is deliberately a different hue
 * from the focus accent, so "this is selected" and "the cursor is here" never
 * look alike.
 *
 * Read it through [SelectedFill] and [SelectedStroke]. It is backed by Compose
 * state, so changing the colour recolours the open screen at once.
 */
enum class SelectedPreset(val id: String, val label: String, val fill: Color, val stroke: Color) {
    SteelBlue("steel_blue", "Steel Blue", Color(0xFF3A4B68), Color(0xFF8DA4C6)),
    DeepSteel("deep_steel", "Deep Steel", Color(0xFF2B3A52), Color(0xFF6F88AA)),
    Slate("slate", "Slate Gray", Color(0xFF454B58), Color(0xFF9AA1B0)),
    Teal("teal", "Teal", Color(0xFF2C5559), Color(0xFF7FC4C0)),
    Violet("violet", "Violet", Color(0xFF473F6B), Color(0xFFA89AD6)),
    Amber("amber", "Amber", Color(0xFF5E4A2A), Color(0xFFD9B26A)),
    ;

    companion object {
        fun fromId(id: String?): SelectedPreset? = entries.firstOrNull { it.id == id }
    }
}

/**
 * The selected-state colour chosen on this TV. Device-local: stored in
 * [SharedPreferences] and read once at launch, like [TvAccent].
 */
object TvSelected {
    /** The preset used until the viewer picks another. */
    val DefaultPreset = SelectedPreset.SteelBlue

    /** [selectedId] when the viewer chose their own colour. */
    const val CustomId = "custom"

    private const val PrefsName = "tv_appearance"
    private const val KeySelectedId = "selected_id"
    private const val KeyCustomColor = "selected_custom_argb"

    /** A custom colour is blended into this so white labels stay readable on any pick. */
    private val FillBase = Color(0xFF14161B)

    private var prefs: SharedPreferences? = null

    /** Id of the selected [SelectedPreset], or [CustomId]. */
    var selectedId by mutableStateOf(DefaultPreset.id)
        private set

    /** The viewer's own colour; used when [selectedId] is [CustomId]. */
    var customColor by mutableStateOf(Color(0xFF4F7CE0))
        private set

    val fill: Color
        get() = if (selectedId == CustomId) {
            lerp(FillBase, customColor, 0.45f)
        } else {
            (SelectedPreset.fromId(selectedId) ?: DefaultPreset).fill
        }

    val stroke: Color
        get() = if (selectedId == CustomId) {
            lerp(customColor, Color.White, 0.25f)
        } else {
            (SelectedPreset.fromId(selectedId) ?: DefaultPreset).stroke
        }

    val label: String
        get() = if (selectedId == CustomId) {
            "Custom"
        } else {
            (SelectedPreset.fromId(selectedId) ?: DefaultPreset).label
        }

    /** Loads the saved choice. Call once from [android.app.Application.onCreate]. */
    fun init(context: Context) {
        val stored = context.getSharedPreferences(PrefsName, Context.MODE_PRIVATE)
        prefs = stored
        if (stored.contains(KeyCustomColor)) {
            customColor = Color(stored.getInt(KeyCustomColor, customColor.toArgb()))
        }
        val savedId = stored.getString(KeySelectedId, null)
        if (savedId != null && (savedId == CustomId || SelectedPreset.fromId(savedId) != null)) {
            selectedId = savedId
        }
    }

    fun select(preset: SelectedPreset) {
        selectedId = preset.id
        prefs?.edit()?.putString(KeySelectedId, preset.id)?.apply()
    }

    fun selectCustom(color: Color) {
        customColor = color
        selectedId = CustomId
        prefs?.edit()
            ?.putString(KeySelectedId, CustomId)
            ?.putInt(KeyCustomColor, color.toArgb())
            ?.apply()
    }
}
