package org.siloserver.silo.tv.ui.screens.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import org.siloserver.silo.tv.ui.components.rememberTvDialogInitialFocus
import org.siloserver.silo.tv.ui.components.tvDialogSurface
import org.siloserver.silo.tv.ui.theme.AccentPreset
import org.siloserver.silo.tv.ui.theme.FocusAccent
import org.siloserver.silo.tv.ui.theme.SelectedFill
import org.siloserver.silo.tv.ui.theme.SelectedPreset
import org.siloserver.silo.tv.ui.theme.SelectedStroke
import org.siloserver.silo.tv.ui.theme.TvAccent
import org.siloserver.silo.tv.ui.theme.TvSelected

/** Which of the two colours the custom grid is choosing. */
private enum class ColorTarget { Accent, Selected }

/** One row in a colour column. */
private data class ColorChoice(val id: String, val label: String, val swatch: Color)

private val AccentChoices: List<ColorChoice>
    get() = AccentPreset.entries.map { ColorChoice(it.id, it.label, it.color) } +
        ColorChoice(TvAccent.CustomId, CustomLabel, TvAccent.customColor)

private val SelectedChoices: List<ColorChoice>
    get() = SelectedPreset.entries.map { ColorChoice(it.id, it.label, it.stroke) } +
        ColorChoice(TvSelected.CustomId, CustomLabel, TvSelected.customColor)

private const val CustomLabel = "Custom color…"

/** The accent's name for the Settings row; a custom pick shows its palette name. */
internal fun accentDisplayName(): String =
    if (TvAccent.selectedId == TvAccent.CustomId) TvColorPalette.nameOf(TvAccent.customColor) ?: "Custom" else TvAccent.label

/** The selected colour's name for the Settings row; a custom pick shows its palette name. */
internal fun selectedDisplayName(): String =
    if (TvSelected.selectedId == TvSelected.CustomId) TvColorPalette.nameOf(TvSelected.customColor) ?: "Custom" else TvSelected.label

/**
 * Settings → General → Cards & Posters → Colors: the accent (focus ring,
 * loading indicators) and the selected colour (the current choice) side by
 * side. A pick applies at once and the window stays open so both can be set;
 * "Custom color…" opens the full palette.
 */
@Composable
internal fun TvColorsDialog(onDismiss: () -> Unit) {
    var customTarget by remember { mutableStateOf<ColorTarget?>(null) }
    val initialFocus = remember { FocusRequester() }

    BackHandler(enabled = customTarget == null, onBack = onDismiss)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.88f)),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                modifier = Modifier
                    .width(640.dp)
                    .tvDialogSurface()
                    .padding(horizontal = 22.dp, vertical = 18.dp)
                    .then(rememberTvDialogInitialFocus(initialFocus)),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    text = "Colors",
                    style = MaterialTheme.typography.displaySmall.copy(fontSize = 21.sp, lineHeight = 25.sp),
                    color = Color.White,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    ColorColumn(
                        title = "ACCENT · focus ring",
                        choices = AccentChoices,
                        selectedId = TvAccent.selectedId,
                        onPick = { id ->
                            val preset = AccentPreset.entries.firstOrNull { it.id == id }
                            if (preset != null) TvAccent.select(preset) else customTarget = ColorTarget.Accent
                        },
                        initialFocus = initialFocus,
                        modifier = Modifier.weight(1f),
                    )
                    ColorColumn(
                        title = "SELECTED · current choice",
                        choices = SelectedChoices,
                        selectedId = TvSelected.selectedId,
                        onPick = { id ->
                            val preset = SelectedPreset.entries.firstOrNull { it.id == id }
                            if (preset != null) TvSelected.select(preset) else customTarget = ColorTarget.Selected
                        },
                        initialFocus = null,
                        modifier = Modifier.weight(1f),
                    )
                }
                ColorPreview()
            }
        }
    }

    customTarget?.let { target ->
        TvColorGrid(
            currentColor = when (target) {
                ColorTarget.Accent -> TvAccent.customColor.takeIf { TvAccent.selectedId == TvAccent.CustomId }
                ColorTarget.Selected -> TvSelected.customColor.takeIf { TvSelected.selectedId == TvSelected.CustomId }
            },
            onSelect = { color ->
                when (target) {
                    ColorTarget.Accent -> TvAccent.selectCustom(color)
                    ColorTarget.Selected -> TvSelected.selectCustom(color)
                }
                customTarget = null
            },
            onDismiss = { customTarget = null },
        )
    }
}

private val ColumnListHeight = 330.dp
private val ChoiceRowShape = RoundedCornerShape(9.dp)

@Composable
private fun ColorColumn(
    title: String,
    choices: List<ColorChoice>,
    selectedId: String,
    onPick: (String) -> Unit,
    initialFocus: FocusRequester?,
    modifier: Modifier = Modifier,
) {
    val initialIndex = choices.indexOfFirst { it.id == selectedId }.coerceAtLeast(0)
    // Start a little above the current colour so it is composed and on screen.
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (initialIndex - 3).coerceAtLeast(0))
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium.copy(fontSize = 13.sp, lineHeight = 16.sp),
            fontWeight = FontWeight.Bold,
            color = Color.White.copy(alpha = 0.55f),
        )
        LazyColumn(
            state = listState,
            modifier = Modifier.height(ColumnListHeight),
            verticalArrangement = Arrangement.spacedBy(2.dp),
            contentPadding = PaddingValues(vertical = 3.dp),
        ) {
            itemsIndexed(choices, key = { _, choice -> choice.id }) { index, choice ->
                ColorChoiceRow(
                    choice = choice,
                    current = choice.id == selectedId,
                    onClick = { onPick(choice.id) },
                    modifier = if (index == initialIndex && initialFocus != null) {
                        Modifier.focusRequester(initialFocus)
                    } else {
                        Modifier
                    },
                )
            }
        }
    }
}

/** One colour: a dot, its name, and a small dot when it is the current pick. */
@Composable
private fun ColorChoiceRow(
    choice: ColorChoice,
    current: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val content = if (isFocused) Color.Black else Color.White
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(ChoiceRowShape)
            .background(if (isFocused) Color.White else Color.Transparent)
            .then(if (isFocused) Modifier.border(2.dp, FocusAccent, ChoiceRowShape) else Modifier)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .semantics { selected = current }
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        TvColorDot(choice.swatch)
        Text(
            text = choice.label,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 17.sp, lineHeight = 21.sp),
            fontWeight = FontWeight.SemiBold,
            color = content,
            modifier = Modifier.weight(1f),
        )
        if (current) {
            Box(modifier = Modifier.size(8.dp).background(content, CircleShape))
        }
    }
}

/** A focused item beside a selected one, in the colours currently chosen. */
@Composable
private fun ColorPreview() {
    val pill = RoundedCornerShape(percent = 50)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color.Black.copy(alpha = 0.35f))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(
            text = "Preview",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 14.sp, lineHeight = 18.sp),
            color = Color.White.copy(alpha = 0.55f),
        )
        Text(
            text = "Focused",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 14.sp, lineHeight = 18.sp),
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier
                .background(Color.White, pill)
                .border(2.dp, FocusAccent, pill)
                .padding(horizontal = 16.dp, vertical = 6.dp),
        )
        Text(
            text = "Selected",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 14.sp, lineHeight = 18.sp),
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier
                .background(SelectedFill, pill)
                .border(1.5.dp, SelectedStroke.copy(alpha = 0.55f), pill)
                .padding(horizontal = 16.dp, vertical = 6.dp),
        )
    }
}

private const val GridColumns = 10
private val SwatchSize = 34.dp
private val GridHeight = SwatchSize * TvColorPalette.Rows + 8.dp * (TvColorPalette.Rows - 1) + 8.dp

@Composable
private fun TvColorGrid(
    currentColor: Color?,
    onSelect: (Color) -> Unit,
    onDismiss: () -> Unit,
) {
    BackHandler(onBack = onDismiss)
    val initialFocus = remember { FocusRequester() }
    val palette = TvColorPalette.colors
    // Start on the colour already in use when it is part of the grid.
    val initialIndex = palette.indexOfFirst { it.color == currentColor }.coerceAtLeast(0)
    var focusedName by remember { mutableStateOf(palette[initialIndex].name) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.88f)),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                modifier = Modifier
                    .width(470.dp)
                    .tvDialogSurface()
                    .padding(horizontal = 18.dp, vertical = 16.dp)
                    .then(rememberTvDialogInitialFocus(initialFocus)),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Custom Color",
                        style = MaterialTheme.typography.displaySmall.copy(fontSize = 21.sp, lineHeight = 25.sp),
                        color = Color.White,
                    )
                    Text(
                        text = focusedName,
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 15.sp, lineHeight = 20.sp),
                        color = Color.White.copy(alpha = 0.60f),
                    )
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(GridColumns),
                    // Rows of SwatchSize plus the gaps and padding; the grid would otherwise fill the screen.
                    modifier = Modifier.height(GridHeight),
                    contentPadding = PaddingValues(4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(palette.size, key = { it }) { index ->
                        val entry = palette[index]
                        ColorSwatch(
                            color = entry.color,
                            selected = entry.color == currentColor,
                            onFocused = { focusedName = entry.name },
                            onClick = { onSelect(entry.color) },
                            modifier = if (index == initialIndex) Modifier.focusRequester(initialFocus) else Modifier,
                        )
                    }
                }
            }
        }
    }
}

/**
 * One grid cell. Focus is a white ring so it reads against any colour,
 * including the accent that is currently applied.
 */
@Composable
private fun ColorSwatch(
    color: Color,
    selected: Boolean,
    onFocused: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    LaunchedEffect(isFocused) { if (isFocused) onFocused() }
    Box(
        modifier = modifier
            .size(SwatchSize)
            .border(
                width = 2.dp,
                color = if (isFocused) Color.White else Color.Transparent,
                shape = CircleShape,
            )
            .padding(4.dp)
            .background(color, CircleShape)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .semantics { contentDescription = if (selected) "Selected color" else "Color" },
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = null,
                tint = if (color.luminance() > 0.5f) Color.Black.copy(alpha = 0.75f) else Color.White,
                modifier = Modifier.size(14.dp),
            )
        }
    }
}

/** A small filled circle showing [color], used before a colour option's label. */
@Composable
internal fun TvColorDot(color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(18.dp)
            .background(color, CircleShape)
            .border(1.dp, Color.White.copy(alpha = 0.30f), CircleShape),
    )
}
