package org.siloserver.silo.tv.ui.screens.settings

import androidx.compose.ui.graphics.Color

/** A named entry in the custom colour grid. */
internal data class NamedColor(val name: String, val color: Color)

/**
 * The custom colour grid: ten hues across and eight tones down, each named
 * "<tone> <hue>" so the name shown while browsing says what the swatch is.
 */
internal object TvColorPalette {
    private val hues = listOf(
        "Red" to 355f,
        "Orange" to 22f,
        "Gold" to 45f,
        "Lime" to 85f,
        "Green" to 135f,
        "Teal" to 175f,
        "Sky" to 200f,
        "Blue" to 225f,
        "Purple" to 270f,
        "Pink" to 320f,
    )

    /** Tone name, saturation, value: from pale to near black. */
    private val tones = listOf(
        Triple("Pastel", 0.30f, 1.00f),
        Triple("Light", 0.55f, 1.00f),
        Triple("Vivid", 0.95f, 1.00f),
        Triple("Medium", 0.85f, 0.80f),
        Triple("Strong", 0.95f, 0.65f),
        Triple("Dark", 0.90f, 0.50f),
        Triple("Deep", 0.85f, 0.38f),
        Triple("Midnight", 0.80f, 0.26f),
    )

    val Rows: Int = tones.size

    val colors: List<NamedColor> = buildList {
        for ((tone, saturation, value) in tones) {
            for ((hue, degrees) in hues) {
                add(NamedColor("$tone $hue", Color.hsv(degrees, saturation, value)))
            }
        }
    }

    fun nameOf(color: Color): String? = colors.firstOrNull { it.color == color }?.name
}
