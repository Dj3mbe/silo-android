package org.siloserver.silo.tv.ui.theme

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb

/**
 * The fill and outline that mark the current choice: the open top-bar tab, the
 * chosen season, the ticked row in a menu. It is deliberately a different hue
 * from the focus accent, so "this is selected" and "the cursor is here" never
 * look alike.
 *
 * Read it through [SelectedFill] and [SelectedStroke]. It is backed by Compose
 * state, so changing the colour recolours the open screen at once.
 */
enum class SelectedPreset(val id: String, val label: String, val fill: Color) {
    Gold("gold", "Gold", Color(0xFF5E4A2A)),
    Orange("orange", "Orange", Color(0xFF6B4021)),
    Red("red", "Red", Color(0xFF5E2530)),
    Pink("pink", "Pink", Color(0xFF63304A)),
    Purple("purple", "Purple", Color(0xFF46346B)),
    Indigo("indigo", "Indigo", Color(0xFF33397A)),
    Blue("blue", "Blue", Color(0xFF3A4B68)),
    Sky("sky", "Sky", Color(0xFF2C5568)),
    Teal("teal", "Teal", Color(0xFF2C5559)),
    Green("green", "Green", Color(0xFF2B5A43)),
    Lime("lime", "Lime", Color(0xFF4A5A25)),
    Graphite("graphite", "Graphite", Color(0xFF454B58)),

    // Deep versions of the streaming-service colours offered for the accent.
    NetflixRed("netflix_red", "Netflix Red", Color(0xFF5C1218)),
    HuluGreen("hulu_green", "Hulu Green", Color(0xFF1E5C3E)),
    PrimeBlue("prime_blue", "Prime Blue", Color(0xFF0F4A66)),
    PlexGold("plex_gold", "Plex Gold", Color(0xFF5E4812)),
    EmbyGreen("emby_green", "Emby Green", Color(0xFF2E5A2B)),
    JellyfinPurple("jellyfin_purple", "Jellyfin Purple", Color(0xFF4F2E63)),
    JellyfinBlue("jellyfin_blue", "Jellyfin Blue", Color(0xFF0F4A63)),
    DisneyBlue("disney_blue", "Disney+ Blue", Color(0xFF14286A)),
    HboPurple("hbo_purple", "HBO Max Purple", Color(0xFF3D3370)),
    ParamountBlue("paramount_blue", "Paramount+ Blue", Color(0xFF12396E)),
    YouTubeRed("youtube_red", "YouTube Red", Color(0xFF6B1212)),
    CrunchyrollOrange("crunchyroll_orange", "Crunchyroll Orange", Color(0xFF6E3A14)),
    ;

    /** The outline: the fill, lightened so it reads against the dark background. */
    val stroke: Color get() = lerp(fill, Color.White, 0.55f)

    companion object {
        fun fromId(id: String?): SelectedPreset? = entries.firstOrNull { it.id == id }
    }
}

/**
 * The selected-state colour chosen on this TV. Device-local: stored in
 * [SharedPreferences] and read once at launch, like [TvAccent].
 */
object TvSelected {
    /** The preset used until the viewer picks another. */
    val DefaultPreset = SelectedPreset.Blue

    /** [selectedId] when the viewer chose their own colour. */
    const val CustomId = "custom"

    private const val PrefsName = "tv_appearance"
    private const val KeySelectedId = "selected_id"
    private const val KeyCustomColor = "selected_custom_argb"

    /** A custom colour is blended into this so white labels stay readable on any pick. */
    private val FillBase = Color(0xFF14161B)

    private var prefs: SharedPreferences? = null

    /** Id of the selected [SelectedPreset], or [CustomId]. */
    var selectedId by mutableStateOf(DefaultPreset.id)
        private set

    /** The viewer's own colour; used when [selectedId] is [CustomId]. */
    var customColor by mutableStateOf(Color(0xFF4F7CE0))
        private set

    val fill: Color
        get() = if (selectedId == CustomId) {
            lerp(FillBase, customColor, 0.45f)
        } else {
            (SelectedPreset.fromId(selectedId) ?: DefaultPreset).fill
        }

    val stroke: Color
        get() = if (selectedId == CustomId) {
            lerp(customColor, Color.White, 0.25f)
        } else {
            (SelectedPreset.fromId(selectedId) ?: DefaultPreset).stroke
        }

    val label: String
        get() = if (selectedId == CustomId) {
            "Custom"
        } else {
            (SelectedPreset.fromId(selectedId) ?: DefaultPreset).label
        }

    /** Loads the saved choice. Call once from [android.app.Application.onCreate]. */
    fun init(context: Context) {
        val stored = context.getSharedPreferences(PrefsName, Context.MODE_PRIVATE)
        prefs = stored
        if (stored.contains(KeyCustomColor)) {
            customColor = Color(stored.getInt(KeyCustomColor, customColor.toArgb()))
        }
        val savedId = stored.getString(KeySelectedId, null)
        if (savedId != null && (savedId == CustomId || SelectedPreset.fromId(savedId) != null)) {
            selectedId = savedId
        }
    }

    fun select(preset: SelectedPreset) {
        selectedId = preset.id
        prefs?.edit()?.putString(KeySelectedId, preset.id)?.apply()
    }

    fun selectCustom(color: Color) {
        customColor = color
        selectedId = CustomId
        prefs?.edit()
            ?.putString(KeySelectedId, CustomId)
            ?.putInt(KeyCustomColor, color.toArgb())
            ?.apply()
    }
}
