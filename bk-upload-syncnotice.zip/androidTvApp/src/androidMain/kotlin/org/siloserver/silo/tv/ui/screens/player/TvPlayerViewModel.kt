@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package org.siloserver.silo.tv.ui.screens.player

import org.siloserver.silo.common.R as CommonR
import org.siloserver.silo.common.diagnostics.DiagnosticsPlaybackLogger
import org.siloserver.silo.common.diagnostics.DiagnosticsSeekEvent
import org.siloserver.silo.common.player.AudioOutputPath
import org.siloserver.silo.common.player.dolbyVisionTransformClassification
import org.siloserver.silo.common.player.failedRendererTrackType
import org.siloserver.silo.common.player.failureDiagnostics
import org.siloserver.silo.common.player.failureClassification
import org.siloserver.silo.tv.BuildConfig
import android.os.SystemClock
import android.util.Log
import org.siloserver.silo.common.player.SubDiag
import org.siloserver.silo.common.player.subtitlesForVideoMediaMount
import org.siloserver.silo.common.player.canSwitchSubtitleInPlace
import org.siloserver.silo.common.player.withInPlaceAdoption
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import org.siloserver.silo.tv.data.preferences.PlaybackQuality
import org.siloserver.silo.common.player.PlaybackAnalyticsListener
import org.siloserver.silo.common.player.PlaybackCapabilityDetector
import org.siloserver.silo.common.player.PlaybackSessionLifecycle
import org.siloserver.silo.common.player.isPlaybackSessionEnded
import org.siloserver.silo.common.player.PlaybackSessionManager
import org.siloserver.silo.common.player.inPlayerQualityPair
import org.siloserver.silo.common.player.PlaybackTeardownGate
import org.siloserver.silo.common.player.video.MountedAudioTrack
import org.siloserver.silo.common.player.video.AudioReconcileAction
import org.siloserver.silo.common.player.video.AudioSelectionWatchdog
import org.siloserver.silo.common.player.video.AUDIO_TRACK_SELECTION_FAILED_CLASSIFICATION
import org.siloserver.silo.common.player.video.DesiredAudio
import org.siloserver.silo.common.player.video.LocalAudioSelection
import org.siloserver.silo.common.player.video.reconcileDesiredAudioAction
import org.siloserver.silo.common.player.video.shouldVerifyOriginalAudioSelection
import org.siloserver.silo.common.player.video.mountedAudioFor
import org.siloserver.silo.playback.resolveAudioTrackOrdinal
import org.siloserver.silo.common.player.FinalPlaybackPosition
import org.siloserver.silo.common.player.FinalPlaybackPositionWriter
import org.siloserver.silo.common.player.VideoSessionStartV3
import org.siloserver.silo.common.player.PlayerNotice
import org.siloserver.silo.common.player.PlayerStatsSnapshot
import org.siloserver.silo.common.player.SessionState
import org.siloserver.silo.common.player.SleepTimerController
import org.siloserver.silo.common.player.SleepTimerState
import org.siloserver.silo.common.player.StartParams
import org.siloserver.silo.common.ui.LanguageNames
import org.siloserver.silo.common.player.MountedSubtitleTrack
import org.siloserver.silo.common.player.resolveMountedSubtitle
import org.siloserver.silo.common.player.backend.VideoBackendCapabilities
import org.siloserver.silo.common.player.reducePlayerStats
import org.siloserver.silo.common.player.seek.PendingSeekPresentationGuard
import org.siloserver.silo.common.player.seek.PlaybackSeekDecision
import org.siloserver.silo.common.player.seek.QuickSkipAccumulator
import org.siloserver.silo.common.player.seek.SeekBoundsMs
import org.siloserver.silo.common.player.seek.SeekPositionDecision
import org.siloserver.silo.common.player.seek.decideSeek
import org.siloserver.silo.common.player.seek.isSameRouteSeekReanchorCandidate
import org.siloserver.silo.common.player.seek.playerPositionForSource
import org.siloserver.silo.common.player.seek.replanMountPositionForSource
import org.siloserver.silo.common.player.seek.sourcePositionForPlayer
import org.siloserver.silo.common.network.ServerReachabilityMonitor
import org.siloserver.silo.common.player.video.MarkerReconciliationFence
import org.siloserver.silo.common.player.video.MarkerSkipTarget
import org.siloserver.silo.common.player.video.VideoPlaybackSessionCoordinator
import org.siloserver.silo.common.player.video.markerSkipTarget
import org.siloserver.silo.common.player.video.VideoPlaybackStartRequest
import org.siloserver.silo.common.player.video.EpisodeAudioIntent
import org.siloserver.silo.common.player.video.EpisodeAudioMode
import org.siloserver.silo.common.player.video.EpisodeSelectionHandoff
import org.siloserver.silo.common.player.video.NextUpTransitionGate
import org.siloserver.silo.common.player.video.EpisodeSubtitleIntent
import org.siloserver.silo.common.player.video.EpisodeSubtitleMode
import org.siloserver.silo.common.player.video.ResolvedEpisodeSelection
import org.siloserver.silo.common.player.video.captureEpisodeSourceIntent
import org.siloserver.silo.common.player.video.captureEpisodeSubtitleIntent
import org.siloserver.silo.common.player.video.resolveAudioSelectionAcrossVersions
import org.siloserver.silo.common.player.normalizedSubtitleCodecFamily
import org.siloserver.silo.common.player.video.VideoPlayerUiState
import org.siloserver.silo.common.player.video.SERVER_TERMINAL_FALLBACK_MESSAGE
import org.siloserver.silo.common.player.video.serverTerminalUserMessage
import org.siloserver.silo.common.player.video.terminalUserMessageRes
import org.siloserver.silo.common.settings.PlayerSettingsStore
import org.siloserver.silo.common.settings.dolbyVisionPolicySnapshot
import org.siloserver.silo.common.player.BufferingQualityPlayerAdapter
import org.siloserver.silo.common.player.awaitNetworkRetry
import org.siloserver.silo.common.player.PlaybackNetworkEvidenceProvider
import org.siloserver.silo.common.player.asPlaybackEventSink
import org.siloserver.silo.domain.player.BufferingQualityController
import org.siloserver.silo.domain.player.BufferingQualityKey
import org.siloserver.silo.domain.player.BufferingQualityPicks
import org.siloserver.silo.domain.player.isViewerChangeTo
import org.siloserver.silo.domain.player.BufferingQualityNotice
import org.siloserver.silo.domain.player.BufferingQualityNoticeSlot
import org.siloserver.silo.domain.player.BufferingQualityPill
import org.siloserver.silo.domain.player.BufferingQualityReplan
import org.siloserver.silo.domain.player.toBufferingQualityPlan
import org.siloserver.silo.model.playback.isCommittedAt
import org.siloserver.silo.model.playback.LEARNED_LIMIT_CLEAR
import org.siloserver.silo.model.playback.PLAYBACK_QUALITY_AUTO
import org.siloserver.silo.domain.player.IntroAutoSkipController
import org.siloserver.silo.domain.player.IntroAutoSkipState
import org.siloserver.silo.domain.player.IntroSkipMode
import org.siloserver.silo.domain.player.settlingFalseEdges
import org.siloserver.silo.model.catalog.AudioTrack
import org.siloserver.silo.model.catalog.FileVersion
import org.siloserver.silo.domain.player.MarkerKind
import org.siloserver.silo.domain.player.MarkerTimeline
import org.siloserver.silo.model.catalog.MarkerSegment
import org.siloserver.silo.model.catalog.TimeRange
import org.siloserver.silo.model.catalog.VersionChapter
import org.siloserver.silo.model.settings.SubtitleAppearance
import org.siloserver.silo.model.playback.AutoSubtitleCandidate
import org.siloserver.silo.model.playback.SUBTITLE_HLS_RENDITION_FAILED_CLASSIFICATION
import org.siloserver.silo.model.playback.SUBTITLE_SELECTION_FAILURE_CLASSIFICATIONS
import org.siloserver.silo.model.playback.executableMedia3ClientTransformations
import org.siloserver.silo.model.playback.AutoSubtitleContext
import org.siloserver.silo.model.playback.inventoryAutoSubtitleCandidates
import org.siloserver.silo.model.playback.resolveAutoSubtitle
import org.siloserver.silo.model.playback.selectedCandidate
import org.siloserver.silo.model.playback.PlaybackDelivery
import org.siloserver.silo.model.playback.PlaybackAvailableQualityV3
import org.siloserver.silo.model.playback.PlaybackEffectiveRecipeV3
import org.siloserver.silo.model.playback.PlaybackSourceDescriptorV3
import org.siloserver.silo.model.playback.ReportedPlaybackQuality
import org.siloserver.silo.model.playback.activePlaybackQualityId
import org.siloserver.silo.model.playback.playbackQualityMenu
import org.siloserver.silo.model.playback.reportedQuality
import org.siloserver.silo.model.playback.PlayMethod
import org.siloserver.silo.model.playback.ClientCodecCapabilities
import org.siloserver.silo.model.playback.ClientPlaybackContext
import org.siloserver.silo.model.playback.PlaybackExecutionPlan
import org.siloserver.silo.model.playback.PlaybackSessionResponse
import org.siloserver.silo.model.playback.PlaybackTimeline
import org.siloserver.silo.model.playback.PlayerSubtitleInfo
import org.siloserver.silo.model.playback.SubtitleIdentity
import org.siloserver.silo.model.playback.SubtitleMediaIdentity
import org.siloserver.silo.model.playback.enrichAuthoritativePlaybackSubtitleChoices
import org.siloserver.silo.model.playback.resolvedSelectedSubtitleIndex
import org.siloserver.silo.model.playback.mergeDownloadedSubtitles
import org.siloserver.silo.model.playback.videoQualityPreference
import org.siloserver.silo.playback.ADMIN_ENDED_PLAYBACK_NOTICE
import org.siloserver.silo.playback.LiveSubtitleTrack
import org.siloserver.silo.playback.PlaybackLiveSubtitleEvent
import org.siloserver.silo.playback.PlaybackMarkersUpdate
import org.siloserver.silo.playback.PlaybackSubtitleReady
import org.siloserver.silo.playback.PlaybackSubtitleTimingChanged
import org.siloserver.silo.playback.PlaybackSubtitleSyncUpdated
import org.siloserver.silo.playback.SubtitleSyncController
import org.siloserver.silo.playback.SubtitleSyncFeedbackTracker
import org.siloserver.silo.playback.SubtitleSyncNotice
import org.siloserver.silo.playback.feedbackInput
import org.siloserver.silo.playback.includesSyncKey
import org.siloserver.silo.playback.activeSyncKey
import org.siloserver.silo.playback.statusLabelFor
import org.siloserver.silo.playback.syncKeyFor
import org.siloserver.silo.playback.timingActionsFor
import org.siloserver.silo.model.subtitles.SubtitleSyncState
import org.siloserver.silo.common.player.subtitleSyncName
import org.siloserver.silo.playback.applyAuthoritativeSubtitleReadyTrack
import org.siloserver.silo.model.subtitles.SubtitleAiQuota
import org.siloserver.silo.model.subtitles.SubtitleAiStatus
import org.siloserver.silo.model.subtitles.SubtitleDownloadRequest
import org.siloserver.silo.model.subtitles.SubtitleResult
import org.siloserver.silo.model.subtitles.SubtitleSearchRequest
import org.siloserver.silo.model.subtitles.SubtitleTranslateRequest
import org.siloserver.silo.network.ApiResult
import org.siloserver.silo.network.errorMessage
import org.siloserver.silo.playback.nextEpisodeAfter
import org.siloserver.silo.playback.canonicalSubtitleLanguage
import org.siloserver.silo.playback.subtitleLabelIndicatesHearingImpaired
import org.siloserver.silo.repository.SubtitlesRepository
import org.siloserver.silo.repository.port.PlaybackWriteScope
import org.siloserver.silo.repository.port.TrackSelectionFingerprintUpdate
import org.siloserver.silo.tv.ui.screens.detail.TvDetailTrackSelectionSession
import org.siloserver.silo.watchtogether.RoomPlayerObservation
import org.siloserver.silo.watchtogether.WatchPartyPlaybackContext
import org.siloserver.silo.watchtogether.shouldNavigateToLocalNext
import kotlin.math.ceil
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.transformLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Always-on tag for subtitle-ownership anomalies.
 *
 * Distinct from SubDiag, which is opt-in tracing: everything logged under this
 * tag means some authority other than the subtitle transaction adapter acted on
 * a text track, which should not be possible and must be visible in a bug
 * report without anyone having set a system property first.
 */
internal const val TV_SUBTITLE_LOG_TAG = "TvSubtitle"

/**
 * How long `isPlaying` must stay false before it counts as a pause rather than
 * a rebuffer, for the intro countdown's purposes.
 *
 * Long enough to cover an ordinary network stall on a TV box, short enough that
 * a viewer who actually pressed pause does not watch the countdown keep running
 * afterwards.
 */
private const val PLAYBACK_PAUSE_GRACE_MS = 1_500L

/** Reduced to the fields that can identify the track across index spaces. */
internal fun PlayerTrackEntry.toMountedAudioTrack(): MountedAudioTrack = MountedAudioTrack(
    ordinal = index,
    language = language,
    codecOrMime = codecOrMime,
    channelCount = channelCount.takeIf { it > 0 },
    label = displayLabel.ifBlank { label },
)

/**
 * The protocol-v3 Quality menu: Auto, then the server's entries in server
 * order, with the row [selectedLabel] resolves to marked selected.
 */
internal fun authoritativePlaybackQualityOptions(
    available: List<PlaybackAvailableQualityV3>,
    selectedLabel: String?,
    delivered: PlaybackEffectiveRecipeV3? = null,
    source: PlaybackSourceDescriptorV3? = null,
    reported: ReportedPlaybackQuality? = null,
): List<VideoQualityOption> {
    val menu = playbackQualityMenu(available)
    val activeId = activePlaybackQualityId(menu, selectedLabel, delivered, source, reported)
    return menu.map { option ->
        VideoQualityOption(
            id = option.id,
            label = option.name,
            isSelected = option.id == activeId,
            resolution = option.height.takeIf { it > 0 }?.let { "${it}p" },
            bitrateLabel = option.bitrateLabel,
        )
    }
}

internal fun clampTvScrubPreview(seconds: Double, duration: Double): Double =
    seconds.coerceAtLeast(0.0).let { value ->
        if (duration > 0.0) value.coerceAtMost(duration) else value
    }

/**
 * Renderable audio or subtitle track pulled out of ExoPlayer's current
 * `Tracks` object. [index] is the ordinal position among groups of the same
 * type and is used as the index argument when calling
 * [org.siloserver.silo.common.player.AudioTrackManager.selectAudioTrack] or
 * [org.siloserver.silo.common.player.SubtitleManager.selectSubtitle].
 * [trackId] retains Media3's stable selector identity; [label] is presentation
 * metadata and [displayLabel] is the polished user-facing string.
 */
data class PlayerTrackEntry(
    val index: Int,
    val label: String,
    val language: String?,
    val isSelected: Boolean,
    val displayLabel: String = label,
    val codecOrMime: String? = null,
    val channelCount: Int = 0,
    val isForced: Boolean = false,
    val isHearingImpaired: Boolean = false,
    val trackId: String? = null,
)

/**
 * The audio the server considers in force, as an ORDINAL into
 * [FileVersion.audioTracks].
 *
 * That ordinal is the server's actual contract for audio. Unlike subtitles,
 * audio tracks carry NO index field on the wire — a probe of the running server
 * returns `{"title":"English DTS 5.1","language":"en","codec":"dts",...}` with
 * no `index`, while a subtitle in the same payload has `"index": 2`. So
 * [AudioTrack.index] deserialises to its `0` default for every audio track and
 * is not an identifier. `effective_audio_track_index` is likewise an ordinal.
 *
 * This previously read `catalogAudioTracks.getOrNull(ordinal)?.index`, which
 * therefore evaluated to 0 for every track: every explicit audio pick asked the
 * server for track 0, so choosing Dutch played English.
 *
 * The plan wins over the mounted Media3 ordinal. The plan carries the server's
 * own selection, while a Media3 group ordinal describes only what THIS stream
 * delivered — after a transcode the stream carries just the chosen track and
 * reports ordinal zero, which is "first delivered group", not "catalog track
 * zero". Preferring it made the next replan ask for track zero and silently
 * reverted the audio to the first language.
 *
 * The Media3 ordinal survives as a fallback when there is no plan identity, and
 * only when it is actually within the catalog's range. It is a guess: it holds
 * just when delivered order matches catalog order.
 */
internal fun selectedServerAudioTrackIndex(
    selectedPlayerOrdinal: Int?,
    catalogAudioTracks: List<AudioTrack>?,
    currentPlanTrackIndex: Int?,
): Int? {
    val catalog = catalogAudioTracks.orEmpty()
    // Validate the plan against the catalog when we have one: a stale
    // plan/catalog pairing would otherwise forward an out-of-range ordinal.
    // With no catalog to check against, the plan is still the best identity.
    currentPlanTrackIndex?.let { plan ->
        if (catalog.isEmpty() || plan in catalog.indices) return plan
    }
    return selectedPlayerOrdinal?.takeIf { it in catalog.indices }
}

private fun SubtitleIdentity.serverTrackIndexForTv(): Int = when (this) {
    SubtitleIdentity.Off -> -1
    is SubtitleIdentity.ServerSidecar -> serverIndex
    is SubtitleIdentity.ServerBurnIn -> serverIndex
    is SubtitleIdentity.Embedded -> serverIndex
    is SubtitleIdentity.Downloaded,
    is SubtitleIdentity.LocalMedia3,
    -> -1
}

private fun SubtitleMediaIdentity.toEpisodeSubtitleIntent(
    external: Boolean?,
): EpisodeSubtitleIntent = EpisodeSubtitleIntent(
    mode = EpisodeSubtitleMode.TRACK,
    language = canonicalSubtitleLanguage(language),
    codecFamily = normalizedSubtitleCodecFamily(codecFamily),
    forced = forced,
    hearingImpaired = hearingImpaired,
    external = external,
)

/**
 * Captures only episode-portable intent. Server, download, and Media3 identities
 * remain local to the current item and therefore cannot cross this boundary.
 */
/**
 * The handoff the next episode gets: what [captured] saw this episode play,
 * except that a choice carried into this episode ([incoming]) is carried on
 * unchanged unless the viewer picked again here. This episode may have
 * played a fallback for it (only plain English where SDH was chosen); the
 * next one re-resolves the original choice on its own tracks.
 *
 * Audio is carried only as the viewer chose it: a pick during this episode
 * ([audioPicked]), else the choice carried in, else Auto — the next episode
 * then follows the series choice. The audio this episode merely played
 * (the series default, a fallback where the chosen language is missing, a
 * track an automatic replan settled on) is never handed on as a choice.
 */
internal fun carryEpisodeIntent(
    captured: EpisodeSelectionHandoff,
    incoming: EpisodeSelectionHandoff?,
    audioPicked: Boolean,
    subtitlePicked: Boolean,
): EpisodeSelectionHandoff {
    val audio = when {
        audioPicked -> captured.audio
        incoming != null && incoming.audio.mode != EpisodeAudioMode.AUTO -> incoming.audio
        else -> org.siloserver.silo.common.player.video.EpisodeAudioIntent.auto()
    }
    incoming ?: return captured.copy(audio = audio)
    return captured.copy(
        audio = audio,
        subtitle = incoming.subtitle
            .takeIf { !subtitlePicked && it.mode != org.siloserver.silo.common.player.video.EpisodeSubtitleMode.AUTO }
            ?: captured.subtitle,
    )
}

internal fun captureTvEpisodeSelectionHandoff(
    activeVersion: FileVersion?,
    committedSubtitleIdentity: SubtitleIdentity,
    catalogSubtitles: List<PlayerSubtitleInfo>,
    hasExplicitSubtitleSelection: Boolean,
    selectedAudioTrack: PlayerTrackEntry? = null,
    selectedCatalogAudio: AudioTrack? = null,
    hasExplicitAudioSelection: Boolean = false,
): EpisodeSelectionHandoff = EpisodeSelectionHandoff(
    source = captureEpisodeSourceIntent(activeVersion),
    // Only an explicit choice travels. Carrying whatever the server happened to
    // default to would pin that default onto every later episode, which looks
    // identical to a preference the viewer never expressed.
    audio = when {
        !hasExplicitAudioSelection -> EpisodeAudioIntent.auto()
        // Prefer the SOURCE row the plan selected. The mounted Media3 track is
        // the delivered representation, so a DTS 5.1 source transcoded to AAC
        // stereo would hand the next episode "UND / AAC / 2ch" as the stated
        // preference — and the resolver weighs title and codec heavily enough
        // to then match the wrong track or give up and take the default.
        selectedCatalogAudio != null -> EpisodeAudioIntent(
            mode = EpisodeAudioMode.TRACK,
            language = selectedCatalogAudio.language,
            codecFamily = selectedCatalogAudio.codec,
            channelCount = selectedCatalogAudio.channels?.takeIf { it > 0 },
            title = selectedCatalogAudio.title,
        )
        // Legacy fallback: no catalog row to resolve against.
        selectedAudioTrack != null -> EpisodeAudioIntent(
            mode = EpisodeAudioMode.TRACK,
            language = selectedAudioTrack.language,
            codecFamily = selectedAudioTrack.codecOrMime,
            channelCount = selectedAudioTrack.channelCount.takeIf { it > 0 },
            // The label is what tells a commentary track from the main mix when
            // language, codec and channel count are identical.
            title = selectedAudioTrack.label,
        )
        else -> EpisodeAudioIntent.auto()
    },
    subtitle = if (!hasExplicitSubtitleSelection) {
        org.siloserver.silo.common.player.video.EpisodeSubtitleIntent.auto()
    } else {
        when (committedSubtitleIdentity) {
            SubtitleIdentity.Off -> captureEpisodeSubtitleIntent(-1, catalogSubtitles)
            is SubtitleIdentity.ServerSidecar,
            is SubtitleIdentity.ServerBurnIn,
            is SubtitleIdentity.Embedded,
            -> captureEpisodeSubtitleIntent(
                committedSubtitleIdentity.serverTrackIndexForTv(),
                catalogSubtitles,
            )
            is SubtitleIdentity.Downloaded -> committedSubtitleIdentity.media
                .toEpisodeSubtitleIntent(external = true)
            is SubtitleIdentity.LocalMedia3 -> committedSubtitleIdentity.media
                .toEpisodeSubtitleIntent(external = null)
        }
    },
)

internal class TvEpisodeSelectionHandoffLease internal constructor(
    val ownerGeneration: Long,
    val sequence: Long,
    val handoff: EpisodeSelectionHandoff,
)

/** Recoverable-start lease; only the current owner can retain or acknowledge it. */
internal class TvEpisodeSelectionHandoffSlot(
    handoff: EpisodeSelectionHandoff?,
) {
    private var pending = handoff
    private var currentLease: TvEpisodeSelectionHandoffLease? = null
    private var sequence = 0L

    @Synchronized
    fun leaseForStart(ownerGeneration: Long): TvEpisodeSelectionHandoffLease? {
        val handoff = pending ?: return null
        currentLease?.let { lease ->
            if (lease.ownerGeneration == ownerGeneration) return lease
            // A newer launch owner supersedes this transition rather than
            // inheriting an older in-flight selection intent.
            invalidate()
            return null
        }
        return TvEpisodeSelectionHandoffLease(
            ownerGeneration = ownerGeneration,
            sequence = ++sequence,
            handoff = handoff,
        ).also { currentLease = it }
    }

    @Synchronized
    fun retainForRetry(lease: TvEpisodeSelectionHandoffLease?): Boolean {
        if (lease == null || currentLease != lease) return false
        currentLease = null
        return true
    }

    @Synchronized
    fun acknowledgeReady(lease: TvEpisodeSelectionHandoffLease?): Boolean {
        if (lease == null || currentLease != lease) return false
        currentLease = null
        pending = null
        return true
    }

    @Synchronized
    fun replace(handoff: EpisodeSelectionHandoff) {
        currentLease = null
        pending = handoff
    }

    @Synchronized
    fun invalidate() {
        currentLease = null
        pending = null
    }
}

internal data class TvEpisodeInitialSubtitleSelection(
    val pendingInitialSubtitleIndex: Int?,
    val suppressDurableSubtitleRestore: Boolean,
)

/** Applies a target-only resolution without changing ordinary/manual starts. */
internal fun resolveTvEpisodeInitialSubtitleSelection(
    episodeSelectionHandoff: EpisodeSelectionHandoff?,
    resolvedEpisodeSelection: ResolvedEpisodeSelection?,
    existingPendingInitialSubtitleIndex: Int?,
): TvEpisodeInitialSubtitleSelection {
    if (episodeSelectionHandoff == null || resolvedEpisodeSelection == null) {
        return TvEpisodeInitialSubtitleSelection(
            pendingInitialSubtitleIndex = existingPendingInitialSubtitleIndex,
            suppressDurableSubtitleRestore = false,
        )
    }
    return TvEpisodeInitialSubtitleSelection(
        pendingInitialSubtitleIndex = resolvedEpisodeSelection.subtitleTrackIndex,
        suppressDurableSubtitleRestore = resolvedEpisodeSelection.subtitleIntentSpecified,
    )
}

private fun PlayerTrackEntry.isEffectivelyHearingImpaired(): Boolean =
    isHearingImpaired ||
        subtitleLabelIndicatesHearingImpaired(label) ||
        subtitleLabelIndicatesHearingImpaired(displayLabel)

internal fun subtitleTracksWithSelection(
    tracks: List<PlayerTrackEntry>,
    selectedIndex: Int,
): List<PlayerTrackEntry> =
    tracks.map { track ->
        track.copy(isSelected = selectedIndex >= 0 && track.index == selectedIndex)
    }

/**
 * The identity Auto resolves to for a launch that carried NO decision (deep
 * link, cast, remote/realtime start).
 *
 * Resolved over the SERVER inventory whenever there is one: `subtitle_urls`
 * lists external sidecars the initial plan did not mount, and Media3's mounted
 * text tracks do not. Ranking only what was mounted is what made an external
 * SRT structurally invisible and started the embedded PGS track instead. If the
 * winner is not mounted yet the adapter mounts it — a replan that is legitimate
 * precisely because nobody decided this launch.
 *
 * A null resolution maps to an explicit Off: Auto picked nothing, but a
 * selector or device caption setting may still have a track on, and Apple's
 * engines start subs OFF ("Auto - None" in the detail preview).
 */
internal fun resolveTvAutoSubtitleIdentity(
    audioTracks: List<PlayerTrackEntry>,
    subtitleTracks: List<PlayerTrackEntry>,
    subtitleRows: List<PlayerSubtitleInfo>,
    preferredLanguage: String?,
    subtitleMode: String?,
    showForced: Boolean,
    trackSignature: org.siloserver.silo.model.playback.SubtitleTrackSignature? = null,
    /**
     * Language of the audio this playback is set to play (the planned or
     * chosen track). Media3's first snapshot still shows the file's default
     * track selected before the switch lands, so reading the selection alone
     * judged English audio as the German default and turned on full English
     * subtitles where only the forced track belonged. Falls back to the
     * mounted selection when unknown.
     */
    intendedAudioLanguage: String? = null,
): SubtitleIdentity {
    val context = AutoSubtitleContext(
        preferredLanguage = preferredLanguage,
        mode = subtitleMode,
        showForced = showForced,
        audioLanguage = intendedAudioLanguage?.takeIf { it.isNotBlank() }
            ?: audioTracks.firstOrNull { it.isSelected }?.language,
        trackSignature = trackSignature,
    )
    if (subtitleRows.isNotEmpty()) {
        val winner = resolveAutoSubtitle(
            candidates = inventoryAutoSubtitleCandidates(subtitleRows),
            context = context,
        ).selectedCandidate() ?: return SubtitleIdentity.Off
        return subtitleRows.firstOrNull { it.index == winner.selectionIndex }
            ?.let(::tvSubtitleIdentity)
            ?: SubtitleIdentity.Off
    }
    // No server inventory (a purely local mount): the mounted tracks are then
    // the whole truth anyway.
    val winner = resolveAutoSubtitle(
        candidates = playerTrackAutoSubtitleCandidates(subtitleTracks),
        context = context,
    ).selectedCandidate() ?: return SubtitleIdentity.Off
    return subtitleTracks.firstOrNull { it.index == winner.selectionIndex }
        ?.let { track -> tvMountedSubtitleIdentity(track, subtitleTracks, subtitleRows) }
        ?: SubtitleIdentity.Off
}

/**
 * Mounted text tracks as resolver candidates, keyed by Media3 track index.
 *
 * Hearing-impaired travels as an explicit signal (role flags and both labels),
 * which the catalog cannot supply and the shared predicate ORs with the title.
 * Nothing here needs a burn-in: every track is already in the player, Media3
 * decodes the bitmap families itself, and with no server inventory there is
 * no burn-in route anyway. Media3 does not say where a track came from, so
 * source stays unknown and ties keep the mounted order.
 */
internal fun playerTrackAutoSubtitleCandidates(
    subtitleTracks: List<PlayerTrackEntry>,
): List<AutoSubtitleCandidate> = subtitleTracks.map { track ->
    AutoSubtitleCandidate(
        selectionIndex = track.index,
        language = track.language,
        codec = track.codecOrMime,
        forced = track.isForced,
        hearingImpaired = track.isEffectivelyHearingImpaired(),
        needsBurnIn = false,
    )
}

internal fun resolveInitialSubtitleTrackIndex(
    requestedOrdinal: Int,
    subtitleTracks: List<PlayerTrackEntry>,
    mountedSubtitles: List<PlayerSubtitleInfo>,
): Int? {
    // Key on the STABLE server subtitle index (PlayerSubtitleInfo.index) first,
    // by identity not list position: a server index gap (a burned/skipped track)
    // or a downloaded tail entry shifts list positions, so a positional hit would
    // shadow the correct index-field match and select the wrong subtitle. Only
    // fall back to positional lookup when nothing carries the requested index.
    val requested = mountedSubtitles.firstOrNull { it.index == requestedOrdinal }
        ?: mountedSubtitles.getOrNull(requestedOrdinal)
        ?: return null

    return resolveMountedSubtitleTrack(requested, subtitleTracks)?.index
}

internal fun resolveMountedSubtitleTrack(
    subtitle: PlayerSubtitleInfo,
    subtitleTracks: List<PlayerTrackEntry>,
): PlayerTrackEntry? {
    val match = resolveMountedSubtitle(
        subtitle,
        subtitleTracks.map(PlayerTrackEntry::toMountedSubtitleTrack),
    ) ?: return null
    return subtitleTracks.firstOrNull { it.index == match.track.index }
}

internal fun resolveMountedSubtitleRow(
    track: PlayerTrackEntry,
    subtitleTracks: List<PlayerTrackEntry>,
    mountedSubtitles: List<PlayerSubtitleInfo>,
): PlayerSubtitleInfo? =
    mountedSubtitles
        .filter { resolveMountedSubtitleTrack(it, subtitleTracks)?.index == track.index }
        .singleOrNull()

internal fun resolvedMountedSubtitleTrackIndexes(
    subtitleTracks: List<PlayerTrackEntry>,
    mountedSubtitles: List<PlayerSubtitleInfo>,
): Set<Int> =
    mountedSubtitles
        .mapNotNull { resolveMountedSubtitleTrack(it, subtitleTracks)?.index }
        .toSet()

private fun PlayerTrackEntry.toMountedSubtitleTrack(): MountedSubtitleTrack =
    MountedSubtitleTrack(
        index = index,
        trackId = trackId,
        label = label,
        language = language,
        codec = codecOrMime,
        forced = isForced,
        hearingImpaired = isHearingImpaired,
    )

/**
 * How the video surface scales to fill the player area. Session-scoped
 * (resets to [Fit] on each new playback) — matches tvOS behavior.
 */
enum class VideoFillMode {
    /** Letterbox: preserve aspect ratio, may show bars. Default. */
    Fit,
    /** Zoom: preserve aspect ratio, fill screen, may crop edges. */
    Zoom,
    /** Stretch: fill screen ignoring aspect ratio (matches phone "Stretch"). */
    Stretch,
}

/** The in-player notice for an AI subtitle job that failed out of sight. */
internal fun aiFailureNotice(message: String): String = TvPlayerErrors.AI_SUBTITLES_FAILED_PREFIX + message

/**
 * English of the errors and notices this player writes itself (this view
 * model and [TvVideoPlaybackStarter]). State keeps the English, which the
 * logs, the adb debug hook and source tests read; [res] and [prefixed] map it
 * to the catalog when the screen shows it (see `tvPlayerMessageText`). Text
 * from the server or the shared module has no entry and shows as it is.
 */
/** A catalog string for one exact [message] held in [TvPlayerViewModel.UiState.error]. */
data class TvPlayerErrorRes(val message: String, @StringRes val res: Int)

internal object TvPlayerErrors {
    const val SERVER_UNREACHABLE = "Can't reach server — check your connection."
    const val PLAYBACK_FAILED = "Playback failed. Please try again."
    const val SEEK_FAILED = "Couldn't seek. Please try again."
    const val RECOVERY_UNSUPPORTED = "This Silo server must be updated to support playback recovery."
    const val STOPPED_RESPONDING = "Playback stopped responding. Press Back and try again."
    const val SEEK_UNSUPPORTED = "This Silo server does not support reliable seeking."
    const val SEEK_CHANGED_VERSION = "Seek recovery tried to change the selected media version."

    // Written as literals at their `fail(...)` calls, which source tests pin.
    const val NO_SESSION = "Playback start returned no session."
    const val PUBLICATION_UNCONFIRMED = "Playback publication could not be confirmed."

    // TvVideoPlaybackStarter.
    const val METADATA_NEEDS_PROFILE = "Playback metadata needs an authenticated profile."
    const val NO_VERSIONS = "No playable versions available"
    const val WATCH_PARTY_VERSION_UNAVAILABLE = "The Watch Party's version of this title isn't available to this profile."
    const val NO_PROFILE = "No active profile selected"
    const val NOT_AUTHENTICATED = "Not authenticated"
    const val VIEWER_CHANGED_BEFORE_ADMISSION = "The metadata viewer changed before playback admission."
    const val SERVER_UPGRADE_MEDIA3 = "This Silo server must be updated to support the Media3 playback protocol."
    const val VIEWER_CHANGED_AFTER_ADMISSION = "The metadata viewer changed after playback admission."
    const val WATCH_PARTY_VERSION_MISMATCH = "The server offered a different version than the Watch Party's."
    const val SUPERSEDED = "Playback start was superseded."
    const val VIEWER_CHANGED_DURING_ADOPTION = "The metadata viewer changed during playback adoption."
    const val LOAD_FAILED_PREFIX = "Failed to load content: "
    const val NETWORK_PREFIX = "Network error: "
    const val START_FAILED_PREFIX = "Failed to start playback: "
    const val UNEXPECTED_PREFIX = "Unexpected error: "

    // Notices (the remote-message toast).
    const val AI_SUBTITLES_FAILED_PREFIX = "AI subtitles failed. "

    // Subtitle search and AI subtitle state, shown by the subtitle dialogs.
    const val SUBTITLE_SEARCH_FAILED = "Subtitle search failed"
    const val SUBTITLE_DOWNLOAD_FAILED = "Subtitle download failed"
    const val SUBTITLE_DOWNLOADED_NOT_REFRESHED = "Downloaded, but the subtitle list could not be refreshed."
    const val SUBTITLE_SIGN_IN_REQUIRED = "Sign in before starting subtitle processing."
    const val TRANSLATION_FAILED = "Translation failed"
    const val TRANSLATED_NOT_REFRESHED = "Translated, but the subtitle list could not be refreshed."
    const val PROCESSING_IN_BACKGROUND = "Processing in background"

    @StringRes
    fun res(english: String): Int? = when (english) {
        SERVER_UNREACHABLE -> CommonR.string.player_error_serverUnreachable
        PLAYBACK_FAILED -> CommonR.string.player_error_playbackFailed
        SEEK_FAILED -> CommonR.string.player_error_seekFailed
        RECOVERY_UNSUPPORTED -> CommonR.string.player_error_recoveryUnsupported
        STOPPED_RESPONDING -> CommonR.string.player_error_stoppedResponding
        SEEK_UNSUPPORTED -> CommonR.string.player_error_seekUnsupported
        SEEK_CHANGED_VERSION -> CommonR.string.player_error_seekChangedVersion
        NO_SESSION -> CommonR.string.player_error_noSession
        PUBLICATION_UNCONFIRMED -> CommonR.string.player_error_publicationUnconfirmed
        METADATA_NEEDS_PROFILE -> CommonR.string.player_error_metadataNeedsProfile
        NO_VERSIONS -> CommonR.string.player_error_noVersions
        WATCH_PARTY_VERSION_UNAVAILABLE -> CommonR.string.player_watchParty_versionUnavailable
        NO_PROFILE -> CommonR.string.player_error_noProfile
        NOT_AUTHENTICATED -> CommonR.string.player_error_notAuthenticated
        VIEWER_CHANGED_BEFORE_ADMISSION -> CommonR.string.player_error_viewerChangedBeforeAdmission
        SERVER_UPGRADE_MEDIA3 -> CommonR.string.player_error_serverUpgradeMedia3
        VIEWER_CHANGED_AFTER_ADMISSION -> CommonR.string.player_error_viewerChangedAfterAdmission
        WATCH_PARTY_VERSION_MISMATCH -> CommonR.string.player_watchParty_versionMismatch
        SUPERSEDED -> CommonR.string.player_error_superseded
        VIEWER_CHANGED_DURING_ADOPTION -> CommonR.string.player_error_viewerChangedDuringAdoption
        TvPlayerViewModel.SHUFFLE_CONTINUE_FAILED -> CommonR.string.upNext_shuffleContinueFailed
        TvPlayerViewModel.SHUFFLE_PICK_FAILED -> CommonR.string.upNext_pickAnotherFailed
        TV_WATCH_PARTY_LAUNCH_REFUSAL -> CommonR.string.player_watchParty_launchRefusal
        SUBTITLE_SEARCH_FAILED -> CommonR.string.player_subtitleTools_searchFailed
        SUBTITLE_DOWNLOAD_FAILED -> CommonR.string.player_subtitleTools_downloadFailed
        SUBTITLE_DOWNLOADED_NOT_REFRESHED -> CommonR.string.player_subtitleTools_downloadedNotRefreshed
        SUBTITLE_SIGN_IN_REQUIRED -> CommonR.string.player_subtitleTools_signInRequired
        TRANSLATION_FAILED -> CommonR.string.player_subtitleTools_translationFailed
        TRANSLATED_NOT_REFRESHED -> CommonR.string.player_subtitleTools_translatedNotRefreshed
        PROCESSING_IN_BACKGROUND -> CommonR.string.player_subtitleTools_processingInBackground
        // The shared terminal fallback, for paths that keep only the English (a replacement-load toast).
        SERVER_TERMINAL_FALLBACK_MESSAGE -> CommonR.string.player_error_playbackUnavailable
        else -> null
    }

    /** A message built as a fixed prefix and a detail: the catalog id for it and the detail. */
    fun prefixed(english: String): Pair<Int, String>? {
        val prefix = PREFIXES.keys.firstOrNull { english.startsWith(it) } ?: return null
        return PREFIXES.getValue(prefix) to english.removePrefix(prefix)
    }

    private val PREFIXES = mapOf(
        LOAD_FAILED_PREFIX to CommonR.string.player_error_loadFailed,
        NETWORK_PREFIX to CommonR.string.player_error_network,
        START_FAILED_PREFIX to CommonR.string.player_error_startFailed,
        UNEXPECTED_PREFIX to CommonR.string.player_error_unexpected,
        AI_SUBTITLES_FAILED_PREFIX to CommonR.string.player_notice_aiSubtitlesFailed,
    )
}

/** A transient remote "display_message"; [id] makes repeats re-trigger the toast. */
data class RemoteMessage(
    val id: Long,
    val text: String,
    val durationMs: Long = 5_000L,
    /** When set, the toast shows this catalog string; [text] keeps the English. */
    @StringRes val textRes: Int? = null,
)

/** The resolved next episode for auto-advance / "Up next". */
data class NextEpisodeState(
    val contentId: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val title: String?,
    val stillUrl: String?,
    /** Whether [stillUrl] is the episode's own still (null when the server doesn't say). */
    val stillIsEpisodeStill: Boolean? = null,
    val overview: String? = null,
    val seriesTitle: String? = null,
    val runtimeMinutes: Int = 0,
    /** Not started by this profile; spoiler protection may hide [overview]. */
    val isUnwatched: Boolean = true,
    /** False for a shuffled movie, which has no season or episode line. */
    val isEpisode: Boolean = true,
)

/**
 * Set while a shuffle plays: the Up Next overlay announces the server's random
 * pick from the scope [scopeLabel] names, and no sequential next episode is
 * offered.
 */
data class TvShuffleUiState(
    /** Null until the shuffle has been read. */
    val scopeLabel: String? = null,
    val pickingAnother: Boolean = false,
    /** A transient failure to continue or pick another. */
    val message: String? = null,
)

data class TvPlayerLaunchArgs(
    val contentId: String,
    val libraryId: Int? = null,
    val preferredFileId: Int? = null,
    /** The viewer picked [preferredFileId]'s version: the start pins it. */
    val versionChosen: Boolean = false,
    val preferredQuality: String? = null,
    val roomId: String? = null,
    val resumePositionOverride: Double? = null,
    /** Pre-selected audio track index from the detail screen (null = auto). */
    val initialAudioTrackIndex: Int? = null,
    /** True when the launch ordinal is a pick made this session, not a restore. */
    val initialAudioPickedThisSession: Boolean = false,
    /** Pre-selected subtitle track index (null = no handoff, -1 = Off). */
    val initialSubtitleTrackIndex: Int? = null,
    /**
     * True when [initialSubtitleTrackIndex] is the detail row's Auto preview
     * rather than the viewer's own pick. The player still starts on it — that
     * is the whole point of the handoff — but must not record it as a manual
     * selection (no durable persistence, no explicit episode intent).
     */
    val initialSubtitleAutoResolved: Boolean = false,
    /**
     * How many consecutive auto-advances led to this playback (0 = a manual
     * start). The player re-mounts per episode, so the pass-out streak rides
     * the route instead of living in the VM. When it reaches the pass-out
     * threshold setting, the next credits-reached shows "Still watching?"
     * instead of auto-advancing.
     */
    val autoAdvanceCount: Int = 0,
    val episodeSelectionHandoff: EpisodeSelectionHandoff? = null,
    /** The running shuffle this item is a pick of; picks play from the beginning. */
    val shuffleId: String? = null,
)

/**
 * Subtitle provider search/download state backing the TV subtitle search
 * dialog. `completedNonce` increments when a download lands and the track
 * list has been refreshed — the dialog observes it and dismisses itself.
 */
data class SubtitleSearchUiState(
    val language: String = "en",
    val isSearching: Boolean = false,
    val hasSearched: Boolean = false,
    val results: List<SubtitleResult> = emptyList(),
    /** Provider warnings from the search response (e.g. a provider was skipped). */
    val warnings: List<String> = emptyList(),
    val error: String? = null,
    /** [SubtitleResult.id] currently downloading (inline row spinner), or null. */
    val downloadingResultId: String? = null,
    val completedNonce: Int = 0,
)

/** Lifecycle of the in-dialog AI job for the TV AI translate dialog. */
sealed interface AiJobPhase {
    data object Idle : AiJobPhase
    data object Submitting : AiJobPhase
    data class Running(val progress: Double, val message: String?) : AiJobPhase
    data class Failed(val message: String) : AiJobPhase
}

/**
 * AI translate/transcribe state. `status` defaults to both-flags-false so the
 * HUD row stays hidden until the lazy probe succeeds (matching the web: a
 * failed probe also leaves both flags false and surfaces no error).
 */
data class AiTranslateUiState(
    val statusLoaded: Boolean = false,
    val status: SubtitleAiStatus = SubtitleAiStatus(enabled = false, transcribeEnabled = false),
    val quota: SubtitleAiQuota? = null,
    val phase: AiJobPhase = AiJobPhase.Idle,
    val completedNonce: Int = 0,
)

/**
 * TV player ViewModel. Phase E adds state for track selection menus, skip
 * buttons, and a 5-second auto-hide timer for the Compose overlay.
 *
 * Phase 3 TV uplift mirrors the phone PlayerViewModel: injects
 * [PlayerSettingsStore], [IntroAutoSkipController], [PlaybackSessionLifecycle],
 * and [SleepTimerController]. The lifecycle owns progress reporting, recovery,
 * final progress flushing, and session stop. Intro auto-skip and player notices
 * are exposed as separate flows for the screen to consume.
 *
 * Playback itself still goes through [org.siloserver.silo.common.player.SiloPlayerFactory] +
 * [PlaybackSessionManager]. The ViewModel receives track info from the
 * screen (via [onTracksChanged]) because ExoPlayer is owned by the
 * composable.
 */
class TvPlayerViewModel(
    private val videoPlaybackCoordinator: VideoPlaybackSessionCoordinator,
    private val playbackSessionManager: PlaybackSessionManager,
    private val playbackAnalytics: PlaybackAnalyticsListener,
    private val capabilityDetector: PlaybackCapabilityDetector,
    // Phase 3 TV uplift dependencies.
    private val playerSettingsStore: PlayerSettingsStore,
    private val introAutoSkipController: IntroAutoSkipController,
    private val sessionLifecycle: PlaybackSessionLifecycle,
    private val sleepTimer: SleepTimerController,
    // Subtitle suite (provider search/download + AI translate).
    private val subtitlesRepository: SubtitlesRepository,
    // Track B: durable offline-safe position (resume + outbox sync).
    private val userItemStatePort: org.siloserver.silo.repository.port.UserItemStatePort,
    private val finalPlaybackPositionWriter: FinalPlaybackPositionWriter,
    // Next-episode resolution for auto-advance (F2).
    private val catalogRepository: org.siloserver.silo.repository.CatalogRepository,
    // Pre-play reachability gate (issue #33): drives Retry's fresh probe.
    private val serverReachabilityMonitor: ServerReachabilityMonitor,
    private val launchArgs: TvPlayerLaunchArgs,
    // Shuffle: the server picks what plays next. Optional so tests that
    // construct the VM directly stay source-compatible.
    private val shuffleFeatureStore: org.siloserver.silo.model.feature.ShuffleFeatureStore? = null,
    // Home sections feeding the Up Next overlay's On Deck row. Optional so
    // tests that construct the VM directly stay source-compatible.
    private val sectionRepository: org.siloserver.silo.repository.SectionRepository? = null,
    // Network availability for the buffering-quality adapter: a wait while
    // the device is offline is an outage, not a stall. Optional for tests
    // that construct the VM directly; null reads as always connected.
    private val networkEvidence: PlaybackNetworkEvidenceProvider? = null,
    // When the video's requests last received a byte, so the buffering-quality
    // adapter can tell a dead link from a slow one. Optional for the same reason.
    private val throughputMeter: org.siloserver.silo.common.player.PlaybackThroughputMeter? = null,
    /** Remembers a manual subtitle choice for the whole series on the server. */
    private val seriesTrackChoiceWriter: org.siloserver.silo.common.settings.SeriesTrackChoiceWriter? = null,
    /** The server's seek-bar previews. Optional for the same reason. */
    trickplayManifests: org.siloserver.silo.playback.trickplay.TrickplayManifestSource? = null,
    /** Stamps the series return with the identity generation it was recorded under. */
    private val identityTransitions: org.siloserver.silo.network.IdentityTransitionBarrier? = null,
) : ViewModel() {

    companion object {
        private const val TAG = "TvPlayerViewModel"
        private const val LIVE_SUBTITLE_COMPLETED_GRACE_MS = 15_000L
        private const val AI_SUBTITLE_READY_FALLBACK_MS = 5_000L
        const val SERVER_UNREACHABLE_MESSAGE = TvPlayerErrors.SERVER_UNREACHABLE
        // A transient network blip retries the same route this many times before
        // demoting to a server transcode (resets once playback progresses).
        private const val MAX_TRANSIENT_NETWORK_RETRIES = 1
        // How long an outage's check that the server answers again may take.
        private const val SERVER_CHECK_TIMEOUT_MS = 10_000L
        // Error screens say what happened in plain words; the request URL and
        // the library's exception text go to the log only.
        private const val PLAYBACK_FAILED_MESSAGE = TvPlayerErrors.PLAYBACK_FAILED
        private const val SEEK_FAILED_MESSAGE = TvPlayerErrors.SEEK_FAILED
        private const val SEEK_SETTLE_DEADLINE_MS = 15_000L
        /** How long a Dolby Vision toggle may claim "Applying…" before the cue gives up. */
        private const val OUTPUT_SWITCH_FEEDBACK_TIMEOUT_MS = 20_000L
        // Record a durable position roughly every 10s of content time.
        private const val POSITION_RECORD_INTERVAL_SEC = 10.0
        // Non-empty onTracksChanged callbacks an unresolved explicit subtitle
        // gives up and lets the persisted/auto fallback proceed.
        private const val MAX_PENDING_INITIAL_SUBTITLE_ATTEMPTS = 5
        // Auto-play countdown shown on the Up-Next overlay before the next
        // episode starts (mirrors tvOS CountdownRing default).
        const val NEXT_UP_COUNTDOWN_SECONDS = 10
        // A room player sample older than this cannot vouch for buffered media.
        private const val ROOM_SAMPLE_MAX_AGE_MS = 1_000L
        // How long a coordinated source fallback may take before the original
        // refusal is shown after all.
        private const val ROOM_FALLBACK_WAIT_MS = 15_000L
        // How often a waiting Restore quality looks again for its turn.
        private const val BUFFERING_RESTORE_POLL_MS = 250L
        const val SHUFFLE_CONTINUE_FAILED = "Couldn't continue the shuffle."
        const val SHUFFLE_PICK_FAILED = "Couldn't pick another."
    }

    // Up-Next auto-play countdown ticker. Cancelled on dismiss / Play Now /
    // exit. Lives on the VM (not the composable) so the countdown survives
    // recomposition and overlay focus churn.
    private var nextUpCountdownJob: Job? = null

    private var lastRecordedKey: String? = null
    private var lastRecordedPositionSec: Double = -1.0
    private var finalPositionScope: PlaybackWriteScope? = null

    /** [force] bypasses the time-throttle (used on pause/stop to capture the exact spot). */
    private fun maybeRecordPosition(positionSec: Double, durationSec: Double, force: Boolean = false) {
        // The exit token, not UI state: exit clears sessionId before the player
        // reports its pause, which then saved a sequenced session's spot locally (#842).
        if (exitSessionId?.let(playbackSessionManager::isSequenced) == true) return
        if (positionSec < 0.0) return
        val cid = contentId.takeIf { it.isNotBlank() } ?: return
        val fileId = _uiState.value.selectedFileId ?: _uiState.value.mediaFileId ?: return
        val key = "$cid|$fileId"
        if (!force && key == lastRecordedKey && lastRecordedPositionSec >= 0.0 &&
            kotlin.math.abs(positionSec - lastRecordedPositionSec) < POSITION_RECORD_INTERVAL_SEC
        ) {
            return
        }
        lastRecordedKey = key
        lastRecordedPositionSec = positionSec
        viewModelScope.launch {
            userItemStatePort.recordPosition(cid, fileId, positionSec, durationSec.takeIf { it > 0.0 })
        }
    }

    private var contentId: String = launchArgs.contentId
    /**
     * Preferred file version to play (chosen by the user in the detail
     * screen's playback selector row). When the
     * item has multiple versions (e.g. 4K + 1080p), this pins the session
     * to that version's `fileId`. `null` means "auto" — fall back to the
     * first version the server returns.
     *
     * Without this, the detail screen's version picker was visually
     * effective but functionally dead: the Play action always defaulted
     * to `versions.first()`, which for many titles is the lower-
     * resolution file because of the server's version sort order.
     */
    private var preferredFileId: Int? = launchArgs.preferredFileId

    /** The viewer picked [preferredFileId]'s version, so starts of it pin it. */
    private var versionChosen: Boolean = launchArgs.versionChosen
    // A legacy "original" route reads as Auto, which plays the source when it can.
    private var preferredQuality: String? = videoQualityPreference(launchArgs.preferredQuality)
    // Explicit session-level video-quality intent chosen in the player's
    // Quality menu: a plan entry's label, or "auto". Null uses
    // [preferredQuality] as the default output ceiling.
    private var qualityOverride: String? = null
    // Blank means solo, exactly as the screen treats it.
    private val roomId: String? = launchArgs.roomId?.takeIf { it.isNotBlank() }
    private val resumePositionOverride: Double? = launchArgs.resumePositionOverride
    // The handoff belongs to one cross-screen transition. A recoverable start
    // leases it until Ready publication; replacement/exit invalidates it.
    private val episodeSelectionHandoffSlot = TvEpisodeSelectionHandoffSlot(launchArgs.episodeSelectionHandoff)

    // Pre-playback track selections from the detail screen. Audio is sent to the
    // server session start; subtitle is applied once the player's tracks land
    // (see [applyInitialSubtitleIfPending]). Cleared after the first apply so a
    // later user track change isn't overridden.
    private var initialAudioTrackIndex: Int? = launchArgs.initialAudioTrackIndex
    private var pendingInitialSubtitleIndex: Int? = launchArgs.initialSubtitleTrackIndex

    /**
     * Whether [pendingInitialSubtitleIndex] is the detail row's Auto preview
     * rather than the viewer's own pick. Both are applied identically — the
     * row's decision is what starts — but only an explicit pick may be recorded
     * as a manual selection.
     */
    private var pendingInitialSubtitleAutoResolved: Boolean =
        launchArgs.initialSubtitleAutoResolved

    /**
     * Non-empty track callbacks the explicit pick has failed to resolve
     * tracks land (Media3 reports everything at once), so an unresolved pick
     * is retried across callbacks until the sidecars arrive — bounded by
     * [MAX_PENDING_INITIAL_SUBTITLE_ATTEMPTS], after which the pick is dropped
     * so the persisted/auto fallback can proceed.
     */
    private var pendingInitialSubtitleAttempts = 0
    private var pendingPersistedAudioFingerprint: String? = null
    private var autoTextSubtitleSelectionAttempted = false
    private var manualSubtitleSelectionApplied = false

    /**
     * A launch handoff (explicit pick OR the detail row's Auto preview) has been
     * applied, so the player must not re-decide.
     *
     * Separate from [manualSubtitleSelectionApplied], which answers a different
     * question — "did the VIEWER choose this" — and drives persistence and the
     * next-episode intent.
     */
    private var launchSubtitleSelectionApplied = false
    /**
     * Whether the viewer picked the current audio track themselves.
     *
     * Only an explicit choice is carried into the next episode; a server
     * default must not be pinned onto every later one.
     */
    private var manualAudioSelectionApplied = false

    /** Monotonic across the screen's life, so no id is ever reused. */
    private var subtitleFailureIdSeed = 0L

    private fun nextSubtitleFailureId(): Long = ++subtitleFailureIdSeed

    /** Guards [startServerRecoveryFallback] against concurrent fallbacks racing the same session. */
    private var recoveryJob: Job? = null

    /** An outage's wait for the network and the server; see [waitOutOutage]. */
    private var outageRecoveryJob: Job? = null

    /** The mount [outageRecoveryJob] waits to reopen. */
    private var outageMount: Long? = null

    /**
     * The same route was reopened once the outage ended and has not played
     * since: a transport failure now is the route's, so it is replanned.
     */
    private var reopenedAfterOutage = false

    private data class QueuedRecoveryReplan(
        val classification: String,
        val notice: String,
        val qualityPreference: String?,
        val subtitleTrackIndexOverride: Int?,
    )

    /**
     * Latest user track/quality/route change that arrived while [recoveryJob]
     * held the replan single-flight guard. Re-driven against the then-current
     * UiState once that flight completes so the selection isn't silently
     * dropped; last-write-wins because only the newest selection matters.
     */
    private var queuedRecoveryReplan: QueuedRecoveryReplan? = null

    /**
     * Seek recovery has its own latest-target-wins single flight. It is intentionally separate
     * from [recoveryJob]: a committed seek HTTP request is never cancelled by a newer seek, and
     * general playback replans keep their existing single-flight behavior.
     */
    private val seekRecoveryQueue = TvSeekRecoveryQueue()
    private val transportMountGate = TvTransportMountGate()
    private var seekRecoveryRollbackInvalidated = false
    private var pendingNativeSeekAfterMount: Double? = null
    private var transportMountSequence = 0L

    /**
     * Single-flight guard for in-player session restarts ([onSelectFileVersion] +
     * [retry]). Both await a stopSession round-trip before [loadContent] flips
     * isLoading; two rapid picks would otherwise run concurrent load pipelines and
     * orphan a server session. Cancel-and-replace so a fresh pick supersedes an
     * in-flight one without permanently locking out later switches.
     */
    private var versionSwitchJob: Job? = null

    /**
     * Monotonic generation for [loadContent] pipelines. Bumped at the top of
     * every loadContent call; each pipeline captures its value at entry and
     * re-checks it before applying results to [_uiState], so a superseded
     * pipeline (rapid version picks, a retry racing a pick) is inert even
     * once its coordinator round-trip returns.
     */
    private var contentLoadGeneration = 0L
    private val loadOwners = TvPlayerLoadOwnerRegistry()

    /**
     * The account, server and profile the current playback was started under
     * — what a series audio or subtitle pick is saved under.
     */
    private var trackChoiceOwner: org.siloserver.silo.network.AuthScopeSnapshot? = null

    /**
     * The choice the current episode was started with by the previous one,
     * and whether the viewer has picked anything during this episode. What
     * played can be a fallback (the episode lacks the chosen track); the next
     * episode inherits the choice, not the fallback.
     */
    private var episodeIntentContentId: String? = null
    private var incomingEpisodeIntent: org.siloserver.silo.common.player.video.EpisodeSelectionHandoff? = null
    private var audioPickedThisEpisode = false
    private var subtitlePickedThisEpisode = false

    private fun noteEpisodeIntent(
        contentId: String,
        handoff: org.siloserver.silo.common.player.video.EpisodeSelectionHandoff?,
    ) {
        if (contentId != episodeIntentContentId) {
            // The first episode's audio counts as picked only when the detail
            // page's selector was used; its Auto preview is not a pick.
            audioPickedThisEpisode = episodeIntentContentId == null && launchArgs.initialAudioPickedThisSession
            episodeIntentContentId = contentId
            incomingEpisodeIntent = handoff
            subtitlePickedThisEpisode = false
        } else if (handoff != null) {
            incomingEpisodeIntent = handoff
        }
    }

    /** A pick waiting for its change to commit; a newer pick replaces it. */
    private val stagedSubtitleWrite = java.util.concurrent.atomic.AtomicReference<StagedSubtitleWrite?>(null)
    private val stagedAudioWrite = java.util.concurrent.atomic.AtomicReference<StagedAudioWrite?>(null)

    /** Same-route retries spent on transient network errors; reset once playback progresses. */
    private var transientNetworkRetries = 0
    private val quickSkipAccumulator = QuickSkipAccumulator()
    private val seekPresentationGuard = PendingSeekPresentationGuard()
    private var quickSkipCommitJob: Job? = null
    private var quickSkipOriginMs: Long = 0L
    private var activeSeekTargetSec: Double? = null
    private var activeSeekStartedAtMs: Long = 0L
    private var sameRouteSeekRecoveryAttempted = false
    private var seekSequence = 0L
    private var activeSeekId: Long? = null
    private var hasRenderedFirstFrame = false
    // Mounted-transport extent reported by the screen's position poll: whether
    // the current Media3 window is seekable and how far it reaches in
    // player-local time (-1 = unknown/unset). Feeds
    // [mountedSeekableSourceRange] so decideSeek can ride the mounted content
    // for quick skips instead of re-anchoring through the server.
    private var playerWindowIsSeekable = false
    private var playerWindowEndPlayerMs = -1L

    // ---- Watch Party ----------------------------------------------------------
    // Declared ahead of init: the room observation collector and the sleep
    // timer callback installed there touch these.

    /** The room playback epoch this player is prepared for; every room restart reuses it. */
    private var roomContext: WatchPartyPlaybackContext? = null

    /** The selection revision of the published session, or -1 before one. */
    private var roomPreparedRevision = -1L

    /** The room's last applied play state (commands only; never user intent). */
    private var roomPlaying = false

    /** Local reasons playback is held without asking the room. Main thread only. */
    private val roomHolds = mutableSetOf<TvRoomHold>()
    private var roomLoadJob: Job? = null

    private data class TvRoomPlayerSample(
        val positionMs: Long,
        val bufferedPositionMs: Long,
        val playWhenReady: Boolean,
        val isPlaying: Boolean,
        val playbackState: Int,
        val suppressed: Boolean,
        val sampledAtMs: Long,
        val playbackSpeed: Double?,
    )

    private var roomPlayerSample: TvRoomPlayerSample? = null

    // When the latest transport mount was applied. A sample read before it
    // describes the replaced item and must not be mapped through the new
    // plan's timeline.
    private var roomMountAppliedAtMs = Long.MIN_VALUE

    // Counts applied transport mounts, so the room can tell new media from a
    // native seek within the mounted item.
    private var roomMountGeneration = 0L
    private val _roomObservation = MutableStateFlow(RoomPlayerObservation())

    /** What the player is actually doing, for the room binding. */
    val roomObservation: StateFlow<RoomPlayerObservation> = _roomObservation.asStateFlow()
    private val _roomCorrectionRate = MutableStateFlow<Double?>(null)

    /** The room's temporary drift-correction rate; null is exactly 1x. Never saved or shown. */
    val roomCorrectionRate: StateFlow<Double?> = _roomCorrectionRate.asStateFlow()
    private val _roomRefusal = MutableStateFlow<TvRoomRefusal?>(null)

    /** A server refusal the room must decide on before this player shows an error. */
    val roomRefusal: StateFlow<TvRoomRefusal?> = _roomRefusal.asStateFlow()

    data class UiState(
        val isLoading: Boolean = true,
        val error: String? = null,
        /** The catalog string a shared producer named for [error]; shown only while [error] still matches. */
        val errorRes: TvPlayerErrorRes? = null,
        val contentId: String = "",
        /**
         * Distinct "Can't reach server" state (issue #33): when true, [error]
         * carries the reachability message and the error screen offers Retry
         * (fresh probe + reload) plus Try Anyway, rather than a generic failure.
         */
        val serverUnreachable: Boolean = false,
        val title: String = "",
        val seriesTitle: String? = null,
        val year: Int? = null,
        val contentType: String? = null,
        /**
         * Artwork URL for Now Playing lock-screen / Bluetooth / Wear surfaces.
         * Sourced from `WatchDetail.posterUrl` with `backdropUrl` fallback.
         * Threaded into MediaItem.MediaMetadata via [TvPlayerScreen]'s call
         * to `playerFactory.buildMediaItem`. Mirrors phone player parity.
         */
        val artworkUrl: String? = null,
        val sessionId: String? = null,
        val playMethod: PlayMethod? = null,
        val playbackPlan: PlaybackExecutionPlan? = null,
        /**
         * Server-normalized output frame rate. Media3 can report
         * [androidx.media3.common.Format.NO_VALUE] for transformed Dolby Vision
         * streams even though protocol v3 already knows the exact source rate.
         */
        val effectiveFrameRate: Float? = null,
        val requestHeaders: Map<String, String> = emptyMap(),
        val delivery: PlaybackDelivery? = null,
        val streamUrl: String? = null,
        /**
         * Monotonic identity for a concrete player mount. A seek re-anchor can legally return the
         * same URL and plan id with only a new timeline origin, so URL/plan equality is not enough
         * to make Compose mount it again.
         */
        val transportMountNonce: Long = 0L,
        val container: String? = null,
        val serverUrl: String = "",
        val accessToken: String = "",
        val selectedFileId: Int? = null,
        /** All server file versions for this item (in-player version switching). */
        val fileVersions: List<org.siloserver.silo.model.catalog.FileVersion> = emptyList(),
        val selectedFileResolution: String? = null,
        val startPosition: Double = 0.0,
        val position: Double = 0.0,
        val duration: Double = 0.0,
        // Server-declared source runtime (0 when the server didn't provide one).
        // Authoritative ceiling for engine position/duration reports; unlike
        // [duration] it is never touched by player callbacks, so an in-progress
        // transcode's short window can't shrink it.
        val serverDuration: Double = 0.0,
        // User intent (only flipped by onPlayPause / explicit actions).
        val isPaused: Boolean = false,
        // Actual player state — transient dips during buffering must not
        // overwrite isPaused, otherwise the icon flickers to Play and the
        // auto-hide timer cancels mid-stall.
        val isPlaying: Boolean = false,
        // Buffering — driven by the player's onIsLoadingChanged listener
        // (set in the screen). Used together with sessionState.Reconnecting
        // to render the centered spinner during outage recovery.
        val isBuffering: Boolean = false,
        // Track selection — populated by the screen from ExoPlayer's
        // `currentTracks` once playback starts.
        val audioTracks: List<PlayerTrackEntry> = emptyList(),
        /**
         * Catalog ordinal of the audio the viewer wants — including a track the
         * mounted stream already carried, switched without a server replan.
         * Outranks the plan for display, for later replan requests and for the
         * next episode's handoff: the plan names what the server last
         * delivered, not what was chosen.
         */
        val desiredAudioOrdinal: Int? = null,
        /** False while the player has not yet been shown on that track. */
        val desiredAudioConfirmed: Boolean = false,
        val subtitleTracks: List<PlayerTrackEntry> = emptyList(),
        val videoTracks: List<PlayerTrackEntry> = emptyList(),
        // Real per-format video quality variants (resolution/bitrate) flattened
        // from the video group, plus a synthetic "Auto". Distinct from
        // [videoTracks] (group-level): only this drives the HUD Quality picker.
        val videoQualities: List<VideoQualityOption> = emptyList(),
        /**
         * The preference the session plays at: a pick, the route's, or the
         * saved settings. With no row lit (a saved resolution the source
         * plays under) the HUD names it instead of Auto.
         */
        val videoQualityPreference: String? = null,
        // Scrubber preview state — `isScrubbing` flips on the first arrow
        // press from the focused scrubber, `scrubPreviewSec` shadows the
        // intended seek target so the overlay can render a preview puck
        // without committing to MediaController.seekTo until the user
        // releases or presses Select.
        val isScrubbing: Boolean = false,
        val scrubPreviewSec: Double = 0.0,
        // Sidecar subtitle URLs from the playback session — passed into
        // [SiloPlayerFactory.createMediaSource] so the player loads them
        // as text tracks (the stream manifest doesn't reference these).
        val subtitleUrls: List<PlayerSubtitleInfo> = emptyList(),
        // Server media file id for the active version — required by the
        // subtitle search/download and AI translate endpoints. Sourced from
        // PlaybackSessionResponse.mediaFileId in loadContent; null until the
        // session starts (the HUD hides the Search row while null).
        val mediaFileId: Int? = null,
        // Bumped by refreshSubtitles after merging downloaded subtitles into
        // subtitleUrls. The screen rebuilds the MediaItem (same stream URL,
        // enlarged sidecar list) on each bump — keyed on the nonce, NOT on
        // subtitleUrls, so the initial prepare effect stays the only path
        // for session start / stream-URL changes.
        val subtitleRefreshNonce: Int = 0,
        // Grows per sync key each time a syncable subtitle's timing changed
        // and its cues must be fetched again. The mount that carries a
        // revision reports it back, so sync feedback knows the new cues show.
        val subtitleCueRevisions: Map<String, Int> = emptyMap(),
        val committedSubtitleIdentity: SubtitleIdentity = SubtitleIdentity.Off,
        val pendingSubtitleIdentity: SubtitleIdentity? = null,
        val subtitleApplying: Boolean = false,
        val subtitleFailureMessage: String? = null,
        /** The catalog string for [subtitleFailureMessage] when a shared producer named one. */
        val subtitleFailureRes: TvPlayerErrorRes? = null,
        /** Distinguishes two failures that happen to read the same. */
        val subtitleFailureId: Long = 0L,
        // Dialog visibility — owned here so HUD rows can request them and
        // the screen renders the Popups above the open HUD.
        val showSubtitleSearchDialog: Boolean = false,
        val showAiTranslateDialog: Boolean = false,
        // Overlay visibility (Phase E — driven by the screen but stored here
        // so the overlay can react to play/pause state changes).
        val showControls: Boolean = true,
        val controlsVisibilityNonce: Int = 0,
        val hudOpen: Boolean = false,
        val preferredAudioLanguage: String? = null,
        val preferredTextLanguage: String? = null,
        val preferredSubtitleMode: String? = null,
        val showForcedSubtitles: Boolean = true,
        /** The series' remembered subtitle track, from the watch detail. */
        val preferredSubtitleTrackSignature: org.siloserver.silo.model.playback.SubtitleTrackSignature? = null,
        // Intro / credits ranges — populated from `WatchDetail`. Used by the
        // intro auto-skip observer and (eventually) the next-up promote.
        val intro: TimeRange? = null,
        val credits: TimeRange? = null,
        val recap: TimeRange? = null,
        val preview: TimeRange? = null,
        /** Every marker occurrence; null from servers that send only the singular fields. */
        val markerSegments: List<MarkerSegment>? = null,
        // Chapters from the selected FileVersion (server-extracted via FFprobe
        // at ingest, mirrors Apple's `VersionChapter` consumption). Empty list
        // when the file has no embedded chapters. The HUD Chapters pane
        // renders this directly; the scrubber maps the same list to its
        // lightweight ChapterInfo for tick rendering.
        val chapters: List<VersionChapter> = emptyList(),
        // Next-episode auto-advance (F2). seriesId/season/episode come from the
        // Ready state; nextEpisode is resolved from the season/episode lists once
        // playback starts. stillWatchingPrompt gates auto-advance after a run of
        // consecutive auto-plays (pass-out protection).
        val seriesId: String? = null,
        val seasonNumber: Int? = null,
        val episodeNumber: Int? = null,
        val nextEpisode: NextEpisodeState? = null,
        // Up Next's On Deck row: other items in progress (tvOS parity).
        val onDeckItems: List<TvOnDeckItem> = emptyList(),
        val stillWatchingPrompt: Boolean = false,
        // Up-Next end-of-playback surface (mirrors tvOS PlayerNextUpScreen). When
        // `showNextUp` is true the screen renders the Up-Next overlay — a 16:9
        // mini-player pane beside the next-episode panel — in place of the idle
        // controls. `nextUpVideoEnded` distinguishes "almost finished" (credits
        // reached, still playing) from "end of playback" (stream ended).
        // `nextUpCountdownSeconds` drives the auto-play CountdownRing; null
        // means no countdown (auto-play off, pass-out gate hit, or no next
        // episode). A card raised at end-of-playback counts a wall clock down
        // to 0 and then plays the next episode. A card raised at the credits
        // marker instead mirrors the remaining playback time, so reaching 0
        // means "the stream should be over" — it waits for the player to say
        // so rather than cutting the tail off.
        val showNextUp: Boolean = false,
        /** Keep the outgoing frame/card mounted until the successor renders. */
        val isNextUpTransitioning: Boolean = false,
        val nextUpVideoEnded: Boolean = false,
        val nextUpCountdownSeconds: Int? = null,
        val nextUpCountdownTotalSeconds: Int = NEXT_UP_COUNTDOWN_SECONDS,
        val shuffle: TvShuffleUiState? = null,
        // Live player statistics — reduced from [PlaybackAnalyticsListener.Event]s
        // by [reducePlayerStats]. Always non-null so the HUD Stats pane has a
        // snapshot to read; populates field-by-field as events arrive.
        val stats: PlayerStatsSnapshot = PlayerStatsSnapshot(),
        // Video surface fill mode (letterbox vs zoom). Session-scoped — resets
        // to Fit on each new playback to match tvOS video-gravity behavior.
        val videoFillMode: VideoFillMode = VideoFillMode.Fit,
        // The item whose first frame (or, for audio, first play) has shown.
        // Until it matches [contentId] the item is on its first load: no
        // controls, only the spinner. A retry, renewal, reconnect or replan
        // keeps the content id, so only a new item brings that state back.
        val startedContentId: String? = null,
    ) {
        /** The current item has not shown its first frame yet; see [startedContentId]. */
        val awaitingFirstFrame: Boolean
            get() = startedContentId != contentId

        /** The marker occurrences the skip controls and Up Next read. */
        val markerTimeline: MarkerTimeline by lazy {
            MarkerTimeline.resolve(markerSegments, intro = intro, credits = credits, recap = recap, preview = preview)
        }
    }

    private val _uiState = MutableStateFlow(
        UiState(
            contentId = contentId,
            shuffle = TvShuffleUiState().takeIf { !launchArgs.shuffleId.isNullOrBlank() && shuffleFeatureStore != null },
        ),
    )

    init {
        viewModelScope.launch {
            _uiState.collect { state ->
                sendStagedSubtitleIfCommitted(
                    state.contentId, state.committedSubtitleIdentity, state.pendingSubtitleIdentity, state.subtitleUrls,
                )
            }
        }
    }
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()
    val presentationState: StateFlow<UiState> = uiState
        .map(UiState::withoutPlaybackClock)
        .distinctUntilChanged()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = _uiState.value.withoutPlaybackClock(),
        )
    val playbackClock: StateFlow<PlaybackClock> = uiState
        .map(UiState::toPlaybackClock)
        .distinctUntilChanged()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = _uiState.value.toPlaybackClock(),
        )
    // Marker controls use source time; presentationState deliberately omits the clock.
    val manualMarkerSkipTarget: StateFlow<MarkerSkipTarget?> = uiState
        .map { markerSkipTarget(it.position, it.markerTimeline) }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private var subtitleMountGeneration = 0L
    private var lastAdapterMountIdentity: SubtitleIdentity? = null
    private var lastAdapterMountGeneration: Long? = null
    /** The adapter's owner of [lastAdapterMountIdentity]; a new owner re-arms the same identity. */
    private var lastAdapterMountOwner: Long? = null
    /** [lastAdapterMountIdentity] was shown on the playing stream ahead of its replan. */
    private var lastAdapterMountInPlaceSwitch = false

    /**
     * Authority for the NEXT mount the adapter arms, consumed by the snapshot
     * callback below. App-derived selections (launch auto-pick, detail-page
     * restore) must not be able to evict a user pick that is still applying.
     */
    private var nextSubtitleMountPriority = TvSubtitleMountPriority.UserTransaction

    /**
     * Identity the app chose automatically, if it is still the committed one.
     *
     * The adapter cannot tell an automatic pick from a viewer's choice once it
     * is committed, and both flow through the same persistence port — so the
     * per-item subtitle preference is held back here. An automatic pick must
     * never be written back as though the viewer had made it; the next explicit
     * selection clears this and persists normally.
     */
    private var autoSelectedSubtitleIdentity: SubtitleIdentity? = null

    /** True from issuing an automatic selection until the adapter commits it. */
    private var autoSubtitleSelectionInFlight = false
    private val unpublishedSubtitleUi = mutableMapOf<String, UiState>()

    /** The mount nonce of each subtitle publication not yet confirmed, by session. */
    private val unpublishedSubtitleMounts = mutableMapOf<String, Long>()

    /**
     * Sessions whose unconfirmed subtitle publication was applied in place:
     * no mount nonce, the same MediaItem. Their rollback restores the plan
     * and reselects the previous subtitle instead of remounting.
     */
    private val unpublishedInPlaceSubtitles = mutableSetOf<String>()

    /**
     * Unconfirmed publications that moved to another version, which turned the
     * requested subtitle Off because that file lacks it, by session, with the
     * [subtitleChoiceGeneration] they were adopted under. Once confirmed, the Off
     * is not the viewer's choice: it isn't carried to the next episode or saved
     * as their preference, unless they picked a subtitle in the meantime.
     */
    private val unpublishedForcedSubtitleOff = mutableMapOf<String, Long>()

    /** Counts the viewer's subtitle picks; see [unpublishedForcedSubtitleOff]. */
    private var subtitleChoiceGeneration = 0L
    private val unpublishedTvLoadUi =
        TvUnpublishedLoadUiOwnership<UiState, TvSubtitlePlaybackContext>()

    private val subtitleTransactions = TvSubtitleTransactionAdapter(
        scope = viewModelScope,
        // An Auto picked in the player takes the saved cap. The TV has no
        // cellular pair.
        stagedPort = PlaybackSessionManagerTvSubtitleStagedReplanPort(
            playbackSessionManager,
            sessionLifecycle,
        ) { preference -> playerSettingsStore.inPlayerQualityPair(preference, cellular = false) },
        settlementScope = TvSubtitleSettlementOwner.scope,
        persistencePort = object : TvSubtitlePersistencePort {
            override suspend fun persist(
                committed: org.siloserver.silo.model.playback.CommittedSubtitle,
                context: TvSubtitlePlaybackContext,
            ): Boolean {
                // Only when AUDIO was what changed. Every commit carries the
                // current audio index — a subtitle-only change included — so
                // testing the index for non-null marked the server default as
                // the viewer's choice after any successful subtitle change.
                if (committed.audioPreferenceSpecified) onAudioSelectionCommitted()
                sendCommittedSeriesWrites(committed)
                val writeScope = context.writeScope ?: return false
                return userItemStatePort.recordTrackSelection(
                    scope = writeScope,
                    contentId = context.contentId,
                    fileId = context.mediaFileId,
                    audioUpdate = tvAudioTrackPersistenceUpdate(
                        committedAudioTrackIndex = committed.audioTrackIndex,
                        audioTracks = context.audioTracks,
                    ),
                    subtitleUpdate = tvSubtitlePersistenceUpdate(
                        committedIdentity = committed.identity,
                        automaticIdentity = autoSelectedSubtitleIdentity,
                    ),
                )
            }
        },
        onSnapshotChanged = { snapshot ->
            if (snapshot.failureMessage != null) refuseMenuPickWhenIdle()
            val localMountIdentity = snapshot.localMountIdentity
            // A switch shown ahead of its replan ended with nothing after it
            // (a newer pick that takes the replan path, or a failure): the
            // player still shows that track, so put the committed one back.
            val abandonedInPlaceSwitch = localMountIdentity == null &&
                lastAdapterMountInPlaceSwitch &&
                lastAdapterMountIdentity != snapshot.committedIdentity
            if (localMountIdentity != null) lastAdapterMountInPlaceSwitch = snapshot.localMountInPlaceSwitch
            if (localMountIdentity != null && (
                    localMountIdentity != lastAdapterMountIdentity ||
                        snapshot.localMountGeneration != lastAdapterMountOwner
                    )
            ) {
                lastAdapterMountOwner = snapshot.localMountGeneration
                subtitleMountGeneration += 1
                lastAdapterMountGeneration = subtitleMountGeneration
                subtitleRemountReselection.arm(
                    identity = localMountIdentity,
                    generation = subtitleMountGeneration,
                    priority = nextSubtitleMountPriority,
                )
                nextSubtitleMountPriority = TvSubtitleMountPriority.UserTransaction
                subtitleSnapshotSettlement.reset()
                lastAdapterMountIdentity = localMountIdentity
                // In-stream captions can already be present and need no media
                // rebuild, so settle them against the current snapshot now.
                // Off needs no track, and a title without text tracks may
                // publish no later snapshot to act on.
                _uiState.value.subtitleTracks
                    .takeIf { it.isNotEmpty() || localMountIdentity == SubtitleIdentity.Off }
                    ?.let(::resolveSubtitleRemountReselection)
            } else if (localMountIdentity == null) {
                lastAdapterMountGeneration?.let { generation ->
                    if (subtitleRemountReselection.cancelOwned(generation)) {
                        subtitleSnapshotSettlement.reset()
                    }
                }
                lastAdapterMountGeneration = null
                lastAdapterMountIdentity = null
                lastAdapterMountOwner = null
                lastAdapterMountInPlaceSwitch = false
                if (abandonedInPlaceSwitch) reselectMountedSubtitle(snapshot.committedIdentity)
            }
            if (autoSubtitleSelectionInFlight &&
                !snapshot.subtitleApplying &&
                snapshot.localMountIdentity == null
            ) {
                autoSubtitleSelectionInFlight = false
            }
            val committedQuality = snapshot.transition.committed.qualityPreference
            if (!snapshot.subtitleApplying && committedQuality != null) {
                qualityOverride = committedQuality
            }
            _uiState.update { state ->
                state.copy(
                    committedSubtitleIdentity = snapshot.committedIdentity,
                    pendingSubtitleIdentity = snapshot.pendingIdentity,
                    subtitleApplying = snapshot.subtitleApplying,
                    subtitleFailureMessage = snapshot.failureMessage,
                    subtitleFailureId = when {
                        snapshot.failureMessage == null -> state.subtitleFailureId
                        // Any failure that is not the one already on screen is a
                        // new event. Requiring the previous slot to be empty
                        // meant a second, different failure inherited the first
                        // one's id and was therefore never shown — the effect
                        // keys on the id alone.
                        snapshot.failureMessage != state.subtitleFailureMessage ->
                            nextSubtitleFailureId()
                        else -> state.subtitleFailureId
                    },
                    subtitleUrls = authoritativeTvSubtitleRows(
                        snapshotRows = snapshot.subtitleTracks,
                        previousRows = state.subtitleUrls,
                    ),
                    subtitleRefreshNonce = snapshot.subtitleRefreshNonce
                        .coerceAtMost(Int.MAX_VALUE.toLong())
                        .toInt(),
                    videoQualities = state.videoQualities,
                )
            }
        },
        onCommittedPlayback = ::adoptSubtitlePlayback,
        onCommittedPlaybackConfirmed = ::confirmSubtitlePlaybackPublication,
        onCommittedPlaybackRollback = ::rollbackSubtitlePlaybackPublication,
        onEmbeddedSubtitleFailure = { serverIndex ->
            startProtocolV3Replan(
                classification = "subtitle_embedded_failed",
                notice = "Embedded subtitles couldn't load. Retrying with a sidecar.",
                state = _uiState.value,
                subtitleTrackIndexOverride = serverIndex,
            )
        },
        onHlsRenditionSubtitleFailure = { serverIndex ->
            startProtocolV3Replan(
                classification = SUBTITLE_HLS_RENDITION_FAILED_CLASSIFICATION,
                notice = "Embedded subtitles couldn't load. Retrying with a sidecar.",
                state = _uiState.value,
                subtitleTrackIndexOverride = serverIndex,
            )
        },
        onCommittedPlaybackFailure = { message ->
            _uiState.update { it.copy(error = message) }
        },
        // Until the screen applies a pending mount, subtitleTracks still lists
        // the previous item's tracks (onTransportMountApplied clears them), and
        // counting those would start the mount deadline before the new item
        // has any.
        hasMountableTracks = {
            !transportMountGate.suppressPositionReports && _uiState.value.subtitleTracks.isNotEmpty()
        },
        isLocallyMountable = { identity ->
            val state = _uiState.value
            isTvLocallyMountable(
                identity = identity,
                plan = state.playbackPlan,
                subtitleRows = state.subtitleUrls,
                mounted = state.subtitleTracks.map { it.toMountedTvSubtitleTrack() },
            )
        },
        canSwitchInPlace = { committed, target ->
            val state = _uiState.value
            canSwitchSubtitleInPlace(state.playbackPlan, state.subtitleUrls, committed, target)
        },
        onBufferingQualityReplanFailed = {
            Log.i(TAG, "buffering_quality replan_failed")
            bufferingQualityController.onReplanFailed()
        },
    )
    private val subtitleTransactionLaunchMutex = Mutex()
    private val playbackMutationFence by lazy {
        TvPlayerMutationFence(loadOwners, subtitleTransactions::invalidate)
    }

    /** Intro skip pill state. The screen consumes this directly. */
    val introSkipState: StateFlow<IntroAutoSkipState> = introAutoSkipController.state

    /** Bumps whenever the pill's timer (re)starts, so the fill can re-anchor. */
    val introSkipCountdownRun: StateFlow<Int> = introAutoSkipController.countdownRun

    /** False while the pill is up but its timer is frozen by a pause. */
    val introSkipTimerRunning: StateFlow<Boolean> = introAutoSkipController.timerRunning

    /** Total seconds a fresh intro prompt runs for, for the fill's arithmetic. */
    val introSkipTotalSeconds: Int = introAutoSkipController.totalCountdownSeconds

    // ---- Buffering quality (server docs/design/2026-10-17-buffering-quality.md) ----

    /**
     * Lowers quality when playback keeps buffering, or offers to. Suspended
     * in a Watch Party, where the room's own lower-quality offer applies: it
     * times stalls and summarizes plans but never acts. Main thread only,
     * like the intro controller.
     */
    private val bufferingQualityController = BufferingQualityController(
        scope = viewModelScope,
        clock = { SystemClock.elapsedRealtime() },
        onReplan = ::requestBufferingQualityReplan,
        onNotice = ::showBufferingQualityNotice,
        onPlanSummary = { playbackSessionManager.emitPlanSummary(it) },
        planThroughputKbps = playbackSessionManager::observedPlanThroughputKbps,
    )

    /**
     * True while the controller acts on stalls: false in a Watch Party. TV has
     * no local file playback, so that is the only exclusion.
     */
    val bufferingQualityEnabled: Boolean = roomId == null

    /** The Media3 adapter feeding the controller. The screen attaches it to the in-process ExoPlayer. */
    val bufferingQualityAdapter = BufferingQualityPlayerAdapter(
        bufferingQualityController.asPlaybackEventSink(),
        lastMediaByteAtMs = { throughputMeter?.lastByteAtMs() },
        loadingReplacement = { bufferingQualityController.loadingReplacement },
    )

    /** The buffering pill. The screen consumes this directly. */
    val bufferingPill: StateFlow<BufferingQualityPill> = bufferingQualityController.pill

    /** Bumps whenever the pill's timer (re)starts, so the fill can re-anchor. */
    val bufferingCountdownRun: StateFlow<Int> = bufferingQualityController.countdownRun

    /** False while the pill is up but its timer is frozen by a pause. */
    val bufferingTimerRunning: StateFlow<Boolean> = bufferingQualityController.timerRunning

    /** Picture in picture: no pill or notice shows. */
    private val playerViewHidden = MutableStateFlow(false)

    /**
     * The buffering notice. It waits while the player is in picture in
     * picture or a lifecycle notice, which the screen ranks first, holds the
     * slot.
     */
    private val bufferingNoticeSlot = BufferingQualityNoticeSlot(
        scope = viewModelScope,
        slotFree = combine(sessionLifecycle.notice, playerViewHidden) { other, hidden -> other == null && !hidden },
        clock = { SystemClock.elapsedRealtime() },
    )

    /** A display-only buffering notice; the screen words it from string resources. */
    val bufferingNotice: StateFlow<BufferingQualityNotice?> = bufferingNoticeSlot.notice

    private val _bufferingAutoLimited = MutableStateFlow(false)

    /** The playing plan is on Auto under a learned limit: the menu says so. */
    val bufferingAutoLimited: StateFlow<Boolean> = _bufferingAutoLimited.asStateFlow()

    /** The title the controller's answer, notice and re-offer wait belong to. */
    private var bufferingQualityContentId: String? = null

    /** What the last adopted plan played at, for spotting the viewer's quality change. */
    private var bufferingQualityKey: BufferingQualityKey? = null

    /** The viewer's picks, so only the latest one settles the controller's pending pick. */
    private val bufferingPicks = BufferingQualityPicks(bufferingQualityController)
    private var lastMenuPick: BufferingQualityPicks.Pick? = null
    private var lastVersionPick: BufferingQualityPicks.Pick? = null

    /** The mount that plays the controller's own replan, until it is adopted. */
    private var bufferingReplanNonce: Long? = null

    /** A Restore quality waiting for the replan or transaction in flight. */
    private var bufferingRestoreJob: Job? = null

    /**
     * The adoption last handed to the controller. Every published plan that
     * mounts is a new adoption, even when the server repeats its plan_id.
     */
    private var bufferingAdoptionId: String? = null

    /** The mount that made [bufferingAdoptionId]. */
    private var bufferingAdoptedMountNonce: Long? = null

    /**
     * The mount nonce of a client-side same-plan remount (a `client_retry`
     * copy of the playing plan). Its mount is a reload, not an adoption.
     */
    private var pendingBufferingReloadNonce: Long? = null

    private val seekRequestChannel = Channel<Double>(capacity = Channel.BUFFERED)
    val seekRequests: Flow<Double> = seekRequestChannel.receiveAsFlow()

    // ---- Remote session-control surface (driven by TvPlaybackRealtimeController) ----
    // Stop is screen-local (stopPlaybackAndExit) and the lifecycle `notice` is
    // read-only, so expose thin channels here for the control socket to drive.
    private val _roomAudioTrackChanges = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    /**
     * Emits when the viewer switched audio track within the mounted stream in
     * a room, so the binding measures rate support again (a replan mounts new
     * media, which already does).
     */
    val roomAudioTrackChanges: SharedFlow<Unit> = _roomAudioTrackChanges

    private val _remoteStopRequests = MutableSharedFlow<String?>(extraBufferCapacity = 1)
    /** Screen collects this and runs its teardown/exit, showing the notice when there is one. */
    val remoteStopRequests: SharedFlow<String?> = _remoteStopRequests

    private var remoteMessageCounter = 0L
    private val _remoteMessage = MutableStateFlow<RemoteMessage?>(null)
    /** Server "display_message" to surface transiently; null = nothing. */
    val remoteMessage: StateFlow<RemoteMessage?> = _remoteMessage.asStateFlow()

    // ---- Next-episode auto-advance (F2) ----
    private var autoAdvanceCount: Int = launchArgs.autoAdvanceCount
    private var autoAdvanceHandled = false // once-per-item guard
    // The credits or the end of this item was reached. Unlike autoAdvanceHandled,
    // opening Up Next by hand or Keep Watching never sets it.
    private var reachedCreditsOrEnd = false
    // The identity generation this player was launched under.
    private val launchIdentityGeneration: Long? = identityTransitions?.generation?.value
    private val nextUpTransitionGate = NextUpTransitionGate()
    private var resolveNextEpisodeJob: Job? = null
    // Set when the credits/end point fired but nextEpisode hadn't resolved yet,
    // so the Up-Next overlay couldn't arm its countdown. Carries the "video has
    // ended" flag forward so the countdown re-arms once nextEpisode resolves.
    private var pendingApproachingEndVideoEnded: Boolean? = null
    // The running shuffle this player plays picks from; null outside a shuffle.
    private var shufflePlayback: org.siloserver.silo.playback.ShufflePlayback? =
        launchArgs.shuffleId?.takeIf { it.isNotBlank() }?.let { id -> shuffleFeatureStore?.playback(id) }
    // The later part of a multi-part pick that plays before the shuffle moves on.
    private var shuffleNextPartFileId: Int? = null
    // Once per item: the server re-checks the next pick when the overlay opens.
    private var shuffleRefreshedForPostRoll = false
    private var shuffleAdvanceJob: Job? = null
    private var shufflePickJob: Job? = null
    private var shuffleMessageJob: Job? = null
    /**
     * Transient player notice (server reconnecting, suspend warnings, etc.) emitted by
     * [PlaybackSessionLifecycle]. `null` means show nothing.
     */
    val notice: StateFlow<PlayerNotice?> = sessionLifecycle.notice

    /**
     * Lifecycle session state. The screen uses this to drive the buffering
     * spinner during outage Reconnecting (which the underlying ExoPlayer can't
     * observe).
     */
    val sessionState: StateFlow<SessionState> = sessionLifecycle.state

    // ---- Subtitle suite flows ----------------------------------------------------
    private val _subtitleSearch = MutableStateFlow(SubtitleSearchUiState())
    val subtitleSearch: StateFlow<SubtitleSearchUiState> = _subtitleSearch.asStateFlow()

    private val _aiTranslate = MutableStateFlow(AiTranslateUiState())
    val aiTranslate: StateFlow<AiTranslateUiState> = _aiTranslate.asStateFlow()

    // Timing and sync state of the playing file's stored subtitles.
    private val subtitleSync = SubtitleSyncController(
        subtitlesRepository,
        viewModelScope,
        onTimingChanged = ::onSubtitleSyncTimingChanged,
    )
    /** The Subtitles pane's sync state: the selected track's timing actions and each track's status. */
    internal val hudSubtitleSync: StateFlow<TvHudSubtitleSync> = combine(
        subtitleSync.state,
        _uiState
            .map { state -> state.subtitleUrls to (state.pendingSubtitleIdentity ?: state.committedSubtitleIdentity) }
            .distinctUntilChanged(),
    ) { sync, (rows, selected) ->
        val statuses = rows.mapNotNull { row -> sync.statusLabelFor(row)?.let { row to it } }
        TvHudSubtitleSync(
            timing = sync.timingActionsFor(rows.syncKeyFor(selected)),
            statusByServerIndex = statuses.associate { (row, status) -> row.index to status },
            statusByDownloadId = statuses.mapNotNull { (row, status) -> row.downloadId?.let { it to status } }.toMap(),
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, TvHudSubtitleSync())
    // The card that follows a sync this viewer started.
    private val subtitleSyncFeedback = SubtitleSyncFeedbackTracker(viewModelScope)
    // A "syncing" notice clears after a few seconds; the sync itself keeps running,
    // and its result notice still shows when it finishes.
    private val subtitleSyncProgressVisibleMs = 4_000L
    val subtitleSyncNotice: StateFlow<SubtitleSyncNotice?> = subtitleSyncFeedback.notice
        .transformLatest { notice ->
            emit(notice)
            if (notice?.tone == SubtitleSyncNotice.Tone.Progress) {
                delay(subtitleSyncProgressVisibleMs)
                emit(null)
            }
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)
    /** The cue revision of each sync key whose cues the player has in use. */
    private val loadedSubtitleCueRevisions = MutableStateFlow<Map<String, Int>>(emptyMap())
    /** Cue revisions of the last subtitle mount, until Media3 selects its subtitle track. */
    private var mountedSubtitleCueRevisions: Map<String, Int> = emptyMap()

    fun requestSubtitleSync(key: String) = subtitleSync.requestSync(key)

    // Seek-bar thumbnails for the streamed file; the scrubber and the
    // hold-seek chip stay text-only while this is null.
    private val trickplay = trickplayManifests?.let {
        org.siloserver.silo.common.player.trickplay.trickplayPreviews(it, viewModelScope)
    }
    val trickplayThumbnail: StateFlow<androidx.compose.ui.graphics.ImageBitmap?> =
        trickplay?.thumbnail ?: MutableStateFlow(null)

    /** The time a D-pad seek is previewing, or null when it ends. */
    fun showTrickplay(seconds: Double?) {
        trickplay?.show(seconds)
    }

    fun resetSubtitleTiming(key: String) = subtitleSync.resetTiming(key)

    /**
     * The player mounted subtitles built from a state carrying [revisions].
     * Media3 fetches them after the mount returns, so they count as loaded
     * only once [onMountedSubtitleSelected] reports the track in use.
     */
    internal fun onSubtitleCuesMounted(revisions: Map<String, Int>) {
        mountedSubtitleCueRevisions = revisions
    }

    /** Media3 selected the mounted subtitle track on the live player: its cues are in use. */
    internal fun onMountedSubtitleSelected() {
        val revisions = mountedSubtitleCueRevisions
        if (revisions.isEmpty()) return
        mountedSubtitleCueRevisions = emptyMap()
        loadedSubtitleCueRevisions.update { it + revisions }
    }

    /**
     * Mounts the subtitle transaction adapter has asked for, each carrying the
     * owner that must be told how it went. Mirrors the seekRequests idiom: the
     * screen collects and calls SubtitleManager.selectSubtitle — the VM never
     * touches the controller.
     *
     * This is the ONLY channel that may enable or disable a text track on TV.
     * It used to be a bare `SharedFlow<Int>` that the legacy auto/persisted/
     * detail-pick paths also emitted into without arming an owner, which is how
     * playback and the HUD ended up disagreeing.
     */
    private val _subtitleMountRequests =
        // Only the newest owner's request can be applied (canApplySubtitleMount),
        // so an older one still waiting to be collected gives way to it.
        MutableSharedFlow<TvSubtitleMountRequest>(
            extraBufferCapacity = 1,
            onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST,
        )
    internal val subtitleMountRequests: SharedFlow<TvSubtitleMountRequest> = _subtitleMountRequests

    // Remote track-selection latches. A remote command can land before the
    // screen's video backend attaches OR before Media3 reports its tracks
    // (onTracksChanged), yet the controller already reported the command
    // "completed" — so we must not drop it. A StateFlow retains the last
    // requested index; the screen combines it with the live track list and
    // applies the moment a matching track exists (dropping it only once tracks
    // are loaded but contain no match). `null` = nothing pending. The raw index
    // is latched WITHOUT validation here precisely because the track list may
    // not be populated yet.
    private val _pendingRemoteAudioIndex = MutableStateFlow<Int?>(null)
    private val _pendingRemoteSubtitleIndex = MutableStateFlow<Int?>(null)
    // compareAndSet so a command arriving during the suspending apply isn't
    // clobbered by the clear of the one we just handled.

    // ---- Player settings flows (per-profile, DataStore-backed) -----------------
    val playbackSpeed: StateFlow<Double> = playerSettingsStore.playbackSpeedFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, 1.0)
    val introSkipMode: StateFlow<IntroSkipMode> = playerSettingsStore.introSkipModeFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, IntroSkipMode.Default)
    val autoPlayNextEnabled: StateFlow<Boolean> = playerSettingsStore.autoPlayNextFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    // Per-profile "Still watching?" threshold (default 3; 0 = off).
    val passOutThreshold: StateFlow<Int> = playerSettingsStore.passOutThresholdFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, 3)
    val hdrEnabled: StateFlow<Boolean> = playerSettingsStore.hdrEnabledFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val dolbyVisionEnabled: StateFlow<Boolean> = playerSettingsStore.dolbyVisionEnabledFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    val forceHdrPassthrough: StateFlow<Boolean> = playerSettingsStore.forceHdrPassthroughFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val trueBlackBars: StateFlow<Boolean> = playerSettingsStore.trueBlackBarsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val matchContentFrameRate: StateFlow<Boolean> = playerSettingsStore.matchContentFrameRateFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)
    // Effective = custom appearance unless "Match Device Settings" is on
    // (then the OS captioning style, tvOS parity).
    val subtitleAppearance: StateFlow<SubtitleAppearance> = playerSettingsStore.effectiveSubtitleAppearanceFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, SubtitleAppearance.DEFAULT)
    /** False when the server is known to discard subtitle text opacity. */
    val subtitleTextOpacitySupported: StateFlow<Boolean> = playerSettingsStore.subtitleTextOpacitySupportedFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)
    /** The AudioTrack's real output path, for the HUD's Mode row and delay gating. */
    val audioOutputPath: StateFlow<AudioOutputPath?> get() = playbackAnalytics.audioOutputPath

    /**
     * Per-profile audio delay in ms, ±500 clamp. Sourced from
     * [PlayerSettingsStore.audioSyncMsFlow]; mirrored into the active
     * [org.siloserver.silo.common.player.audio.DelayAudioProcessor] by
     * [org.siloserver.silo.common.player.SiloPlaybackService] (E T3).
     * The HUD Audio pane reads this for its delay stepper.
     */
    val audioDelayMs: StateFlow<Int> = playerSettingsStore.audioSyncMsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    /**
     * Per-device subtitle delay in ms, ±10000 clamp. Sourced from
     * [PlayerSettingsStore.subtitleSyncMsFlow]; mirrored into the active
     * [org.siloserver.silo.common.player.subtitle.SubtitleOffsetHolder] by
     * [org.siloserver.silo.common.player.SiloPlaybackService] (A.3f T2).
     * The HUD Subtitles pane reads this for its delay stepper.
     */
    val subtitleDelayMs: StateFlow<Int> = playerSettingsStore.subtitleSyncMsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    // ---- Sleep timer ------------------------------------------------------------
    val sleepTimerState: StateFlow<SleepTimerState> = sleepTimer.state
    val sleepTimerDefaultMinutes: StateFlow<Int> = playerSettingsStore.sleepTimerDefaultMinutesFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, 30)

    private var introObserveJob: Job? = null
    private var lifecycleObserveJob: Job? = null

    // Subtitle suite bookkeeping.
    private var aiStatusRequested = false
    private var aiJobPollJob: Job? = null
    private var activeAiJobId: Long? = null

    // Fork: live AI subtitles. The server streams a running job's output over
    // the session socket, playhead first; the screen draws it until the
    // finished track is loaded and selected through the normal path.
    private val _liveSubtitle = MutableStateFlow<LiveSubtitleTrack?>(null)
    val liveSubtitle: StateFlow<LiveSubtitleTrack?> = _liveSubtitle.asStateFlow()
    private var liveSubtitleFallbackClear: Job? = null
    private var pendingAuthoritativeSubtitleDownloadId: Int? = null
    private val authoritativeSubtitleReadyRows = mutableMapOf<Pair<String, Int>, PlayerSubtitleInfo>()
    private val subtitleRemountReselection = SubtitleRemountReselection()
    private val subtitleSnapshotSettlement = TvSubtitleSnapshotSettlementTracker()

    init {
        startBufferingQuality()
        // Keep the process-wide active-file marker in sync (phone parity), so
        // Reclaim Watched never deletes bytes under a live player.
        viewModelScope.launch {
            _uiState
                .map { it.selectedFileId ?: it.mediaFileId }
                .distinctUntilChanged()
                .collect { org.siloserver.silo.common.player.ActivePlaybackFile.set(it) }
        }
        // Subtitle sync applies to server playback only.
        viewModelScope.launch {
            _uiState
                .map { state ->
                    state.mediaFileId?.takeIf { state.sessionId != null } to
                        state.subtitleUrls.mapNotNullTo(mutableSetOf()) { it.syncKey }
                }
                .distinctUntilChanged()
                .collect { (mediaFileId, syncKeys) -> subtitleSync.bind(mediaFileId, syncKeys) }
        }
        // Seek previews follow the streamed file.
        trickplay?.let { previews ->
            viewModelScope.launch {
                _uiState
                    .map { state ->
                        org.siloserver.silo.common.player.trickplay.trickplayTarget(
                            contentId = state.contentId,
                            fileId = state.mediaFileId,
                            versions = state.fileVersions,
                            streaming = !state.sessionId.isNullOrEmpty(),
                        )
                    }
                    .distinctUntilChanged()
                    .collect(previews::bind)
            }
            // The focused scrubber's preview; the hidden-controls hold seek
            // reports its own through showTrickplay.
            viewModelScope.launch {
                _uiState
                    .map { state -> state.scrubPreviewSec.takeIf { state.isScrubbing } }
                    .distinctUntilChanged()
                    .collect(previews::show)
            }
        }
        viewModelScope.launch {
            val screen = _uiState
                .map { state ->
                    Triple(activeSubtitleSyncKey(state), state.subtitleCueRevisions, state.subtitleUrls)
                }
                .distinctUntilChanged()
            combine(subtitleSync.state, screen, loadedSubtitleCueRevisions) { sync, (activeKey, revisions, tracks), loaded ->
                sync.feedbackInput(activeKey, revisions, loaded) { subtitleSyncName(tracks, it) }
            }.collect(subtitleSyncFeedback::update)
        }
        // Mirror the screen error into the adb test hook — screen-level
        // failures (terminal server plans) never reach the Media3 player, so
        // scripted tests can't see them through player state alone.
        viewModelScope.launch {
            _uiState
                .map { it.error }
                .distinctUntilChanged()
                .collect { org.siloserver.silo.common.player.debug.PlaybackDebugState.screenError = it }
        }
        // Mirror the screen's position/duration too — the scrubber renders
        // from uiState, which can legitimately disagree with the raw player
        // (growing transcode manifests), so tests must see this view of it.
        viewModelScope.launch {
            _uiState
                .map { it.position to it.duration }
                .distinctUntilChanged()
                .collect { (position, duration) ->
                    org.siloserver.silo.common.player.debug.PlaybackDebugState.screenPositionSec = position
                    org.siloserver.silo.common.player.debug.PlaybackDebugState.screenDurationSec = duration
                }
        }
        // Mirror lifecycle Failed state into the UI error field so the user
        // sees a notice if outage recovery times out or the lifecycle's
        // session fails to start. The phone VM does the same.
        lifecycleObserveJob = viewModelScope.launch {
            sessionLifecycle.state.collect { state ->
                if (state is SessionState.Failed) {
                    nextUpTransitionGate.cancel()
                    _uiState.update { current ->
                        if (current.error == null) {
                            current.copy(
                                error = state.message,
                                errorRes = state.messageRes?.let { TvPlayerErrorRes(state.message, it) },
                                showNextUp = false,
                                isNextUpTransitioning = false,
                            )
                        } else {
                            current
                        }
                    }
                }
            }
        }
        viewModelScope.launch {
            sessionLifecycle.sessionEndedEvents.collect { endedSessionId ->
                if (_uiState.value.sessionId == endedSessionId) leaveServerEndedSession()
            }
        }
        viewModelScope.launch {
            sessionLifecycle.missingSessionEvents.collect { renewal ->
                val state = _uiState.value
                if (
                    state.sessionId == renewal.staleSessionId &&
                    renewal.startParams.contentId == contentId
                ) {
                    loadContent(
                        startPositionOverride = renewal.positionSeconds,
                        preferredFileIdOverride = renewal.startParams.fileId,
                        recoveryStartParams = renewal.startParams,
                        suppressResumeRewind = true,
                    )
                }
            }
        }
        viewModelScope.launch {
            capabilityDetector.outputRouteGeneration.drop(1).collect {
                val state = _uiState.value
                if (state.sessionId != null && state.playbackPlan != null) {
                    playbackMutationFence.beginReplan()
                    subtitleTransactions.updatePlaybackContext(subtitlePlaybackContext(state))
                    subtitleTransactions.updateOutputRouteGeneration(
                        capabilityDetector.outputRouteGeneration.value,
                    )
                }
            }
        }

        // When the sleep timer fires, flip user intent to paused. The screen
        // mirrors `isPaused` to `mediaController.playWhenReady`. In a Watch
        // Party it is a local hold: the room keeps playing.
        sleepTimer.configure {
            if (roomId != null) {
                holdRoomPlayback(TvRoomHold.SleepTimer)
            } else {
                _uiState.update { it.copy(isPaused = true) }
            }
        }

        // Reduce the analytics listener's event stream into the HUD's Stats
        // snapshot. The listener is a process-wide singleton shared with
        // SiloPlaybackService; we just subscribe — no extra registration.
        viewModelScope.launch {
            playbackAnalytics.events.collect { event ->
                _uiState.update { it.copy(stats = reducePlayerStats(it.stats, event)) }
            }
        }

        if (roomId != null) {
            // Loading, session, error and duration changes all move the room
            // observation; player samples arrive through onRoomPlayerSample.
            viewModelScope.launch { _uiState.collect { publishRoomObservation() } }
        } else if (contentId.isNotBlank()) {
            // A Watch Party waits for the room's playback context
            // (loadRoomPlayback): the route's own content and file must never
            // start solo playback first.
            loadContent(startPositionOverride = resumePositionOverride)
        }
    }

    fun onBackendCapabilities(capabilities: VideoBackendCapabilities) {
        _uiState.update { state ->
            state.copy(
                stats = state.stats.copy(
                    backendKind = capabilities.backendKind.name,
                    backendDisplayName = capabilities.displayName,
                    backendRoute = capabilities.route.displayName,
                    subtitleRendering = capabilities.subtitleRendering.name,
                    hardContainers = if (capabilities.supportsHardContainers) "Yes" else "No",
                ),
            )
        }
    }

    private fun nextTransportMountNonce(subtitleServerIndexToRestore: Int?): Long {
        // Media3 does not carry a live text-track override across MediaItem
        // replacement. Every same-content remount declares the stable server
        // subtitle index to restore; the first mount explicitly passes null.
        transportMountSequence = if (transportMountSequence == Long.MAX_VALUE) {
            1L
        } else {
            transportMountSequence + 1L
        }
        subtitleServerIndexToRestore?.let { serverIndex ->
            subtitleSnapshotSettlement.reset()
            // A track the media itself carries (a native track or a rendition)
            // is restored by its exact identity. After an in-place switch the
            // reloaded multivariant playlist still marks the original track
            // DEFAULT, so only the explicit selection puts the viewer's back.
            val committed = (_uiState.value.committedSubtitleIdentity as? SubtitleIdentity.Embedded)
                ?.takeIf { it.isServerSelected && it.serverIndex == serverIndex }
            subtitleRemountReselection.arm(
                identity = when {
                    serverIndex == -1 -> SubtitleIdentity.Off
                    committed != null -> committed
                    else -> SubtitleIdentity.ServerSidecar(serverIndex)
                },
                generation = transportMountSequence,
            )
        }
        transportMountGate.expect(transportMountSequence)
        nextUpTransitionGate.expectMount(contentId, transportMountSequence)
        return transportMountSequence
    }

    private fun nextTypedSubtitleMountNonce(identity: SubtitleIdentity): Long {
        transportMountSequence = if (transportMountSequence == Long.MAX_VALUE) {
            1L
        } else {
            transportMountSequence + 1L
        }
        subtitleMountGeneration += 1
        if (subtitleRemountReselection.requiresRemount(identity)) {
            subtitleSnapshotSettlement.reset()
            subtitleRemountReselection.arm(identity, subtitleMountGeneration)
        }
        transportMountGate.expect(transportMountSequence)
        nextUpTransitionGate.expectMount(contentId, transportMountSequence)
        return transportMountSequence
    }

    private suspend fun subtitlePlaybackContext(state: UiState): TvSubtitlePlaybackContext {
        val dolbyVision = playerSettingsStore.dolbyVisionPolicySnapshot()
        val forceHdrPassthrough = playerSettingsStore.forceHdrPassthroughFlow.first()
        val capabilities = capabilityDetector.detect(dolbyVision = dolbyVision, forceHdrPassthrough = forceHdrPassthrough)
        return subtitlePlaybackContext(
            state = state,
            capabilities = capabilities,
            clientPlaybackContext = capabilityDetector.detectPlaybackContext(
                formFactor = "tv",
                appVersion = BuildConfig.VERSION_NAME,
                dolbyVision = dolbyVision,
                capabilities = capabilities,
            ),
        )
    }

    private fun subtitlePlaybackContext(
        state: UiState,
        capabilities: ClientCodecCapabilities,
        clientPlaybackContext: ClientPlaybackContext,
    ): TvSubtitlePlaybackContext {
        val fileId = state.selectedFileId ?: state.mediaFileId ?: 0
        val version = state.fileVersions.firstOrNull { it.fileId == fileId }
        // The viewer's confirmed choice outranks the plan, exactly as the
        // recovery replan already does. A direct-play local switch changes the
        // mounted track without replanning, so the plan can still name the
        // previous audio — and a subtitle, quality or output-route transaction
        // built from it would replan the viewer straight back onto the track
        // they had just switched away from.
        val selectedAudio = state.desiredAudioOrdinal?.takeIf { state.desiredAudioConfirmed }
            ?: selectedServerAudioTrackIndex(
                selectedPlayerOrdinal = state.audioTracks.firstOrNull { it.isSelected }?.index,
                catalogAudioTracks = version?.audioTracks,
                currentPlanTrackIndex = state.playbackPlan?.selectedTracks?.audioIndex,
            )
        return TvSubtitlePlaybackContext(
            contentId = contentId,
            mediaFileId = fileId,
            versionId = "$fileId:${state.playbackPlan?.planId.orEmpty()}",
            sessionId = state.sessionId,
            positionSeconds = state.position,
            audioTrackIndex = selectedAudio,
            // Only a pick (or the route's quality). Defaulting to "auto" here
            // sent Auto on every subtitle change, over a saved resolution, and
            // the commit then recorded it as the viewer's pick.
            qualityPreference = qualityOverride ?: preferredQuality,
            subtitleTracks = state.subtitleUrls,
            audioTracks = version?.audioTracks.orEmpty(),
            outputRouteGeneration = capabilityDetector.outputRouteGeneration.value,
            capabilities = capabilities,
            clientPlaybackContext = clientPlaybackContext,
            writeScope = finalPositionScope,
        )
    }

    private fun launchSubtitleTransaction(
        state: UiState,
        transaction: () -> Unit,
    ) {
        viewModelScope.launch {
            subtitleTransactionLaunchMutex.withLock {
                subtitleTransactions.updatePlaybackContext(subtitlePlaybackContext(state))
                transaction()
            }
        }
    }

    private suspend fun adoptSubtitlePlayback(
        adoption: TvSubtitlePlaybackAdoption,
    ): TvSubtitleAdoptionResult {
        val ready = adoption.playback.ready ?: return TvSubtitleAdoptionResult.Superseded
        if (!adoption.isCurrent()) return TvSubtitleAdoptionResult.Superseded
        val before = _uiState.value
        val fileId = ready.session.mediaFileId.takeIf { it > 0 }
            ?: ready.plan.effectiveMediaFileId
            ?: before.selectedFileId
            ?: before.mediaFileId
            ?: return TvSubtitleAdoptionResult.Superseded
        // A Watch Party plays exactly the room's file; never adopt another.
        if (roomContext?.fileId?.let { it != fileId } == true) return TvSubtitleAdoptionResult.Superseded
        val version = before.fileVersions.firstOrNull { it.fileId == fileId }
        val adopted = sessionLifecycle.adoptActiveSessionIfCurrent(
            params = StartParams(
                contentId = contentId,
                fileId = fileId,
                capabilities = ready.capabilities,
                audioTrackIndex = adoption.committed.audioTrackIndex,
                subtitleTrackIndex = adoption.committed.identity.serverTrackIndexForTv(),
                qualityPreference = adoption.committed.qualityPreference,
                startPosition = ready.session.position,
                clientPlaybackContext = ready.clientPlaybackContext,
            ),
            session = ready.session,
            deferPublication = true,
            isCurrent = adoption::isCurrent,
        )
        if (!adopted) return TvSubtitleAdoptionResult.Superseded
        // The exit token names what the lifecycle owns, from the moment it owns
        // it — not from the UI publication further down. Supersession in the gap
        // otherwise leaves teardown naming the predecessor, the ownership guard
        // rightly refusing it, and the one-shot gate blocking any retry.
        lastAdoptedSessionId = ready.session.sessionId
        if (!adoption.isCurrent()) return TvSubtitleAdoptionResult.Superseded
        unpublishedSubtitleUi[ready.session.sessionId] = before
        if (fileId != before.mediaFileId &&
            adoption.committed.identity == SubtitleIdentity.Off &&
            adoption.requestedIdentity != SubtitleIdentity.Off
        ) {
            unpublishedForcedSubtitleOff[ready.session.sessionId] = subtitleChoiceGeneration
        }

        val subtitleUrls = enrichAuthoritativePlaybackSubtitleChoices(
            catalogTracks = version?.subtitleTracks.orEmpty(),
            plannedTracks = ready.session.subtitleUrls.orEmpty(),
        )
        val mountedPlan = before.playbackPlan
        val adoptedPlan = ready.session.playbackPlan
        if (ready.inPlace &&
            fileId == before.mediaFileId &&
            ready.session.sessionId == before.sessionId &&
            mountedPlan != null &&
            adoptedPlan != null
        ) {
            // The server kept the transport and changed only a subtitle the
            // mounted media already carries, which the adapter has selected
            // (or turned off) on the player. No mount nonce is issued, so the
            // screen keeps the MediaItem: its mount effect keys on the plan's
            // media mount key, which this plan shares. The publication is
            // confirmed by the adapter's mount owner reporting the selection
            // on the current tracks, like any local mount.
            unpublishedInPlaceSubtitles += ready.session.sessionId
            _uiState.update { state ->
                state.copy(
                    error = null,
                    playbackPlan = (state.playbackPlan ?: mountedPlan).withInPlaceAdoption(adoptedPlan),
                    delivery = ready.plan.delivery,
                    videoQualities = authoritativePlaybackQualityOptions(
                        available = ready.plan.availableQualities,
                        selectedLabel = adoption.committed.qualityPreference ?: sessionQualityPreference(),
                        delivered = ready.plan.effectiveRecipe,
                        source = ready.plan.source,
                        reported = ready.plan.reportedQuality,
                    ),
                    subtitleUrls = subtitleUrls,
                )
            }
            Log.i(TAG, "subtitle_replan_in_place plan_id=${ready.plan.planId}")
            return TvSubtitleAdoptionResult.Adopted
        }
        val duration = ready.session.durationSeconds ?: 0.0
        val remountPosition = ready.plan.timeline.replanMountPositionForSource(
            adoption.requestedSourcePositionSeconds,
        )
        val mountNonce = nextTypedSubtitleMountNonce(adoption.committed.identity)
        unpublishedSubtitleMounts[ready.session.sessionId] = mountNonce
        unpublishedInPlaceSubtitles -= ready.session.sessionId
        bufferingReplanNonce = mountNonce.takeIf { adoption.bufferingQuality }
        _uiState.update { state ->
            state.copy(
                error = null,
                sessionId = ready.session.sessionId,
                playMethod = ready.session.playMethod,
                playbackPlan = ready.session.playbackPlan,
                delivery = ready.plan.delivery,
                streamUrl = ready.plan.stream.url,
                transportMountNonce = mountNonce,
                requestHeaders = ready.plan.stream.effectiveRequestHeaders,
                selectedFileId = fileId,
                mediaFileId = fileId,
                selectedFileResolution = version?.resolution
                    ?: ready.plan.effectiveRecipe.height?.let { "${it}p" },
                videoQualities = authoritativePlaybackQualityOptions(
                    available = ready.plan.availableQualities,
                    selectedLabel = adoption.committed.qualityPreference ?: sessionQualityPreference(),
                    delivered = ready.plan.effectiveRecipe,
                    source = ready.plan.source,
                    reported = ready.plan.reportedQuality,
                ),
                videoQualityPreference = adoption.committed.qualityPreference ?: sessionQualityPreference(),
                container = ready.plan.stream.container ?: version?.container ?: state.container,
                duration = duration,
                serverDuration = duration,
                subtitleUrls = subtitleUrls,
                chapters = version?.chapters.orEmpty(),
                startPosition = remountPosition.playerPositionSeconds,
                position = remountPosition.sourcePositionSeconds,
            )
        }
        adoptFileMarkersAfterReplan(before.mediaFileId, version)
        Log.i(
            TAG,
            "subtitle_replan_mount restored_source_seconds=${remountPosition.sourcePositionSeconds} " +
                "player_seconds=${remountPosition.playerPositionSeconds}",
        )
        return TvSubtitleAdoptionResult.Adopted
    }

    private suspend fun confirmSubtitlePlaybackPublication(
        playback: TvSubtitleCommittedPlayback,
    ): Boolean {
        unpublishedSubtitleUi.remove(playback.sessionId)
        unpublishedSubtitleMounts.remove(playback.sessionId)
        unpublishedInPlaceSubtitles.remove(playback.sessionId)
        if (unpublishedForcedSubtitleOff.remove(playback.sessionId) == subtitleChoiceGeneration) {
            manualSubtitleSelectionApplied = false
            autoSelectedSubtitleIdentity = SubtitleIdentity.Off
        }
        return true
    }

    private suspend fun rollbackSubtitlePlaybackPublication(
        playback: TvSubtitleCommittedPlayback,
        restoreUi: Boolean,
    ): Boolean {
        val predecessor = unpublishedSubtitleUi.remove(playback.sessionId)
        unpublishedForcedSubtitleOff.remove(playback.sessionId)
        val inPlace = unpublishedInPlaceSubtitles.remove(playback.sessionId)
        // A replacement the controller adopted sends its summary when the
        // predecessor's remount ends it. One it never adopted sends none, and
        // its identity would go to a later adoption that repeats its plan id.
        val mountNonce = unpublishedSubtitleMounts.remove(playback.sessionId)
        if (mountNonce == null || mountNonce != bufferingAdoptedMountNonce) {
            playback.ready?.let { playbackSessionManager.forgetPlanIdentity(it.plan.planId, it.planAttemptId) }
        }
        // The token follows lifecycle ownership in BOTH directions. Rollback
        // hands ownership back to the predecessor, so leaving the token on the
        // discarded replacement would make teardown name a session the
        // lifecycle no longer holds — and be refused. This runs regardless of
        // restoreUi: ownership reverts either way.
        if (lastAdoptedSessionId == playback.sessionId) {
            lastAdoptedSessionId = predecessor?.sessionId
        }
        if (restoreUi && predecessor != null && inPlace) {
            // The MediaItem never changed: lay the predecessor's subtitle
            // decision back over the mounted plan, as the adoption did, and
            // select its subtitle again on the same tracks. The rest of the
            // snapshot is older than what is playing now; its whole plan
            // would bring back fields changed since (a PCM retry's audio
            // claims), change the media mount key, and remount.
            _uiState.update { state ->
                state.copy(
                    playbackPlan = predecessor.playbackPlan?.let { previous ->
                        state.playbackPlan?.withInPlaceAdoption(previous) ?: previous
                    },
                    delivery = predecessor.delivery,
                    videoQualities = predecessor.videoQualities,
                    subtitleUrls = predecessor.subtitleUrls,
                )
            }
            reselectMountedSubtitle(predecessor.committedSubtitleIdentity)
        } else if (restoreUi && predecessor != null) {
            val identity = predecessor.committedSubtitleIdentity
            _uiState.value = predecessor.copy(
                transportMountNonce = nextTypedSubtitleMountNonce(identity),
            )
        }
        return true
    }

    /** Selects [identity] again on the mounted tracks, as a remount would, without one. */
    private fun reselectMountedSubtitle(identity: SubtitleIdentity) {
        subtitleMountGeneration += 1
        if (subtitleRemountReselection.requiresRemount(identity)) {
            subtitleSnapshotSettlement.reset()
            subtitleRemountReselection.arm(identity, subtitleMountGeneration)
        }
        _uiState.value.subtitleTracks
            .takeIf(List<PlayerTrackEntry>::isNotEmpty)
            ?.let(::resolveSubtitleRemountReselection)
    }

    private suspend fun rollbackUnpublishedTvLoadSession(sessionId: String) {
        val predecessor = unpublishedTvLoadUi.snapshotForRollback(sessionId)
        val jointlyRolledBack = sessionLifecycle.settlePendingPublicationIfCurrent(
            sessionId = sessionId,
            confirm = false,
            settleManager = {
                playbackSessionManager.rollbackUnpublishedVideoSession(sessionId)
            },
        )
        if (!jointlyRolledBack) {
            playbackSessionManager.rollbackUnpublishedVideoSession(sessionId)
        }
        // Same rule as the subtitle rollback: ownership reverted to the
        // predecessor, so the exit token has to revert with it.
        if (lastAdoptedSessionId == sessionId) {
            lastAdoptedSessionId = predecessor?.state?.sessionId
        }
        try {
            if (predecessor != null && _uiState.value.sessionId == sessionId) {
                val identity = predecessor.state.committedSubtitleIdentity
                _uiState.value = predecessor.state.copy(
                    transportMountNonce = nextTypedSubtitleMountNonce(identity),
                )
                subtitleTransactions.resetContent(
                    context = predecessor.context,
                    committedIdentity = identity,
                )
            }
        } finally {
            unpublishedTvLoadUi.completeRollback(sessionId)
        }
    }

    /**
     * Called after [org.siloserver.silo.common.player.backend.VideoPlaybackBackend.mount] has
     * synchronously replaced the Media3 item. Nonce qualification prevents an older cancelled
     * Compose effect from unblocking reports for a newer timeline.
     */
    fun onTransportMountApplied(nonce: Long) {
        if (transportMountGate.applied(nonce)) {
            // A matching mount has replaced the item. Discard its predecessor's
            // groups; only the new item's onTracksChanged can resolve subtitles.
            _uiState.update { it.copy(subtitleTracks = emptyList()) }
            subtitleSnapshotSettlement.reset()
            // The mounted item was replaced. Facts from the previous
            // transport's window must not be mapped through the new plan's
            // timeline offset — that can overstate the new extent and turn a
            // target the new transport cannot serve into a silent,
            // wrong-position native seek. The next poll tick (≤500ms)
            // repopulates from the mounted item; until then the hint is
            // absent, which at worst costs an unnecessary reanchor.
            playerWindowIsSeekable = false
            playerWindowEndPlayerMs = -1L
            adoptBufferingQualityPlan(nonce)
            roomMountAppliedAtMs = SystemClock.elapsedRealtime()
            roomMountGeneration++
            pendingNativeSeekAfterMount?.let { targetSeconds ->
                pendingNativeSeekAfterMount = null
                // Re-evaluate against the plan that actually won the load;
                // source/player time may no longer be identical.
                executeSeekTarget(targetSeconds)
            }
            publishRoomObservation()
        }
    }

    /**
     * Invalidates seek work for a new content/version load. A request already on the wire is left
     * to finish so server playback-attempt state remains coherent; its generation can no longer
     * pass the adoption guard.
     */
    private fun resetSeekRecoveryForContentChange() {
        recoveryJob?.cancel()
        recoveryJob = null
        outageRecoveryJob?.cancel()
        outageRecoveryJob = null
        queuedRecoveryReplan = null
        // A budget exhausted on the previous content/version must not leak
        // into the next one (phone parity: resetPlaybackRecoveryState).
        transientNetworkRetries = 0
        reopenedAfterOutage = false
        seekRecoveryQueue.reset()
        cancelPendingQuickSkip()
        seekPresentationGuard.cancel()
        activeSeekTargetSec = null
        activeSeekId = null
        sameRouteSeekRecoveryAttempted = false
        seekRecoveryRollbackInvalidated = false
        pendingNativeSeekAfterMount = null
    }

    private fun loadContent(
        startPositionOverride: Double? = null,
        preferredFileIdOverride: Int? = null,
        // Pins the file this start plays: the viewer's pick, or an in-place restart's exact file.
        versionChosen: Boolean = this.versionChosen,
        audioTrackIndexOverride: Int? = null,
        audioTrackIndexOverrideSpecified: Boolean = false,
        // A missing server session is a renewal, not a new route. Use the
        // lifecycle's adoption-time selection snapshot because Media3 may have
        // already cleared its live tracks by the time the 404 is observed.
        recoveryStartParams: StartParams? = null,
        // True for retry: re-load at the current position without nudging back
        // (a normal first resume keeps the default false so it gets the rewind).
        suppressResumeRewind: Boolean = false,
        // Try Anyway escape hatch (issue #33): bypass the pre-play reachability
        // gate and attempt the server even while it reports unreachable.
        force: Boolean = false,
        // Version replacement is transactional: keep the mounted version
        // visible until the replacement has won ownership and is ready.
        preserveCurrentPlaybackOnFailure: Boolean = false,
    ) {
        // A Watch Party only ever starts the room's exact file and position.
        // Retry, the reachability retries and the 404 renewal all come through
        // here and reuse the room context; before the room has supplied one
        // there is nothing to start.
        val requestRoom = tvRoomStartContext(
            context = roomContext,
            startPositionOverride = startPositionOverride,
            currentSourcePositionSeconds = _uiState.value.position,
            preparedRevision = roomPreparedRevision,
        )
        if (roomId != null && requestRoom == null) return
        // Capture this pipeline's generation; a later loadContent bump makes
        // this one inert before it can touch _uiState.
        val generation = ++contentLoadGeneration
        // The previous load's AI job poll goes inert with the generation, so
        // its phase (progress or failure) must not carry into this content.
        _aiTranslate.update { it.copy(phase = AiJobPhase.Idle) }
        if (recoveryStartParams != null) {
            pendingInitialSubtitleIndex = recoveryStartParams.subtitleTrackIndex
            // A recovery restores the selection the session was already
            // playing, so it restores that selection's STANDING too. The
            // snapshot carries an index and no provenance, so read it off the
            // session being replaced — this runs before the flags are cleared
            // below. Calling it manual unconditionally promoted a pick the app
            // had made into the viewer's: once resolved it set
            // manualSubtitleSelectionApplied, and the automatic choice rode the
            // next episode's handoff and the durable preference.
            pendingInitialSubtitleAutoResolved = !manualSubtitleSelectionApplied
            pendingInitialSubtitleAttempts = 0
        }
        val loadOwner = playbackMutationFence.beginLoad(
            contentId = contentId,
            preferredFileId = preferredFileIdOverride ?: preferredFileId,
            preferredQuality = recoveryStartParams?.qualityPreference
                ?: qualityOverride
                ?: preferredQuality,
        )
        hasRenderedFirstFrame = false
        resetSeekRecoveryForContentChange()
        transportMountGate.beginLoad()
        introAutoSkipController.reset()
        beginBufferingQualityLoad()
        manualSubtitleSelectionApplied = false
        launchSubtitleSelectionApplied = false
        // A replacement load (version switch, retry) decides Auto again for its
        // own file: an earlier automatic Off left text disabled, and only a new
        // decision mounts the subtitle this plan commits.
        autoTextSubtitleSelectionAttempted = false
        autoSelectedSubtitleIdentity = null
        autoSubtitleSelectionInFlight = false
        // Cleared here and raised only if the carried choice actually RESOLVES
        // against this episode's tracks.
        //
        // Seeding it from the intent alone was wrong: resolveEpisodeAudioIntent
        // deliberately returns null when nothing matches or the match is
        // ambiguous, and that null means the server default plays. Marking it
        // manual anyway made the next auto-advance capture that default as a
        // deliberate choice — so one unresolvable episode turned a server
        // default into a preference that then propagated for the rest of the
        // series.
        manualAudioSelectionApplied = false
        _uiState.update { it.copy(isBuffering = false) }

        _uiState.update {
            if (preserveCurrentPlaybackOnFailure) beginTvReplacementLoad(it)
            else it.copy(isLoading = true, error = null, serverUnreachable = false)
        }
        finalPositionScope = null
        viewModelScope.launch {
            finalPositionScope = finalPlaybackPositionWriter.captureScope()
            val unpublishedReadySession =
                TvUnpublishedLoadSessionOwnership(::rollbackUnpublishedTvLoadSession)
            var episodeSelectionHandoffLease: TvEpisodeSelectionHandoffLease? = null
            try {
                if (!subtitleTransactions.invalidateAndAwaitSettlement()) return@launch
                runCatching { playerSettingsStore.refreshFromServer() }
                if (!loadOwners.owns(loadOwner)) return@launch
                episodeSelectionHandoffLease = episodeSelectionHandoffSlot.leaseForStart(
                    ownerGeneration = loadOwner.generation,
                )
                val episodeSelectionHandoff = episodeSelectionHandoffLease?.handoff
                noteEpisodeIntent(contentId, episodeSelectionHandoff)
                val request = VideoPlaybackStartRequest(
                        libraryId = requestRoom?.libraryId ?: launchArgs.libraryId,
                        contentId = contentId,
                        preferredFileId = requestRoom?.fileId ?: preferredFileIdOverride ?: preferredFileId,
                        roomId = requestRoom?.roomId ?: roomId,
                        resumePositionOverride = requestRoom?.positionSeconds ?: startPositionOverride,
                        audioTrackIndex = if (recoveryStartParams != null) {
                            recoveryStartParams.audioTrackIndex
                        } else if (audioTrackIndexOverrideSpecified) {
                            audioTrackIndexOverride
                        } else {
                            initialAudioTrackIndex
                        },
                        subtitleTrackIndex = if (recoveryStartParams != null) {
                            recoveryStartParams.subtitleTrackIndex
                        } else {
                            pendingInitialSubtitleIndex
                        },
                        preferredQualityOverride = recoveryStartParams?.qualityPreference
                            ?: preferredQuality,
                        playbackQualityIntent = qualityOverride,
                        suppressResumeRewind = suppressResumeRewind,
                        force = force,
                        episodeSelectionHandoff = episodeSelectionHandoff,
                        recoveryStartParams = recoveryStartParams,
                        room = requestRoom,
                        versionChosen = versionChosen,
                    )
                // Adopted only when this load publishes: a superseded one must
                // not replace the owner of the playback that is on screen.
                val loadTrackChoiceOwner = catalogRepository.captureWatchAuthority()
                if (!loadOwners.owns(loadOwner)) return@launch
                val result = loadOwners.withOwner(loadOwner) {
                    videoPlaybackCoordinator.start(request)
                }
                // A newer loadContent superseded this pipeline while start()
                // was in flight — its results must not clobber the newer
                // pipeline's session state.
                if (generation != contentLoadGeneration && result !is VideoPlayerUiState.Ready) {
                    return@launch
                }
                when (result) {
                    is VideoPlayerUiState.Ready -> {
                        val allocatedSessionId = result.sessionId
                            ?.takeIf(String::isNotBlank)
                            ?: run {
                                episodeSelectionHandoffSlot.retainForRetry(
                                    episodeSelectionHandoffLease,
                                )
                                fail("Playback start returned no session.")
                                return@launch
                            }
                        unpublishedReadySession.acquire(allocatedSessionId)
                        // Fresh load is a fourth lifecycle-first path: the
                        // starter already adopted this session before returning,
                        // and several suspending hydration steps stand between
                        // here and the UI publication below. Advance the exit
                        // token now, or an exit landing in that gap names the
                        // predecessor, is refused, and permanently claims the
                        // one-shot gate while this load goes on to publish.
                        // The rollback paths revert it if this never publishes.
                        lastAdoptedSessionId = allocatedSessionId
                        if (!loadOwners.owns(loadOwner)) {
                            loadOwners.publishReadyIfOwned(
                                owner = loadOwner,
                                sessionId = allocatedSessionId,
                                publish = {},
                                stopStaleSession = unpublishedReadySession::rollbackIfOwned,
                            )
                            return@launch
                        }
                        val subtitleSelection = resolveTvEpisodeInitialSubtitleSelection(
                            episodeSelectionHandoff = episodeSelectionHandoff,
                            resolvedEpisodeSelection = result.resolvedEpisodeSelection,
                            existingPendingInitialSubtitleIndex = pendingInitialSubtitleIndex,
                        )
                        pendingInitialSubtitleIndex = subtitleSelection.pendingInitialSubtitleIndex
                        if (episodeSelectionHandoff != null) {
                            // A carried episode intent is the viewer's, not a preview.
                            pendingInitialSubtitleAutoResolved = false
                        }
                        val resolvedSelection = result.resolvedEpisodeSelection
                        if (episodeSelectionHandoff != null && resolvedSelection != null) {
                            pendingInitialSubtitleAttempts = 0
                            // The carried audio choice counts as the viewer's
                            // only once it RESOLVED to a real track here. A
                            // TRACK intent that matched nothing leaves the
                            // server default playing, and calling that manual
                            // would hand it on to the next episode as though it
                            // had been chosen.
                            if (resolvedSelection.audioTrackIndex != null) {
                                manualAudioSelectionApplied = true
                            }
                        }
                        val localTrackSelection = result.fileId
                            ?.let { fileId -> userItemStatePort.localTrackSelection(contentId, fileId) }
                        if (!loadOwners.owns(loadOwner)) {
                            loadOwners.publishReadyIfOwned(
                                owner = loadOwner,
                                sessionId = allocatedSessionId,
                                publish = {},
                                stopStaleSession = unpublishedReadySession::rollbackIfOwned,
                            )
                            return@launch
                        }
                        val readyMediaFileId = result.mediaFileId
                        val readySessionId = result.sessionId
                        val catalogSubtitleTracks = result.versions
                            .firstOrNull { it.fileId == (result.fileId ?: readyMediaFileId) }
                            ?.subtitleTracks
                            .orEmpty()
                        val restorePreference = if (
                            pendingInitialSubtitleIndex == null &&
                            !subtitleSelection.suppressDurableSubtitleRestore
                        ) {
                            // The series choice on the server outranks this
                            // device's per-file memory: it is what every other
                            // device sees, and Auto elsewhere deletes it.
                            org.siloserver.silo.model.playback.localSubtitleMemoryForSeriesChoice(
                                localPreference = localTrackSelection?.subtitleFingerprint,
                                serverChoiceKnown = true,
                                signature = result.preferredSubtitleTrackSignature,
                                candidates = org.siloserver.silo.model.playback.inventoryAutoSubtitleCandidates(
                                    result.subtitleUrls,
                                ),
                                effectiveMode = result.preferredSubtitleMode,
                                resetToAuto = org.siloserver.silo.model.playback.seriesTrackChoiceKey(result.seriesId, contentId)
                                    ?.let { seriesTrackChoiceWriter?.subtitleResetToAuto(it) } == true,
                            )
                        } else {
                            null
                        }
                        val freshRestore = if (
                            readyMediaFileId != null &&
                            readySessionId != null
                        ) {
                            resolveOwnedTvFreshSubtitleRestore(
                                owner = loadOwner,
                                registry = loadOwners,
                                preference = restorePreference,
                                catalogTracks = catalogSubtitleTracks,
                                initialRows = result.subtitleUrls,
                                sessionId = readySessionId,
                                serverUrl = result.serverUrl,
                                hydrateDownloadedRows = {
                                    // V3 subtitle inventory is complete. A
                                    // catalog listing may enrich a row only by
                                    // stable identity; it may never add or
                                    // renumber rows, so publish the plan rows
                                    // unchanged on initial playback.
                                    ApiResult.Success(result.subtitleUrls)
                                },
                            )
                        } else {
                            TvFreshSubtitleRestoreResult(
                                rows = result.subtitleUrls,
                                resolution = resolveTvFreshSubtitlePreference(
                                    preference = restorePreference,
                                    catalogTracks = catalogSubtitleTracks,
                                    hydratedRows = result.subtitleUrls,
                                ),
                            )
                        }
                        if (freshRestore == null || !loadOwners.owns(loadOwner)) {
                            loadOwners.publishReadyIfOwned(
                                owner = loadOwner,
                                sessionId = allocatedSessionId,
                                publish = {},
                                stopStaleSession = unpublishedReadySession::rollbackIfOwned,
                            )
                            return@launch
                        }
                        val hydratedSubtitleUrls = freshRestore.rows
                        // The starter already weighed this memory against the
                        // series choice (and an Auto reset, which may have
                        // landed during its flush); only the track its plan
                        // plays may be restored onto the renderer.
                        pendingPersistedAudioFingerprint = if (initialAudioTrackIndex == null) {
                            val readyVersion = result.versions.firstOrNull { it.fileId == (result.fileId ?: readyMediaFileId) }
                            org.siloserver.silo.model.playback.localAudioMemoryForSeriesChoice(
                                localFingerprint = localTrackSelection?.audioFingerprint,
                                tracks = readyVersion?.audioTracks.orEmpty(),
                                serverOrdinal = result.playbackPlan?.selectedTracks?.audioIndex
                                    ?: readyVersion?.effectiveAudioTrackIndex,
                                resetToAuto = org.siloserver.silo.model.playback.seriesTrackChoiceKey(result.seriesId, contentId)
                                    ?.let { seriesTrackChoiceWriter?.pendingAudio(it) }
                                    ?.let { it.choice == null } == true,
                            )
                        } else {
                            null
                        }
                        val committedIdentity = result.playbackPlan
                            ?.selectedTracks
                            ?.subtitleIndex
                            ?.let { selected ->
                                hydratedSubtitleUrls.firstOrNull { it.index == selected }
                            }
                            ?.let(::tvSubtitleIdentity)
                            ?: SubtitleIdentity.Off
                        val predecessorUi = _uiState.value
                        val predecessorSubtitleContext = subtitlePlaybackContext(predecessorUi)
                        val publishedSubtitleContext = subtitlePlaybackContext(
                            predecessorUi.copy(
                                sessionId = result.sessionId,
                                playbackPlan = result.playbackPlan,
                                selectedFileId = result.fileId,
                                fileVersions = result.versions,
                                mediaFileId = result.mediaFileId,
                                position = result.sourceStartPositionSeconds,
                                subtitleUrls = hydratedSubtitleUrls,
                                // The predecessor's audio belongs to its own
                                // file (on Next Up, another episode). Left in,
                                // the first subtitle replan here sent that
                                // ordinal back as this file's audio choice,
                                // replacing the track the start resolved.
                                desiredAudioOrdinal = null,
                                desiredAudioConfirmed = false,
                                audioTracks = emptyList(),
                            ),
                        )
                        val published = loadOwners.publishReadyIfOwned(
                            owner = loadOwner,
                            sessionId = allocatedSessionId,
                            publish = {
                                trackChoiceOwner = loadTrackChoiceOwner
                                // A staged pick belongs to the playback it was
                                // made in; TV never finishes a pick through a
                                // new load, so every load drops it.
                                clearStagedSeriesWrites(keepContentId = null)
                                unpublishedTvLoadUi.register(
                                    sessionId = allocatedSessionId,
                                    state = predecessorUi,
                                    context = predecessorSubtitleContext,
                                    predecessorSessionId = predecessorUi.sessionId,
                                )
                                val transportMountNonce = nextTransportMountNonce(null)
                                val preservesNextUp = nextUpTransitionGate.expectMount(
                                    contentId = contentId,
                                    mountToken = transportMountNonce,
                                )
                                // Paired with the UI publication so the exit
                                // token is never staler than UI state — the
                                // invariant that lets exitSessionId read it
                                // first.
                                result.sessionId?.let { lastAdoptedSessionId = it }
                                if (requestRoom != null) {
                                    // A room session starts paused; only the
                                    // room's command after attach plays it.
                                    roomPreparedRevision = requestRoom.selectionRevision
                                    roomPlaying = false
                                }
                                _uiState.update {
                                    it.copy(
                                isLoading = false,
                                error = null,
                                contentId = contentId,
                                title = result.title,
                                seriesTitle = result.seriesTitle,
                                year = result.year,
                                contentType = result.contentType,
                                artworkUrl = result.artworkUrl,
                                sessionId = result.sessionId,
                                playMethod = result.playMethod,
                                playbackPlan = result.playbackPlan,
                                effectiveFrameRate = result.playbackPlanV3
                                    ?.effectiveRecipe
                                    ?.frameRate
                                    ?.takeIf { frameRate -> frameRate.isFinite() && frameRate > 0.0 }
                                    ?.toFloat(),
                                requestHeaders = result.requestHeaders,
                                delivery = result.delivery,
                                streamUrl = result.streamUrl,
                                transportMountNonce = transportMountNonce,
                                container = result.container,
                                serverUrl = result.serverUrl,
                                accessToken = result.accessToken,
                                selectedFileId = result.fileId,
                                fileVersions = result.versions,
                                selectedFileResolution = result.fileResolution,
                                videoQualities = authoritativePlaybackQualityOptions(
                                    available = result.playbackPlanV3?.availableQualities.orEmpty(),
                                    selectedLabel = sessionQualityPreference(),
                                    delivered = result.playbackPlanV3?.effectiveRecipe,
                                    source = result.playbackPlanV3?.source,
                                    reported = result.playbackPlanV3?.reportedQuality,
                                ),
                                videoQualityPreference = sessionQualityPreference(),
                                mediaFileId = result.mediaFileId,
                                startPosition = result.startPositionSeconds,
                                position = result.sourceStartPositionSeconds,
                                duration = result.durationSeconds ?: 0.0,
                                serverDuration = result.durationSeconds ?: 0.0,
                                isPaused = tvPausedWhenReady(inWatchParty = requestRoom != null),
                                subtitleUrls = hydratedSubtitleUrls,
                                preferredAudioLanguage = result.preferredAudioLanguage,
                                preferredTextLanguage = result.preferredTextLanguage,
                                preferredSubtitleMode = result.preferredSubtitleMode,
                                showForcedSubtitles = result.showForcedSubtitles,
                                preferredSubtitleTrackSignature = result.preferredSubtitleTrackSignature,
                                intro = result.intro,
                                credits = result.credits,
                                recap = result.recap,
                                preview = result.preview,
                                markerSegments = result.markerSegments,
                                chapters = result.chapters,
                                seriesId = result.seriesId,
                                seasonNumber = result.seasonNumber,
                                episodeNumber = result.episodeNumber,
                                // An in-place successor remains covered by the
                                // outgoing card until this exact mount renders.
                                nextEpisode = it.nextEpisode.takeIf { preservesNextUp },
                                stillWatchingPrompt = false,
                                showNextUp = it.showNextUp && preservesNextUp,
                                isNextUpTransitioning = preservesNextUp,
                                nextUpVideoEnded = it.nextUpVideoEnded && preservesNextUp,
                                nextUpCountdownSeconds = null,
                                nextUpCountdownTotalSeconds = NEXT_UP_COUNTDOWN_SECONDS,
                                // T11: clear the subtitle-refresh nonce on every
                                // fresh mount. It is bumped once per post-download
                                // refresh; without this reset a later backend
                                // recreation (version switch / recovery fallback)
                                // would see a stale nonce>0 and re-fire a spurious
                                // second refresh racing the primary mount effect.
                                subtitleRefreshNonce = 0,
                                    )
                                }
                                val plannedAudioOrdinal = result.playbackPlan
                                    ?.selectedTracks
                                    ?.audioIndex
                                    ?: result.audioTrackIndex
                                val plannedAudioFileId = result.fileId ?: result.mediaFileId
                                if (
                                    plannedAudioFileId != null &&
                                    plannedAudioOrdinal in result.versions
                                        .firstOrNull { it.fileId == plannedAudioFileId }
                                        ?.audioTracks
                                        .orEmpty()
                                        .indices
                                ) {
                                    primePlannedAudio(
                                        fileId = plannedAudioFileId,
                                        catalogOrdinal = plannedAudioOrdinal,
                                    )
                                }
                                subtitleTransactions.resetContent(
                                    context = publishedSubtitleContext,
                                    committedIdentity = committedIdentity,
                                )
                                freshRestore.resolution?.let { resolution ->
                                    subtitleTransactions.restoreFreshPreference(
                                        identity = resolution.identity,
                                        migrationRequired = resolution.migratedPreference != null,
                                    )
                                }
                            },
                            stopStaleSession = unpublishedReadySession::rollbackIfOwned,
                        )
                        if (!published) return@launch
                        val publishedSessionId = allocatedSessionId
                        val jointlyConfirmed = withContext(NonCancellable) {
                            sessionLifecycle.settlePendingPublicationIfCurrent(
                                sessionId = publishedSessionId,
                                confirm = true,
                                settleManager = {
                                    playbackSessionManager
                                        .confirmVideoSessionPublication(publishedSessionId)
                                },
                            ).also { confirmed ->
                                if (confirmed) {
                                    check(
                                        unpublishedReadySession
                                            .transferConfirmed(publishedSessionId),
                                    )
                                    unpublishedTvLoadUi.confirm(publishedSessionId)
                                }
                            }
                        }
                        if (!jointlyConfirmed) {
                            unpublishedReadySession.rollbackIfOwned(publishedSessionId)
                            episodeSelectionHandoffSlot.retainForRetry(
                                episodeSelectionHandoffLease,
                            )
                            fail("Playback publication could not be confirmed.")
                            return@launch
                        }
                        if (result.resolvedEpisodeSelection != null) {
                            episodeSelectionHandoffSlot.acknowledgeReady(
                                episodeSelectionHandoffLease,
                            )
                        }
                        startIntroAutoSkipObserver()
                        if (!nextUpTransitionGate.isActive) {
                            resolveNextEpisode()
                            loadOnDeckItems()
                        }
                    }
                    is VideoPlayerUiState.Error -> {
                        episodeSelectionHandoffSlot.retainForRetry(
                            episodeSelectionHandoffLease,
                        )
                        val refusalReason = result.terminalReason?.takeIf { it.isNotBlank() }
                        if (requestRoom != null && refusalReason != null) {
                            // The room decides whether everyone moves to
                            // another source; the error shows only if not.
                            _uiState.update { it.copy(isLoading = true, error = null) }
                            _roomRefusal.value = TvRoomRefusal(
                                context = requestRoom,
                                fileId = requestRoom.fileId,
                                reason = refusalReason,
                                message = result.message,
                                messageRes = result.messageRes,
                            )
                        } else if (preserveCurrentPlaybackOnFailure) {
                            failReplacementLoad(result.message, result.messageRes)
                        } else {
                            fail(result.message, result.messageRes)
                        }
                    }
                    is VideoPlayerUiState.ServerUnreachable -> {
                        episodeSelectionHandoffSlot.retainForRetry(
                            episodeSelectionHandoffLease,
                        )
                        if (preserveCurrentPlaybackOnFailure) {
                            failReplacementLoad(SERVER_UNREACHABLE_MESSAGE)
                        } else {
                            nextUpTransitionGate.cancel()
                            _uiState.update {
                                it.copy(
                                    isLoading = false,
                                    error = SERVER_UNREACHABLE_MESSAGE,
                                    serverUnreachable = true,
                                    showNextUp = false,
                                    isNextUpTransitioning = false,
                                )
                            }
                        }
                    }
                    is VideoPlayerUiState.Loading -> Unit
                }
            } catch (cancellation: CancellationException) {
                unpublishedReadySession.rollbackIfOwned()
                throw cancellation
            } catch (e: Exception) {
                unpublishedReadySession.rollbackIfOwned()
                Log.e(TAG, "Error loading content", e)
                if (generation != contentLoadGeneration || !loadOwners.owns(loadOwner)) return@launch
                episodeSelectionHandoffSlot.retainForRetry(episodeSelectionHandoffLease)
                val message = PLAYBACK_FAILED_MESSAGE
                if (preserveCurrentPlaybackOnFailure) {
                    failReplacementLoad(message)
                } else {
                    fail(message)
                }
            }
        }
    }

    /**
     * The transaction carrying a pick failed, and no newer pick is queued in
     * it: the server refused the latest pick.
     */
    private fun refuseMenuPickWhenIdle() {
        if (!subtitleTransactions.hasActiveTransaction) bufferingPicks.refused(lastMenuPick)
    }

    /**
     * A replacement load (a version switch) failed and the current version
     * keeps playing: the viewer's pick was refused.
     */
    private fun failReplacementLoad(message: String, @StringRes messageRes: Int? = null) {
        _uiState.update { failTvReplacementLoad(it, message, messageRes) }
        bufferingPicks.refused(lastVersionPick)
    }

    private fun startIntroAutoSkipObserver() {
        // Auto-skip is a local transport action: in a Watch Together room only
        // the host's transport may move position, so never auto-skip in a room
        // (a guest jump would fight the host's broadcast in a yank-back loop).
        // The observer still runs in a room — with the mode pinned to `ask` the
        // controller never seeks on its own, and the Skip Intro pill it offers
        // stays live; its Select routes through the screen's gate-checked seek.
        // A room member who chose `never` still gets the pill, which is the
        // lesser wrong: the alternative is a mode whose only implementation is
        // a seek nobody in the room is allowed to make.
        val effectiveMode = if (roomId != null) {
            flowOf(IntroSkipMode.ASK)
        } else {
            playerSettingsStore.introSkipModeFlow
        }
        // An episode may have several intros: the prompt follows the one that
        // last started, so an `always` undo survives the seek past its end.
        val introOccurrence = _uiState
            .map { it.markerTimeline.occurrenceAt(MarkerKind.Intro, it.position) }
            .distinctUntilChanged()
        introObserveJob?.cancel()
        introObserveJob = introAutoSkipController.observe(
            position = _uiState
                .map { it.position }
                .distinctUntilChanged(),
            introRange = introOccurrence,
            mode = effectiveMode,
            introKey = _uiState
                .map { state -> "${state.sessionId}:${state.selectedFileId}" }
                .distinctUntilChanged(),
            // Only reachable outside a room, where the mode is pinned to `ask`.
            onSeek = { seekToSec -> seekWithoutViewerAction(seekToSec) },
            // Filtered, not raw: isPlaying dips for a rebuffer exactly as it
            // does for a deliberate pause, and a pause that reaches the
            // controller freezes the timer. Unfiltered, a stuttering stream
            // would stall the prompt on every hiccup.
            //
            // isPaused is the viewer's own press and needs no filtering, so it
            // freezes the timer on the frame of the press rather than after
            // the grace window.
            playbackActive = _uiState
                .map { it.isPlaying && !it.isLoading }
                .settlingFalseEdges(
                    graceMillis = PLAYBACK_PAUSE_GRACE_MS,
                    deliberatelyInactive = _uiState.map { it.isPaused },
                ),
        )
    }

    private fun fail(message: String, @StringRes messageRes: Int? = null) {
        nextUpTransitionGate.cancel()
        _uiState.update {
            it.copy(
                isLoading = false,
                error = message,
                errorRes = messageRes?.let { res -> TvPlayerErrorRes(message, res) },
                showNextUp = false,
                isNextUpTransitioning = false,
            )
        }
    }

    /**
     * Preflight signaled the selected track combo can't be direct-played.
     * Fall back to a transcoded stream at the current position and show the
     * user the reason.
     */
    fun onUnsupportedPlayback(
        reason: org.siloserver.silo.common.player.Playability,
        transportMountNonce: Long,
    ) {
        val state = _uiState.value
        if (state.isNextUpTransitioning &&
            (state.isLoading || transportMountNonce != state.transportMountNonce)
        ) {
            return
        }
        if (state.sessionId == null) return

        val notice = when (reason) {
            is org.siloserver.silo.common.player.Playability.UnsupportedDvProfile ->
                "This device cannot play Dolby Vision Profile ${reason.profile}. Falling back to transcoded stream."
            is org.siloserver.silo.common.player.Playability.DvBaseLayerMetadataMismatch,
            is org.siloserver.silo.common.player.Playability.DvBaseLayerOutputMismatch,
            is org.siloserver.silo.common.player.Playability.DvBaseLayerDecoderUnavailable,
            ->
                "The Dolby Vision base-layer route could not be verified on this output. Requesting another route."
            is org.siloserver.silo.common.player.Playability.UnsupportedAudioCodec ->
                "Lossless audio not supported on this output. Falling back to transcoded stream."
            is org.siloserver.silo.common.player.Playability.UnsupportedChannelCount ->
                "Audio channel count not supported. Falling back to transcoded stream."
            is org.siloserver.silo.common.player.Playability.StartupStalled ->
                "Playback did not start cleanly on this device. Falling back to transcoded stream."
            org.siloserver.silo.common.player.Playability.Supported -> return
        }
        Log.i(TAG, "Preflight fallback: $notice")

        // A plan, first or replacement, whose transport stalled past the
        // start deadline on a link measurably slower than its bitrate lowers
        // on Auto, as a long stall would, instead of replanning the same
        // quality. A decoder or renderer failure keeps its failure path, and
        // so does a stall with no such evidence; the controller keeps it for
        // a renderer wait and for an outage, which the reconnect path owns.
        if (reason is org.siloserver.silo.common.player.Playability.StartupStalled &&
            reason.classification == "transport_stall" &&
            bufferingQualityEnabled
        ) {
            val mount = state.transportMountNonce
            val generation = contentLoadGeneration
            val lowering = bufferingQualityController.onStartDeadlineMissed {
                // The lowering came to nothing: fail this load as before, if it is still the one mounted.
                val current = _uiState.value
                if (generation == contentLoadGeneration && current.transportMountNonce == mount) {
                    Log.i(TAG, "buffering_quality start_deadline_lowering_failed action=failure_path")
                    runStartFailurePath(reason, notice, current)
                }
            }
            if (lowering) {
                Log.i(
                    TAG,
                    "buffering_quality start_deadline_missed action=lower " +
                        "observed_kbps=${playbackSessionManager.observedPlanThroughputKbps()} " +
                        "classification=${reason.classification} buffered_ahead_ms=${reason.bufferedAheadMs}",
                )
                return
            }
        }
        runStartFailurePath(reason, notice, state)
    }

    /**
     * The failure path of a plan that cannot play here: one same-route reopen
     * of a stalled transport, else a replan that reports the failure.
     */
    private fun runStartFailurePath(
        reason: org.siloserver.silo.common.player.Playability,
        notice: String,
        state: UiState,
    ) {
        if (state.sessionId == null) return
        if (reason is org.siloserver.silo.common.player.Playability.StartupStalled &&
            reason.classification == "transport_stall" &&
            state.playbackPlan != null &&
            transientNetworkRetries < MAX_TRANSIENT_NETWORK_RETRIES &&
            playbackSessionManager.recordTransportReopen()
        ) {
            transientNetworkRetries++
            reopenSameRoute(state, "client_retry=transport_reopen", endLoading = false)
            return
        }

        startProtocolV3Replan(
            classification = reason.failureClassification(),
            notice = notice,
            state = state,
            diagnostics = reason.failureDiagnostics(),
        )
    }

    private fun startProtocolV3Replan(
        classification: String,
        notice: String,
        state: UiState,
        qualityPreference: String? = null,
        diagnostics: Map<String, String> = emptyMap(),
        failedTrackType: Int? = null,
        subtitleTrackIndexOverride: Int? = null,
    ) {
        if (recoveryJob?.isActive == true) {
            // Never silently drop a user selection: queue it (newest wins) and
            // re-drive it when the in-flight recovery completes. Failure-driven
            // replans stay dropped — onPlayerError re-raises those. Embedded
            // mount failures have no player-error retry, so retain those too.
            if (classification in PlaybackSessionManager.USER_INVALIDATION_CLASSIFICATIONS ||
                classification in SUBTITLE_SELECTION_FAILURE_CLASSIFICATIONS
            ) {
                queuedRecoveryReplan = QueuedRecoveryReplan(
                    classification = classification,
                    notice = notice,
                    qualityPreference = qualityPreference,
                    subtitleTrackIndexOverride = subtitleTrackIndexOverride,
                )
            }
            return
        }
        val fileId = state.selectedFileId ?: state.mediaFileId ?: return
        val recoveryContentGeneration = contentLoadGeneration
        recoveryJob = viewModelScope.launch {
            // Locally-confirmed choice first, same reason as the transaction
            // context: the plan names the last track the server delivered, so
            // a recovery replan would otherwise undo the viewer's pick.
            val selectedAudio = state.desiredAudioOrdinal ?: selectedServerAudioTrackIndex(
                selectedPlayerOrdinal = state.audioTracks.firstOrNull { it.isSelected }?.index,
                catalogAudioTracks = state.fileVersions.firstOrNull { it.fileId == fileId }?.audioTracks,
                currentPlanTrackIndex = state.playbackPlan?.selectedTracks?.audioIndex,
            )
            val selectedSubtitle = subtitleTrackIndexOverride ?: selectedSubtitleTrackIndex(state)
            val dolbyVision = playerSettingsStore.dolbyVisionPolicySnapshot()
            coroutineContext.ensureActive()
            if (recoveryContentGeneration != contentLoadGeneration) return@launch
            // A local Dolby Vision recipe that failed on this hardware is
            // withdrawn before the replan context is built, so the server
            // plans from what this device can still execute rather than
            // handing back the route that just failed.
            capabilityDetector.transformQuarantine.noteFailure(
                classification = classification,
                activeTransformations = state.playbackPlan
                    ?.executableMedia3ClientTransformations()
                    .orEmpty(),
                failedTrackType = failedTrackType,
            )
            val forceHdrPassthrough = playerSettingsStore.forceHdrPassthroughFlow.first()
            val capabilities = capabilityDetector.detect(dolbyVision = dolbyVision, forceHdrPassthrough = forceHdrPassthrough)
            val playbackContext = capabilityDetector.detectPlaybackContext(
                formFactor = "tv",
                appVersion = BuildConfig.VERSION_NAME,
                dolbyVision = dolbyVision,
                capabilities = capabilities,
            )
            val result = playbackSessionManager.replanActiveVideoSession(
                classification = classification,
                message = notice,
                positionSeconds = state.position,
                audioTrackIndex = selectedAudio,
                subtitleTrackIndex = selectedSubtitle,
                decoderName = state.stats.videoDecoderName ?: state.stats.audioDecoderName,
                diagnostics = diagnostics,
                qualityPreference = qualityPreference,
                capabilities = capabilities,
                clientPlaybackContext = playbackContext,
            )
            // PlaybackRepository's safe-call layer may translate cancellation to an ApiResult.
            // Re-check both coroutine and content generations before any response can adopt.
            //
            // Bailing out here is not enough on its own. By the time this
            // returns, the manager has already committed and taken ownership of
            // the replacement session — so abandoning the result quietly leaves
            // a transcode running on the server that nothing will ever stop.
            // The viewer sees playback exit; the server keeps the stream slot
            // until it times out. Release it explicitly on every abandon path.
            val abandonedSessionId = (result as? ApiResult.Success)
                ?.data
                ?.let { it as? VideoSessionStartV3.Ready }
                ?.session
                ?.sessionId
            if (!isActive || recoveryContentGeneration != contentLoadGeneration) {
                // Released on the manager's own scope, which outlives this
                // screen: the whole point is to run after the reason for
                // abandoning, and this ViewModel's scope may already be gone.
                abandonedSessionId?.let(playbackSessionManager::abandonActiveVideoSessionAsync)
            }
            coroutineContext.ensureActive()
            if (recoveryContentGeneration != contentLoadGeneration) return@launch
            when (result) {
                is ApiResult.Success -> when (val decision = result.data) {
                    is VideoSessionStartV3.Ready -> {
                        val remountPosition = decision.plan.timeline
                            .replanMountPositionForSource(state.position)
                        val effectiveFileId = decision.session.mediaFileId.takeIf { it > 0 }
                            ?: decision.plan.effectiveMediaFileId
                            ?: fileId
                        val effectiveVersion = state.fileVersions.firstOrNull {
                            it.fileId == effectiveFileId
                        }
                        val effectiveResolution = effectiveVersion?.resolution
                            ?: decision.plan.effectiveRecipe.height?.let { "${it}p" }
                        val effectiveSubtitleUrls = enrichAuthoritativePlaybackSubtitleChoices(
                            catalogTracks = effectiveVersion?.subtitleTracks.orEmpty(),
                            plannedTracks = decision.session.subtitleUrls.orEmpty(),
                        )
                        val returnedSubtitleIndex = decision.plan.resolvedSelectedSubtitleIndex()
                        val returnedSubtitleIdentity = returnedSubtitleIndex
                            ?.let { index -> effectiveSubtitleUrls.singleOrNull { it.index == index } }
                            ?.let(::tvSubtitleIdentity)
                            ?: SubtitleIdentity.Off
                        val returnedAudioIndex = decision.plan.selectedTracks.audio?.index
                            ?: decision.session.audioTrackIndex
                        val effectiveContainer = decision.plan.stream.container
                            ?: effectiveVersion?.container
                            ?: state.container.takeIf { effectiveFileId == fileId }
                        val effectiveDuration = decision.session.durationSeconds ?: 0.0
                        val roomFileId = roomContext?.fileId
                        if (roomFileId != null && effectiveFileId != roomFileId) {
                            // A Watch Party plays exactly the room's file.
                            // The server keeps that pin through every replan,
                            // so this is a guard, not a fallback path.
                            withContext(NonCancellable) {
                                runCatching {
                                    playbackSessionManager.stopSession(decision.session.sessionId)
                                }
                            }
                            onReplanRequestFailed(
                                classification,
                                notice,
                                "The server offered a different version than the Watch Party's.",
                            )
                            return@launch
                        }
                        var adopted = false
                        try {
                            adopted = sessionLifecycle.adoptActiveSessionIfCurrent(
                                params = StartParams(
                                    contentId = contentId,
                                    fileId = effectiveFileId,
                                    capabilities = decision.capabilities,
                                    audioTrackIndex = returnedAudioIndex,
                                    subtitleTrackIndex = returnedSubtitleIndex ?: -1,
                                    // A renewal carries only a pick; the saved
                                    // settings are read again.
                                    qualityPreference = qualityPreference
                                        ?: qualityOverride
                                        ?: preferredQuality,
                                    startPosition = decision.session.position,
                                    clientPlaybackContext = decision.clientPlaybackContext,
                                ),
                                session = decision.session,
                                isCurrent = {
                                    recoveryContentGeneration == contentLoadGeneration &&
                                        isActive
                                },
                            )
                        } finally {
                            // Covers refusal AND cancellation while awaiting the
                            // lifecycle mutex, which throws before isCurrent runs.
                            // NonCancellable because the usual reason for being
                            // here is that this coroutine was cancelled, and a
                            // cancelled one cannot make the releasing call.
                            if (!adopted) {
                                withContext(NonCancellable) {
                                    runCatching {
                                        playbackSessionManager.stopSession(
                                            decision.session.sessionId,
                                        )
                                    }
                                }
                            }
                        }
                        if (!adopted) return@launch
                        lastAdoptedSessionId = decision.session.sessionId
                        coroutineContext.ensureActive()
                        if (recoveryContentGeneration != contentLoadGeneration) return@launch
                        val transportMountNonce = nextTypedSubtitleMountNonce(returnedSubtitleIdentity)
                        val previousFileId = _uiState.value.mediaFileId
                        _uiState.update {
                            it.copy(
                                error = null,
                                sessionId = decision.session.sessionId,
                                playMethod = decision.session.playMethod,
                                playbackPlan = decision.session.playbackPlan,
                                delivery = decision.plan.delivery,
                                streamUrl = decision.plan.stream.url,
                                transportMountNonce = transportMountNonce,
                                requestHeaders = decision.plan.stream.effectiveRequestHeaders,
                                selectedFileId = effectiveFileId,
                                mediaFileId = effectiveFileId,
                                selectedFileResolution = effectiveResolution,
                                videoQualities = authoritativePlaybackQualityOptions(
                                    available = decision.plan.availableQualities,
                                    selectedLabel = qualityPreference ?: sessionQualityPreference(),
                                    delivered = decision.plan.effectiveRecipe,
                                    source = decision.plan.source,
                                    reported = decision.plan.reportedQuality,
                                ),
                                videoQualityPreference = qualityPreference ?: sessionQualityPreference(),
                                container = effectiveContainer,
                                duration = effectiveDuration,
                                serverDuration = effectiveDuration,
                                subtitleUrls = effectiveSubtitleUrls,
                                committedSubtitleIdentity = returnedSubtitleIdentity,
                                chapters = effectiveVersion?.chapters.orEmpty().ifEmpty {
                                    if (effectiveFileId == fileId) state.chapters else emptyList()
                                },
                                startPosition = remountPosition.playerPositionSeconds,
                                position = remountPosition.sourcePositionSeconds,
                            )
                        }
                        val recoveredState = _uiState.value
                        subtitleTransactions.resetContent(
                            context = subtitlePlaybackContext(
                                state = recoveredState,
                                capabilities = decision.capabilities,
                                clientPlaybackContext = decision.clientPlaybackContext,
                            ),
                            committedIdentity = returnedSubtitleIdentity,
                        )
                        subtitleTransactions.restoreCommittedLocalMount()
                        adoptFileMarkersAfterReplan(previousFileId, effectiveVersion)
                        Log.i(
                            TAG,
                            "replan_mount restored_source_seconds=${remountPosition.sourcePositionSeconds} " +
                                "player_seconds=${remountPosition.playerPositionSeconds}",
                        )
                    }
                    is VideoSessionStartV3.Terminal -> {
                        if (classification in SUBTITLE_SELECTION_FAILURE_CLASSIFICATIONS) {
                            onReplanRequestFailed(classification, notice, decision.message)
                            return@launch
                        }
                        val failedSessionId = state.sessionId ?: return@launch
                        val terminalMessage = serverTerminalUserMessage(decision.message)
                        val terminalMessageRes = terminalUserMessageRes(decision)
                        cancelPendingCatalogSubtitle()
                        val terminalStillCurrent = sessionLifecycle.stopTerminalSessionIfCurrent(
                            expectedSessionId = failedSessionId,
                            isCurrent = {
                                recoveryContentGeneration == contentLoadGeneration &&
                                    _uiState.value.sessionId == failedSessionId
                            },
                        )
                        if (!terminalStillCurrent) {
                            return@launch
                        }
                        lastAdoptedSessionId = null
                        val refusalContext = roomContext
                        _uiState.update {
                            it.copy(
                                // In a Watch Party the room decides first
                                // whether everyone moves to another source.
                                error = terminalMessage.takeIf { refusalContext == null },
                                errorRes = terminalMessageRes
                                    ?.takeIf { refusalContext == null }
                                    ?.let { res -> TvPlayerErrorRes(terminalMessage, res) },
                                isLoading = refusalContext != null,
                                isBuffering = false,
                                isPlaying = false,
                                isPaused = true,
                                sessionId = null,
                                playMethod = null,
                                playbackPlan = null,
                                delivery = null,
                                streamUrl = null,
                            )
                        }
                        if (refusalContext != null) {
                            _roomRefusal.value = TvRoomRefusal(
                                context = refusalContext,
                                fileId = fileId,
                                reason = decision.reason,
                                message = terminalMessage,
                                messageRes = terminalMessageRes,
                            )
                        }
                    }
                    VideoSessionStartV3.ServerUpgradeRequired -> {
                        cancelPendingCatalogSubtitle()
                        if (classification in SUBTITLE_SELECTION_FAILURE_CLASSIFICATIONS) {
                            onReplanRequestFailed(classification, notice, "Server upgrade required")
                            return@launch
                        }
                        _uiState.update {
                            it.copy(
                                error = TvPlayerErrors.RECOVERY_UNSUPPORTED,
                                isLoading = false,
                                isBuffering = false,
                            )
                        }
                    }
                }
                is ApiResult.Error -> {
                    cancelPendingCatalogSubtitle()
                    if (result.isPlaybackSessionEnded()) {
                        leaveServerEndedSession()
                    } else {
                        onReplanRequestFailed(classification, notice, result.message)
                    }
                }
                is ApiResult.NetworkError -> {
                    cancelPendingCatalogSubtitle()
                    onReplanRequestFailed(classification, notice, result.exception.message, unreachable = true)
                }
            }
        }.also { job ->
            // Cancellation means a content change / reset already cleared the
            // queue; only a completed flight re-drives a queued user selection.
            job.invokeOnCompletion { cause ->
                if (cause == null) redriveQueuedRecoveryReplan()
            }
        }
    }

    private fun redriveQueuedRecoveryReplan() {
        val queued = queuedRecoveryReplan ?: return
        queuedRecoveryReplan = null
        // Current state, not the queuing-time state, so the replan carries the
        // latest committed track/quality selection.
        startProtocolV3Replan(
            classification = queued.classification,
            notice = queued.notice,
            state = _uiState.value,
            qualityPreference = queued.qualityPreference,
            subtitleTrackIndexOverride = queued.subtitleTrackIndexOverride,
        )
    }

    /**
     * A replan HTTP failure is only fatal when the replan was recovering a
     * broken route. For a user track/quality/route change the old route is
     * still mounted and healthy, so a benign 409 or a network blip must not
     * tear playback down with a fatal error banner.
     */
    private fun onReplanRequestFailed(
        classification: String,
        notice: String,
        detail: String?,
        /** The request got no response. */
        unreachable: Boolean = false,
    ) {
        if (classification in PlaybackSessionManager.USER_INVALIDATION_CLASSIFICATIONS ||
            classification in SUBTITLE_SELECTION_FAILURE_CLASSIFICATIONS
        ) {
            Log.w(TAG, "Invalidation replan failed ($classification): $detail")
            _uiState.update { it.copy(isLoading = false, isBuffering = false) }
        } else {
            Log.w(TAG, "Recovery replan failed ($classification): $notice ($detail)")
            _uiState.update {
                it.copy(
                    error = if (unreachable) SERVER_UNREACHABLE_MESSAGE else PLAYBACK_FAILED_MESSAGE,
                    isLoading = false,
                    isBuffering = false,
                )
            }
        }
    }

    private fun androidx.media3.common.PlaybackException.failureClassification(): String =
        dolbyVisionTransformClassification()?.let { return it }
            ?: when (errorCode) {
        androidx.media3.common.PlaybackException.ERROR_CODE_DECODING_FAILED,
        androidx.media3.common.PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
        androidx.media3.common.PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
        -> "decoder_failure"
        androidx.media3.common.PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        androidx.media3.common.PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
        -> "transport_stall"
        androidx.media3.common.PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "http_failure"
        androidx.media3.common.PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> "source_unavailable"
                else -> "player_failure"
            }

    private fun String?.toAudioMimeType(): String? = when (this?.trim()?.lowercase()) {
        "aac" -> androidx.media3.common.MimeTypes.AUDIO_AAC
        "ac3", "ac-3" -> androidx.media3.common.MimeTypes.AUDIO_AC3
        "eac3", "e-ac-3", "eac3_joc" -> androidx.media3.common.MimeTypes.AUDIO_E_AC3
        "truehd", "mlp" -> androidx.media3.common.MimeTypes.AUDIO_TRUEHD
        "dts" -> androidx.media3.common.MimeTypes.AUDIO_DTS
        "dts_hd", "dts-hd", "dtshd" -> androidx.media3.common.MimeTypes.AUDIO_DTS_HD
        "ac4", "ac-4" -> androidx.media3.common.MimeTypes.AUDIO_AC4
        "flac" -> androidx.media3.common.MimeTypes.AUDIO_FLAC
        "opus" -> androidx.media3.common.MimeTypes.AUDIO_OPUS
        else -> this?.takeIf { it.startsWith("audio/") }
    }

    private fun selectedSubtitleTrackIndex(state: UiState): Int? {
        // Only -1 (Off) when subtitles are GENUINELY off (no track selected).
        val selected = state.subtitleTracks.firstOrNull { it.isSelected } ?: return -1
        // A selected track that maps to a mounted server subtitle resolves to its
        // stable server index. A selected track with no mounted match (e.g. an
        // embedded CEA-608 the player discovered, not in the sidecar list) returns
        // null = keep-current, so a server-recovery transcode preserves the user's
        // subtitles instead of forcing them Off.
        return resolveMountedSubtitleRow(
            track = selected,
            subtitleTracks = state.subtitleTracks,
            mountedSubtitles = state.subtitleUrls,
        )?.index
    }

    /**
     * Mounted-transport facts from the screen's 500ms poll (the VM stays free
     * of MediaController references — the screen owns the player, the same
     * split as [onPositionChanged]). Read by [mountedSeekableSourceRange] at
     * seek-commit time. Two staleness rules keep the hint honest:
     *
     * - Reports are dropped while [transportMountGate] is suppressing: they
     *   describe the OLD MediaItem, and mapping them through the new plan's
     *   timeline offset would overstate the new transport's extent.
     * - [onTransportMountApplied] clears the facts when a mount wins, so
     *   until the next poll tick reads the new item the hint is absent and
     *   ambiguous targets fall back to a server reanchor.
     *
     * Within one mounted item a slightly stale window end only ever costs an
     * unnecessary reanchor, never a wrongly-native seek.
     */
    fun onPlayerWindowChanged(isSeekable: Boolean, windowEndPlayerMs: Long) {
        if (transportMountGate.suppressPositionReports) return
        playerWindowIsSeekable = isSeekable
        playerWindowEndPlayerMs = windowEndPlayerMs
    }

    fun onPositionChanged(positionMs: Long, durationMs: Long) {
        if (positionMs < 0) return
        // A new recovery response updates the source/player timeline before Compose can run the
        // matching backend.mount effect. Reports from the old MediaItem must not be interpreted
        // through that new timeline during this handoff window.
        if (transportMountGate.suppressPositionReports) return

        val currentState = _uiState.value
        val timeline = currentState.playbackPlan?.timeline
        // Clamp reports against the server-declared runtime, never against
        // state.duration: while a server transcode/remux is still running the
        // engine reports the short in-progress window (a few seconds of HLS
        // playlist), and using a value the engine itself wrote as the ceiling
        // turns that first short sample into a permanent downward ratchet
        // (few-second seek bar, forward seeks snapping back).
        val serverDuration = currentState.serverDuration.takeIf { it > 0.0 }
        val rawPositionSec = positionMs / 1000.0
        val rawDurationSec = durationMs / 1000.0
        val mappedPositionSec = (timeline?.sourcePositionForPlayer(rawPositionSec) ?: rawPositionSec)
            .let { position -> serverDuration?.let { position.coerceAtMost(it) } ?: position }
        val mappedDurationSec = if (currentState.playbackPlan != null) {
            // V3 forbids substituting a stream-local engine duration when the
            // plan omitted source.duration_seconds.
            serverDuration ?: 0.0
        } else if (durationMs > 0) {
            timeline?.sourcePositionForPlayer(rawDurationSec) ?: rawDurationSec
        } else {
            0.0
        }
        val nowMs = SystemClock.elapsedRealtime()
        val positionDecision = seekPresentationGuard.onPositionReport(
            positionMs = (mappedPositionSec * 1_000.0).toLong().coerceAtLeast(0L),
            nowElapsedRealtimeMs = nowMs,
        )
        if (positionDecision is SeekPositionDecision.Suppress) return
        val positionSec = (positionDecision as SeekPositionDecision.Publish).positionMs / 1000.0
        val durationSec = mappedDurationSec
        val seekWasActive = activeSeekTargetSec != null
        activeSeekTargetSec?.let { target ->
            val landed = kotlin.math.abs(positionSec - target) <= 2.0
            if (landed || nowMs - activeSeekStartedAtMs >= SEEK_SETTLE_DEADLINE_MS) {
                Log.i(TAG, "seek_settled seek_id=$activeSeekId target_source_seconds=$target actual_source_seconds=$positionSec")
                DiagnosticsPlaybackLogger.seek(
                    if (landed) DiagnosticsSeekEvent.Settled else DiagnosticsSeekEvent.SettleDeadlineReached,
                )
                activeSeekTargetSec = null
                activeSeekId = null
                sameRouteSeekRecoveryAttempted = false
            }
        }
        val previousPosition = _uiState.value.position
        _uiState.update {
            it.copy(
                position = positionSec,
                // Offline playback may learn a runtime from Media3. V3's value
                // above is always the server-declared duration or unknown (0).
                duration = maxOf(it.duration, durationSec),
            )
        }
        // Playback is progressing — restore the transient-network retry budget so
        // a later, unrelated blip gets a fresh retry instead of demoting at once.
        if (positionSec > 0 && transientNetworkRetries > 0) {
            transientNetworkRetries = 0
        }
        // F2: auto-advance / prompt when playback CROSSES the credits point —
        // only on the transition from before to after, so resuming an episode
        // whose saved position is already inside the credits doesn't instantly
        // skip to the next one (a seek into credits also won't trigger it).
        if (!seekWasActive) {
            _uiState.value.markerTimeline.upNextCreditsStart()?.let { creditsStart ->
                if (previousPosition < creditsStart && positionSec >= creditsStart) onApproachingEnd()
            }
        }
        // Forward to the lifecycle so its 10s reporter has a fresh sample.
        sessionLifecycle.reportPosition(
            positionSec = positionSec,
            durationSec = _uiState.value.duration,
            isPaused = _uiState.value.isPaused,
            expectedSessionId = _uiState.value.sessionId,
        )

        // Track B: durably record (local resume + outbox sync) for both streaming
        // and offline-download; throttled to ~every 10s of content time.
        maybeRecordPosition(positionSec, _uiState.value.duration)
    }

    fun onPlayingChanged(isPlaying: Boolean) {
        if (isPlaying) reopenedAfterOutage = false
        _uiState.update { it.copy(isPlaying = isPlaying) }
        if (!isPlaying) {
            maybeRecordPosition(_uiState.value.position, _uiState.value.duration, force = true)
        }
    }

    /**
     * A mount with audio and no video started playing. It renders no frame, so
     * playing ends its first load instead; a callback from an earlier mount is
     * ignored, as for [onFirstVideoFrameRendered].
     */
    fun onAudioOnlyPlaybackStarted(transportMountNonce: Long) {
        if (transportMountNonce != _uiState.value.transportMountNonce) return
        _uiState.update { it.copy(startedContentId = it.contentId) }
    }

    fun onFirstVideoFrameRendered(transportMountNonce: Long?) {
        if (transportMountNonce != _uiState.value.transportMountNonce) return
        hasRenderedFirstFrame = true
        _uiState.update { it.copy(startedContentId = it.contentId) }
        playbackSessionManager.reportFirstVideoFrame(_uiState.value.stats)
        if (nextUpTransitionGate.completeOnFirstFrame(transportMountNonce)) {
            _uiState.update {
                it.copy(
                    nextEpisode = null,
                    showNextUp = false,
                    isNextUpTransitioning = false,
                    nextUpVideoEnded = false,
                    nextUpCountdownSeconds = null,
                    nextUpCountdownTotalSeconds = NEXT_UP_COUNTDOWN_SECONDS,
                )
            }
            resolveNextEpisode()
            loadOnDeckItems()
        }
    }

    /**
     * An audio change has committed, so it is now the viewer's choice.
     *
     * Set here rather than when the change was requested: staging, validation,
     * adoption, mount and rollback can all fail, and a flag raised on intent
     * would carry whatever track survived the failure into the next episode as
     * though it had been chosen.
     */
    fun onAudioSelectionCommitted() {
        manualAudioSelectionApplied = true
    }

    // ---- Desired audio -----------------------------------------------------
    //
    // One generation-owned intent instead of several nullable fields racing to
    // decide the same thing. Every entry point -- the detail page's launch
    // pick, a persisted fingerprint, the HUD, the remote -- writes here, and a
    // single resolver reconciles it against each track snapshot.

    private var desiredAudioGeneration = if (initialAudioTrackIndex != null) 1L else 0L

    /** Monotonic; makes each local-selection request distinct for StateFlow. */
    private var localAudioAttempt = 0L

    /** The audio the viewer wants, as a CATALOG ordinal. */
    private var desiredAudio: DesiredAudio? = initialAudioTrackIndex?.let {
        // The detail page's pick reaches the server in the start request, but a
        // direct-play stream carrying every audio track still lets Media3 pick
        // its own default — so choosing Dutch and pressing Play mounted English.
        // Seeded as a plain value, NOT through setDesiredAudio: an init block
        // running before the flow below is declared would dereference null.
        DesiredAudio(
            generation = 1L,
            catalogOrdinal = it,
            // A fresh detail-page pick carries to the next episode; a durable
            // value seeded onto that page is a restore and must not.
            explicit = launchArgs.initialAudioPickedThisSession,
            fileId = launchArgs.preferredFileId,
        )
    }

    private val audioSelectionWatchdog = AudioSelectionWatchdog(
        scope = viewModelScope,
        onExpired = ::onAudioSelectionVerificationExpired,
    )

    private val _pendingLocalAudioSelection = MutableStateFlow<LocalAudioSelection?>(null)

    /**
     * A mounted track the screen should select on the player directly.
     *
     * The ViewModel has no player handle. The generation lets a stale
     * acknowledgement be ignored: rapid Dutch -> English -> Dutch would
     * otherwise collapse into indistinguishable requests.
     */
    val pendingLocalAudioSelection: StateFlow<LocalAudioSelection?> =
        _pendingLocalAudioSelection.asStateFlow()

    /**
     * Fork: "From audio" sources for the AI dialog, indexed by the server's
     * audio-track ordinal for the playing file. The server resolves the job's
     * source_index against that list; a remuxed or transcoded stream muxes one
     * audio track, so the ExoPlayer group ordinal was always 0 and a dubbed
     * track transcribed the original language. Falls back to the mounted
     * tracks when the catalog list is unknown.
     */
    fun aiAudioSources(): List<PlayerTrackEntry> {
        val state = _uiState.value
        val catalog = catalogAudioTracks(state)
        if (catalog.isEmpty()) return state.audioTracks
        val selected = state.desiredAudioOrdinal ?: selectedServerAudioTrackIndex(
            selectedPlayerOrdinal = state.audioTracks.firstOrNull { it.isSelected }?.index,
            catalogAudioTracks = catalog,
            currentPlanTrackIndex = state.playbackPlan?.selectedTracks?.audioIndex,
        )
        return catalog.mapIndexed { ordinal, track ->
            PlayerTrackEntry(
                index = ordinal,
                label = track.title.orEmpty(),
                language = track.language,
                isSelected = ordinal == selected,
                codecOrMime = track.codec,
                channelCount = track.channels ?: 0,
            )
        }
    }

    private fun catalogAudioTracks(state: UiState): List<AudioTrack> = state.fileVersions
        .firstOrNull { it.fileId == (state.selectedFileId ?: state.mediaFileId) }
        ?.audioTracks
        .orEmpty()

    /**
     * Records what the viewer wants. A newer intent always supersedes an older
     * one and voids any request still in flight for it, so a late match can
     * never revert a choice made since.
     */
    private fun setDesiredAudio(catalogOrdinal: Int, explicit: Boolean) {
        // An explicit choice claims the durable restore. Otherwise the pending
        // fingerprint is resolved on a later callback, mints a NEWER generation
        // for an OLDER decision, and overwrites the pick just made — generation
        // order would encode processing order, not decision order.
        if (explicit) pendingPersistedAudioFingerprint = null
        audioSelectionWatchdog.reset()
        desiredAudioGeneration += 1
        val state = _uiState.value
        desiredAudio = DesiredAudio(
            generation = desiredAudioGeneration,
            catalogOrdinal = catalogOrdinal,
            explicit = explicit,
            fileId = state.selectedFileId ?: state.mediaFileId,
        )
        _pendingLocalAudioSelection.value = null
        _uiState.update {
            it.copy(desiredAudioOrdinal = catalogOrdinal, desiredAudioConfirmed = false)
        }
        _uiState.value.audioTracks.takeIf { it.isNotEmpty() }?.let(::reconcileDesiredAudio)
    }

    /**
     * Seeds the exact source track the server planned without reconciling it
     * against track rows left over from the preceding media mount.
     */
    private fun primePlannedAudio(fileId: Int, catalogOrdinal: Int) {
        val current = desiredAudio
        if (current?.fileId == fileId &&
            (current.explicit || current.catalogOrdinal == catalogOrdinal)
        ) {
            return
        }
        audioSelectionWatchdog.reset()
        desiredAudioGeneration += 1
        desiredAudio = DesiredAudio(
            generation = desiredAudioGeneration,
            catalogOrdinal = catalogOrdinal,
            explicit = false,
            fileId = fileId,
        )
        _pendingLocalAudioSelection.value = null
        _uiState.update {
            it.copy(desiredAudioOrdinal = catalogOrdinal, desiredAudioConfirmed = false)
        }
    }

    /**
     * Drives the desired audio towards the player on every track snapshot.
     *
     * The intent is deliberately NOT cleared once read. An empty or partial
     * first callback used to discard it permanently, which reproduced the
     * original bug: choose Dutch, get English. It stays live until it is
     * satisfied or superseded, and because it stays live it doubles as the
     * re-application mechanism -- a remount installs a new MediaTrackGroup and
     * the override was bound to the old one, so a confirmed choice has to be
     * applied again rather than assumed to survive.
     */
    private fun reconcileDesiredAudio(audio: List<PlayerTrackEntry>) {
        val desired = desiredAudio ?: return
        val state = _uiState.value
        val mounted = audio.map { it.toMountedAudioTrack() }
        val requiresMountedIdentity = state.playbackPlan?.delivery == PlaybackDelivery.ORIGINAL_HTTP
        val action = reconcileDesiredAudioAction(
            desired = desired,
            activeFileId = state.selectedFileId ?: state.mediaFileId,
            catalog = catalogAudioTracks(state),
            mounted = mounted,
            selectedOrdinal = audio.firstOrNull { it.isSelected }?.index,
            planAudioOrdinal = state.playbackPlan?.selectedTracks?.audioIndex,
            requiresMountedIdentity = requiresMountedIdentity,
            delivery = state.playbackPlan?.delivery,
        )
        when (action) {
            AudioReconcileAction.None -> armOriginalAudioSelectionVerification(
                desired = desired,
                state = state,
                mounted = mounted,
                action = action,
            )

            AudioReconcileAction.DropForeignFile -> {
                audioSelectionWatchdog.reset()
                desiredAudio = null
                _pendingLocalAudioSelection.value = null
                _uiState.update {
                    it.copy(desiredAudioOrdinal = null, desiredAudioConfirmed = false)
                }
            }

            AudioReconcileAction.Confirm -> {
                audioSelectionWatchdog.resolve(desired.generation)
                // Dropped first: the collector would otherwise replay a stale
                // ordinal against a replacement backend.
                _pendingLocalAudioSelection.value = null
                confirmDesiredAudio(desired)
            }

            is AudioReconcileAction.Apply -> {
                armOriginalAudioSelectionVerification(
                    desired = desired,
                    state = state,
                    mounted = mounted,
                    action = action,
                )
                localAudioAttempt += 1
                // Reapplying is not a confirmed state: the row must stop
                // claiming the track until the player is back on it.
                if (desired.confirmed) desiredAudio = desired.copy(confirmed = false)
                _uiState.update { it.copy(desiredAudioConfirmed = false) }
                _pendingLocalAudioSelection.value = LocalAudioSelection(
                    generation = desired.generation,
                    catalogOrdinal = desired.catalogOrdinal,
                    targetOrdinal = action.targetOrdinal,
                    attempt = localAudioAttempt,
                )
            }
        }
    }

    private fun armOriginalAudioSelectionVerification(
        desired: DesiredAudio,
        state: UiState,
        mounted: List<MountedAudioTrack>,
        action: AudioReconcileAction,
    ) {
        if (shouldVerifyOriginalAudioSelection(
                desired = desired,
                delivery = state.playbackPlan?.delivery,
                planAudioOrdinal = state.playbackPlan?.selectedTracks?.audioIndex,
                mounted = mounted,
                action = action,
            )
        ) {
            audioSelectionWatchdog.arm(desired.generation)
        } else {
            audioSelectionWatchdog.resolve(desired.generation)
        }
    }

    private fun onAudioSelectionVerificationExpired(generation: Long) {
        val desired = desiredAudio?.takeIf { it.generation == generation } ?: return
        val state = _uiState.value
        val mounted = state.audioTracks.map { it.toMountedAudioTrack() }
        val action = reconcileDesiredAudioAction(
            desired = desired,
            activeFileId = state.selectedFileId ?: state.mediaFileId,
            catalog = catalogAudioTracks(state),
            mounted = mounted,
            selectedOrdinal = state.audioTracks.firstOrNull { it.isSelected }?.index,
            planAudioOrdinal = state.playbackPlan?.selectedTracks?.audioIndex,
            requiresMountedIdentity = true,
        )
        if (!shouldVerifyOriginalAudioSelection(
                desired = desired,
                delivery = state.playbackPlan?.delivery,
                planAudioOrdinal = state.playbackPlan?.selectedTracks?.audioIndex,
                mounted = mounted,
                action = action,
            )
        ) {
            audioSelectionWatchdog.resolve(generation)
            if (action == AudioReconcileAction.Confirm) {
                reconcileDesiredAudio(state.audioTracks)
            }
            return
        }

        _pendingLocalAudioSelection.value = null
        startProtocolV3Replan(
            classification = AUDIO_TRACK_SELECTION_FAILED_CLASSIFICATION,
            notice = "The requested source audio track could not be mounted and selected.",
            state = state,
        )
    }

    /** The player is on the wanted track: only now is it the viewer's choice. */
    private fun confirmDesiredAudio(desired: DesiredAudio) {
        if (desired.confirmed) return
        desiredAudio = desired.copy(confirmed = true)
        // The new track is mounted and selected: only now can its output path
        // (PCM or passthrough) be measured for rate support.
        if (roomId != null) _roomAudioTrackChanges.tryEmit(Unit)
        _uiState.update {
            it.copy(desiredAudioOrdinal = desired.catalogOrdinal, desiredAudioConfirmed = true)
        }
        // A launch or persisted intent is a restore, not a fresh decision, so it
        // must not mark the session as carrying an explicit pick for episode
        // carry-over.
        if (desired.explicit) {
            onAudioSelectionCommitted()
            persistDesiredAudio(desired.catalogOrdinal)
            // The viewer's pick is playing: now it is saved and counts as
            // this episode's pick.
            stagedAudioWrite.get()
                ?.takeIf {
                    it.catalogOrdinal == desired.catalogOrdinal && it.contentId == _uiState.value.contentId &&
                        stagedAudioWrite.compareAndSet(it, null)
                }
                ?.let(::saveSeriesAudio)
        }
    }

    private fun persistDesiredAudio(catalogOrdinal: Int) {
        val state = _uiState.value
        viewModelScope.launch {
            val context = subtitlePlaybackContext(state)
            val scope = context.writeScope ?: return@launch
            val fileId = context.mediaFileId ?: return@launch
            runCatching {
                userItemStatePort.recordTrackSelection(
                    scope = scope,
                    contentId = context.contentId,
                    fileId = fileId,
                    audioUpdate = tvAudioTrackPersistenceUpdate(
                        committedAudioTrackIndex = catalogOrdinal,
                        audioTracks = context.audioTracks,
                    ),
                    // Untouched: this path changed audio only.
                    subtitleUpdate = TrackSelectionFingerprintUpdate.Preserve,
                )
            }
        }
    }

    /**
     * The screen has shown [TvPlayerViewModel.UiState.subtitleFailureMessage].
     *
     * Cleared on acknowledgement rather than on a timer so the same failure
     * cannot be reported twice, and so a later failure with identical text
     * still surfaces.
     */
    fun onSubtitleFailureShown(shownId: Long) {
        _uiState.update {
            // Acknowledged by ID, not by text. Two failures can carry the same
            // words — a mount deadline reported twice reads identically — and
            // comparing strings would let an old acknowledgement clear a new
            // failure that merely said the same thing. Text is what the viewer
            // reads; it was never an identity.
            // The message clears; the id does NOT reset. Resetting the counter
            // let a later re-emission of an old failure manufacture id 1 again
            // and replay something already dismissed.
            if (it.subtitleFailureId == shownId) it.copy(subtitleFailureMessage = null) else it
        }
    }

    /**
     * Bounded recovery has given up and the picture is not coming back.
     *
     * The detector reports Failed exactly once and then goes quiet forever, so
     * without surfacing it the viewer is left with advancing audio over a
     * frozen frame, no message, and no reason to think pressing anything would
     * help. Telemetry recorded this; nobody told the person watching.
     */
    fun onPlaybackRecoveryExhausted() {
        _uiState.update {
            if (it.error != null) it else it.copy(
                error = TvPlayerErrors.STOPPED_RESPONDING,
            )
        }
    }

    fun onRuntimeCorrection(event: String, correctionId: String, stage: String, details: Map<String, String> = emptyMap()) {
        playbackSessionManager.reportActiveVideoEvent(
            event = event,
            diagnostics = details + mapOf("correction_id" to correctionId, "correction_stage" to stage),
        )
    }

    fun onBufferingChanged(isBuffering: Boolean) {
        // Media3 reports a player error before it goes idle, so the idle state
        // would hide what [waitOutOutage] just showed: the viewer still waits.
        _uiState.update { it.copy(isBuffering = isBuffering || outageRecoveryJob?.isActive == true) }
    }

    /** A deliberate interaction shows someone is still watching. */
    private fun resetPassOutStreak() {
        autoAdvanceCount = 0
    }

    /** Toggle user-intent pause state. Screen mirrors this to player.play/pause. */
    fun onPlayPause() {
        // In a Watch Party every toggle goes through the room; a local flip
        // here would fork this viewer from everyone else.
        if (roomId != null) return
        resetPassOutStreak()
        _uiState.update { it.copy(isPaused = !it.isPaused) }
    }

    /**
     * Idempotent pause setter. Unlike [onPlayPause] (a toggle), this sets the
     * absolute desired state, so a duplicate command can't flip the player the
     * wrong way. The screen's `state.isPaused` mirror drives
     * `mediaController.playWhenReady`.
     */
    fun setPaused(paused: Boolean) {
        _uiState.update { if (it.isPaused == paused) it else it.copy(isPaused = paused) }
    }

    /**
     * A viewer's deadband-free seek: it resets the still-watching count.
     * Every caller outside this ViewModel is a viewer's seek: scrubber,
     * chapters, intro and marker skips, a cast phone, a remote command.
     * Unlike the mobile `PlayerViewModel.seekImmediate`, which room
     * corrections use, automatic seeks here go through
     * [seekWithoutViewerAction].
     */
    fun seekImmediate(positionSec: Double) {
        resetPassOutStreak()
        seekWithoutViewerAction(positionSec)
    }

    /**
     * An automatic seek (intro auto-skip, Watch Party room seeks via
     * [applyRoomSeek]); not viewer activity. Updates `uiState.position` AND
     * emits on [seekRequests] (or re-anchors), which the screen applies to
     * the MediaController unconditionally, so sub-second corrections are
     * never swallowed.
     */
    private fun seekWithoutViewerAction(positionSec: Double) {
        cancelPendingQuickSkip()
        beginAndExecuteSeek(positionSec)
    }

    /** Explicit play or pause from a viewer: a cast phone or a remote control command. */
    fun setPausedByViewer(paused: Boolean) {
        resetPassOutStreak()
        setPaused(paused)
    }

    /**
     * Position the in-flight quick-skip burst started from, or null when no
     * burst is pending.
     *
     * Read straight after [onSkipBy] so the skip chip can report the burst
     * TOTAL — three fast forward presses coalesce into one +90s seek, and
     * labelling that "+30s" three times is the only reason the coalescing
     * looks like a dropped press rather than a deliberate one.
     */
    val quickSkipBurstOriginSec: Double?
        get() = quickSkipAccumulator.pending?.let { quickSkipOriginMs / 1_000.0 }

    /** Coalesces rapid remote/button skips into one route-aware seek. */
    fun onSkipBy(deltaSeconds: Double): Double {
        resetPassOutStreak()
        val state = _uiState.value
        val nowMs = SystemClock.elapsedRealtime()
        if (quickSkipAccumulator.pending == null) {
            quickSkipOriginMs = (state.position * 1_000.0).toLong().coerceAtLeast(0L)
            activeSeekId = ++seekSequence
            sameRouteSeekRecoveryAttempted = false
        }
        val pending = quickSkipAccumulator.addSkip(
            deltaMs = (deltaSeconds * 1_000.0).toLong(),
            enginePositionMs = (state.position * 1_000.0).toLong().coerceAtLeast(0L),
            bounds = SeekBoundsMs(
                endPositionMs = state.duration.takeIf { it > 0.0 }
                    ?.let { (it * 1_000.0).toLong() },
            ),
            nowElapsedRealtimeMs = nowMs,
        )
        armSeekPresentation(quickSkipOriginMs, pending.targetPositionMs, nowMs)
        _uiState.update { it.copy(position = pending.targetPositionMs / 1_000.0) }
        quickSkipCommitJob?.cancel()
        quickSkipCommitJob = viewModelScope.launch {
            delay((pending.commitAtElapsedRealtimeMs - SystemClock.elapsedRealtime()).coerceAtLeast(0L))
            quickSkipAccumulator.commitIfDue(
                expectedGeneration = pending.generation,
                nowElapsedRealtimeMs = SystemClock.elapsedRealtime(),
            )?.let { commit -> executeSeekTarget(commit.targetPositionMs / 1_000.0) }
        }
        return pending.targetPositionMs / 1_000.0
    }

    private fun cancelPendingQuickSkip() {
        quickSkipCommitJob?.cancel()
        quickSkipCommitJob = null
        quickSkipAccumulator.cancel()
    }

    private fun beginAndExecuteSeek(positionSec: Double) {
        val state = _uiState.value
        val target = positionSec
            .takeIf { it.isFinite() }
            ?.coerceAtLeast(0.0)
            ?.let { value -> if (state.duration > 0.0) value.coerceAtMost(state.duration) else value }
            ?: return
        val nowMs = SystemClock.elapsedRealtime()
        activeSeekId = ++seekSequence
        sameRouteSeekRecoveryAttempted = false
        armSeekPresentation(
            originSourceMs = (state.position * 1_000.0).toLong().coerceAtLeast(0L),
            targetSourceMs = (target * 1_000.0).toLong().coerceAtLeast(0L),
            nowMs = nowMs,
        )
        _uiState.update { it.copy(position = target) }
        executeSeekTarget(target)
    }

    private fun armSeekPresentation(originSourceMs: Long, targetSourceMs: Long, nowMs: Long) {
        seekPresentationGuard.begin(originSourceMs, targetSourceMs, nowMs)
        activeSeekTargetSec = targetSourceMs / 1_000.0
        activeSeekStartedAtMs = nowMs
        if (activeSeekId == null) activeSeekId = ++seekSequence
    }

    /**
     * Commits a settled seek target (source time) onto the active transport.
     *
     * Routing ladder: with no session/plan yet the target parks in
     * [pendingNativeSeekAfterMount] until the mount wins; with seek recovery
     * or a mount in flight it queues as a reanchor; otherwise
     * [decideSeek][org.siloserver.silo.common.player.seek.decideSeek] picks
     * between a native `Player.seekTo` (fed the mounted transport's proven
     * extent from [mountedSeekableSourceRange]) and a protocol-V3 server
     * reanchor. A missing plan timeline falls through to a raw player seek.
     */
    private fun executeSeekTarget(targetSourceSec: Double) {
        val state = _uiState.value
        if (transportMountGate.suppressPositionReports &&
            (state.sessionId == null || state.playbackPlan == null)
        ) {
            pendingNativeSeekAfterMount = targetSourceSec
            Log.i(
                TAG,
                "seek_commit seek_id=$activeSeekId action=queue_native_after_mount " +
                    "target_source_seconds=$targetSourceSec",
            )
            DiagnosticsPlaybackLogger.seek(DiagnosticsSeekEvent.QueuedUntilMount)
            return
        }
        if (seekRecoveryQueue.hasInFlight || transportMountGate.suppressPositionReports) {
            Log.i(
                TAG,
                "seek_commit seek_id=$activeSeekId action=queue_server_reanchor " +
                    "target_source_seconds=$targetSourceSec reason=recovery_or_mount_pending",
            )
            DiagnosticsPlaybackLogger.seek(DiagnosticsSeekEvent.QueuedBehindRecovery)
            enqueueSeekRecovery(
                TvSeekRecoveryOperation.Reanchor(
                    targetSourceSeconds = targetSourceSec,
                    reason = "recovery_or_mount_pending",
                ),
            )
            return
        }
        val mountedSeekableSourceRange = mountedSeekableSourceRange(state)
        when (
            val decision = state.playbackPlan?.timeline?.decideSeek(
                targetSourceSec,
                mountedSeekableSourceRange,
            )
        ) {
            is PlaybackSeekDecision.ServerReanchor -> {
                Log.i(
                    TAG,
                    "seek_commit seek_id=$activeSeekId action=server_reanchor " +
                        "target_source_seconds=$targetSourceSec reason=${decision.reason}",
                )
                DiagnosticsPlaybackLogger.seek(
                    DiagnosticsSeekEvent.CommittedServerReanchor,
                    reason = decision.reason.name,
                )
                startSeekReanchor(targetSourceSec, "${decision.reason}")
            }
            is PlaybackSeekDecision.NativeSeek -> {
                Log.i(
                    TAG,
                    "seek_commit seek_id=$activeSeekId action=native " +
                        "target_source_seconds=$targetSourceSec " +
                        "target_player_seconds=${decision.targetPlayerPositionSeconds}" +
                        (mountedSeekableSourceRange?.let {
                            " mounted_source_range=${it.start}..${it.endInclusive}"
                        } ?: ""),
                )
                DiagnosticsPlaybackLogger.seek(DiagnosticsSeekEvent.CommittedNative)
                seekRequestChannel.trySend(decision.targetPlayerPositionSeconds)
            }
            null -> {
                DiagnosticsPlaybackLogger.seek(DiagnosticsSeekEvent.CommittedWithoutPlan)
                seekRequestChannel.trySend(targetSourceSec)
            }
        }
    }

    /**
     * Source-time extent the currently mounted transport provably covers, or
     * null when that cannot be proven. Derived from the Media3 window the
     * screen polls: a seekable window with a known length can serve any
     * position it spans as a plain `Player.seekTo`. That covers append-only
     * (growing) HLS manifests — whose window end is the produced head — and
     * completed/indexed streams, while a growing progressive copy remux has
     * no known length and stays excluded. This is what lets quick skips ride
     * already-mounted content instead of re-anchoring through the server.
     */
    private fun mountedSeekableSourceRange(state: UiState): ClosedRange<Double>? {
        val timeline = state.playbackPlan?.timeline ?: return null
        if (!playerWindowIsSeekable || playerWindowEndPlayerMs < 0) return null
        val endSourceSec = timeline.sourcePositionForPlayer(playerWindowEndPlayerMs / 1000.0)
            ?: return null
        return timeline.timelineOffsetSeconds..endSourceSec
    }

    private fun startSeekReanchor(
        targetSourceSec: Double,
        reason: String,
        rollbackAllowed: Boolean = true,
        diagnostics: Map<String, String> = emptyMap(),
    ) {
        enqueueSeekRecovery(
            TvSeekRecoveryOperation.Reanchor(
                targetSourceSeconds = targetSourceSec,
                reason = reason,
                rollbackAllowed = rollbackAllowed,
                diagnostics = diagnostics,
            ),
        )
    }

    private fun startSeekFailureRecovery(
        targetSourceSec: Double,
        classification: String,
        notice: String,
        diagnostics: Map<String, String> = emptyMap(),
    ) {
        enqueueSeekRecovery(
            TvSeekRecoveryOperation.Failure(
                targetSourceSeconds = targetSourceSec,
                classification = classification,
                notice = notice,
                diagnostics = diagnostics,
            ),
        )
    }

    private fun enqueueSeekRecovery(operation: TvSeekRecoveryOperation) {
        val before = _uiState.value
        before.selectedFileId ?: before.mediaFileId ?: return
        val seekId = activeSeekId ?: (++seekSequence).also { activeSeekId = it }
        sameRouteSeekRecoveryAttempted = true
        transportMountGate.beginLoad()
        _uiState.update { it.copy(isBuffering = true, error = null) }
        when (val submission = seekRecoveryQueue.submit(seekId, operation)) {
            is TvSeekRecoverySubmission.Start -> {
                seekRecoveryRollbackInvalidated =
                    operation is TvSeekRecoveryOperation.Reanchor && !operation.rollbackAllowed
                viewModelScope.launch { drainSeekRecoveryQueue(submission.request) }
            }
            TvSeekRecoverySubmission.Queued -> {
                Log.i(
                    TAG,
                    "seek_recovery_queued seek_id=$seekId " +
                        "target_source_seconds=${operation.targetSourceSeconds}",
                )
                DiagnosticsPlaybackLogger.seek(DiagnosticsSeekEvent.RecoveryQueued)
            }
        }
    }

    private suspend fun drainSeekRecoveryQueue(first: TvSeekRecoveryRequest) {
        var request: TvSeekRecoveryRequest? = first
        while (request != null) {
            try {
                runSeekRecoveryRequest(request)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                Log.e(
                    TAG,
                    "Seek recovery failed unexpectedly for seek_id=${request.seekId}",
                    error,
                )
                handleSeekRecoveryFailure(request, SEEK_FAILED_MESSAGE)
            }
            request = seekRecoveryQueue.complete(request)
        }
    }

    private suspend fun runSeekRecoveryRequest(request: TvSeekRecoveryRequest) {
        val before = _uiState.value
        before.selectedFileId ?: before.mediaFileId ?: return
        when (val operation = request.operation) {
            is TvSeekRecoveryOperation.Reanchor -> {
                val operationDiagnostics = operation.diagnostics + mapOf(
                    "seek_id" to request.seekId.toString(),
                    "seek_reason" to operation.reason,
                )
                when (val result = playbackSessionManager.reanchorActiveVideoSession(
                    positionSeconds = operation.targetSourceSeconds,
                    diagnostics = operationDiagnostics,
                )) {
                    is ApiResult.Success -> {
                        if (!isCurrentSeekRecovery(request)) return
                        when (val decision = result.data) {
                            is VideoSessionStartV3.Ready -> adoptSeekRecoveryDecision(
                                request = request,
                                decision = decision,
                                before = before,
                                requestedSourcePosition = operation.targetSourceSeconds,
                            )
                            is VideoSessionStartV3.Terminal -> performPinnedSeekFailureRecovery(
                                request = request,
                                before = before,
                                classification = "seek_reanchor_terminal",
                                notice = decision.message,
                                diagnostics = operationDiagnostics + mapOf(
                                    "reanchor_terminal_reason" to decision.reason,
                                ),
                            )
                            VideoSessionStartV3.ServerUpgradeRequired -> handleSeekRecoveryFailure(
                                request,
                                TvPlayerErrors.SEEK_UNSUPPORTED,
                            )
                        }
                    }
                    is ApiResult.Error -> {
                        if (!isCurrentSeekRecovery(request)) return
                        if (result.error == "seek_reanchor_not_supported") {
                            handleSeekRecoveryFailure(
                                request,
                                TvPlayerErrors.SEEK_UNSUPPORTED,
                            )
                        } else {
                            performPinnedSeekFailureRecovery(
                                request = request,
                                before = before,
                                classification = "seek_reanchor_failed",
                                notice = result.message,
                                diagnostics = operationDiagnostics + mapOf("reanchor_error" to result.error),
                            )
                        }
                    }
                    is ApiResult.NetworkError -> {
                        if (!isCurrentSeekRecovery(request)) return
                        performPinnedSeekFailureRecovery(
                            request = request,
                            before = before,
                            classification = "seek_reanchor_network_failure",
                            notice = result.exception.message ?: "Seek re-anchor request failed.",
                            diagnostics = operationDiagnostics,
                        )
                    }
                }
            }
            is TvSeekRecoveryOperation.Failure -> performPinnedSeekFailureRecovery(
                request = request,
                before = before,
                classification = operation.classification,
                notice = operation.notice,
                diagnostics = operation.diagnostics + ("seek_id" to request.seekId.toString()),
            )
        }
    }

    private suspend fun performPinnedSeekFailureRecovery(
        request: TvSeekRecoveryRequest,
        before: UiState,
        classification: String,
        notice: String,
        diagnostics: Map<String, String>,
    ) {
        if (!isCurrentSeekRecovery(request)) return
        val targetSourceSec = request.operation.targetSourceSeconds
        when (val result = playbackSessionManager.recoverActiveVideoSessionAfterSeek(
            positionSeconds = targetSourceSec,
            classification = classification,
            message = notice,
            diagnostics = diagnostics,
        )) {
            is ApiResult.Success -> {
                if (!isCurrentSeekRecovery(request)) return
                when (val decision = result.data) {
                    is VideoSessionStartV3.Ready -> adoptSeekRecoveryDecision(
                        request = request,
                        decision = decision,
                        before = before,
                        requestedSourcePosition = targetSourceSec,
                    )
                    is VideoSessionStartV3.Terminal -> {
                        Log.w(TAG, "Seek recovery ended: ${decision.reason}: ${decision.message}")
                        handleSeekRecoveryFailure(request, SEEK_FAILED_MESSAGE)
                    }
                    VideoSessionStartV3.ServerUpgradeRequired -> handleSeekRecoveryFailure(
                        request,
                        TvPlayerErrors.SEEK_UNSUPPORTED,
                    )
                }
            }
            is ApiResult.Error -> {
                if (!isCurrentSeekRecovery(request)) return
                val message = if (result.error == "seek_reanchor_not_supported") {
                    TvPlayerErrors.SEEK_UNSUPPORTED
                } else {
                    SEEK_FAILED_MESSAGE.also { Log.w(TAG, "Seek recovery failed: ${result.message}") }
                }
                handleSeekRecoveryFailure(request, message)
            }
            is ApiResult.NetworkError -> {
                if (!isCurrentSeekRecovery(request)) return
                Log.w(TAG, "Seek recovery failed: ${result.exception.message}")
                handleSeekRecoveryFailure(request, SEEK_FAILED_MESSAGE)
            }
        }
    }

    private suspend fun adoptSeekRecoveryDecision(
        request: TvSeekRecoveryRequest,
        decision: VideoSessionStartV3.Ready,
        before: UiState,
        requestedSourcePosition: Double,
    ) {
        if (!isCurrentSeekRecovery(request)) return
        val fileId = before.selectedFileId ?: before.mediaFileId ?: return
        val expectedFileId = before.playbackPlan?.effectiveMediaFileId ?: fileId
        val actualFileId = decision.plan.effectiveMediaFileId ?: expectedFileId
        if (actualFileId != expectedFileId) {
            handleSeekRecoveryFailure(
                request,
                TvPlayerErrors.SEEK_CHANGED_VERSION,
            )
            return
        }
        val sourcePosition = decision.plan.timeline.sourceStartSeconds
            .takeIf { it.isFinite() && it >= 0.0 }
            ?: requestedSourcePosition
        val version = before.fileVersions.firstOrNull { it.fileId == actualFileId }
        val effectiveSubtitleUrls = enrichAuthoritativePlaybackSubtitleChoices(
            catalogTracks = version?.subtitleTracks.orEmpty(),
            plannedTracks = decision.session.subtitleUrls.orEmpty(),
        )
        val returnedSubtitleIndex = decision.plan.resolvedSelectedSubtitleIndex()
        val returnedSubtitleIdentity = returnedSubtitleIndex
            ?.let { index -> effectiveSubtitleUrls.singleOrNull { it.index == index } }
            ?.let(::tvSubtitleIdentity)
            ?: SubtitleIdentity.Off
        val returnedAudioIndex = decision.plan.selectedTracks.audio?.index
            ?: decision.session.audioTrackIndex
        // A renewal carries only a pick; the saved settings are read again.
        val committedQualityPreference = qualityOverride ?: preferredQuality
        seekRecoveryRollbackInvalidated = false
        if (!isCurrentSeekRecovery(request)) return
        val adopted = sessionLifecycle.adoptActiveSessionIfCurrent(
            params = StartParams(
                contentId = contentId,
                fileId = actualFileId,
                capabilities = decision.capabilities,
                audioTrackIndex = returnedAudioIndex,
                subtitleTrackIndex = returnedSubtitleIndex ?: -1,
                qualityPreference = committedQualityPreference,
                startPosition = sourcePosition,
                clientPlaybackContext = decision.clientPlaybackContext,
            ),
            session = decision.session.copy(subtitleUrls = effectiveSubtitleUrls),
            isCurrent = { isCurrentSeekRecovery(request) },
        )
        // Deliberately no stop on refusal. A seek re-anchor is validated to
        // reuse the SAME session id — the manager rejects any response that
        // changes it — so this id names the session still playing, not a
        // disposable candidate. Refusal normally means a newer seek was queued,
        // and that seek needs this very session as its base; stopping it here
        // left the manager with no active attempt to re-anchor.
        if (!adopted) return
        lastAdoptedSessionId = decision.session.sessionId
        if (!isCurrentSeekRecovery(request)) return
        val transportMountNonce = nextTypedSubtitleMountNonce(returnedSubtitleIdentity)
        _uiState.update {
            if (!isCurrentSeekRecovery(request)) return@update it
            it.copy(
                error = null,
                isBuffering = false,
                sessionId = decision.session.sessionId,
                playMethod = decision.session.playMethod,
                playbackPlan = decision.session.playbackPlan,
                delivery = decision.plan.delivery,
                streamUrl = decision.plan.stream.url,
                transportMountNonce = transportMountNonce,
                requestHeaders = decision.plan.stream.effectiveRequestHeaders,
                container = decision.plan.stream.container ?: it.container,
                // A recovered seek can land on another recipe (an HEVC encode
                // falling back to H.264), so the lit row follows its plan.
                videoQualities = authoritativePlaybackQualityOptions(
                    available = decision.plan.availableQualities,
                    selectedLabel = it.videoQualityPreference ?: sessionQualityPreference(),
                    delivered = decision.plan.effectiveRecipe,
                    source = decision.plan.source,
                    reported = decision.plan.reportedQuality,
                ),
                startPosition = decision.plan.timeline.playerStartSeconds,
                position = sourcePosition,
                subtitleUrls = effectiveSubtitleUrls,
                committedSubtitleIdentity = returnedSubtitleIdentity,
            )
        }
        val recoveredState = _uiState.value
        subtitleTransactions.resetContent(
            context = subtitlePlaybackContext(
                state = recoveredState,
                capabilities = decision.capabilities,
                clientPlaybackContext = decision.clientPlaybackContext,
            ),
            committedIdentity = returnedSubtitleIdentity,
        )
        subtitleTransactions.restoreCommittedLocalMount()
    }

    private fun isCurrentSeekRecovery(request: TvSeekRecoveryRequest): Boolean =
        seekRecoveryQueue.isCurrent(request, activeSeekId)

    private fun handleSeekRecoveryFailure(
        request: TvSeekRecoveryRequest,
        message: String,
    ) {
        if (!isCurrentSeekRecovery(request)) return
        val reanchor = request.operation as? TvSeekRecoveryOperation.Reanchor
        if (reanchor != null && reanchor.rollbackAllowed && !seekRecoveryRollbackInvalidated) {
            // Re-anchor requests are transactional while the old Media3 item
            // remains healthy. If neither exact nor pinned server recovery can
            // produce a replacement, cancel the optimistic playhead and keep
            // playing the mounted item instead of showing a fatal error.
            val rollback = seekPresentationGuard.cancel()?.originPositionMs
                ?.div(1_000.0)
                ?: _uiState.value.position
            activeSeekTargetSec = null
            activeSeekId = null
            sameRouteSeekRecoveryAttempted = false
            seekRecoveryRollbackInvalidated = false
            transportMountGate.reset()
            Log.w(TAG, "seek_recovery action=rollback message=$message")
            DiagnosticsPlaybackLogger.seek(DiagnosticsSeekEvent.RolledBack)
            _uiState.update {
                it.copy(
                    position = rollback,
                    isBuffering = false,
                    error = null,
                )
            }
            return
        }
        DiagnosticsPlaybackLogger.seek(DiagnosticsSeekEvent.Failed)
        _uiState.update { it.copy(isBuffering = false, error = message) }
    }

    // ---- Watch Party --------------------------------------------------------------

    /**
     * Prepare the room's playback epoch: its exact content, file and position,
     * paused. A new selection revision or file cancels the old epoch; the same
     * epoch again is a no-op. Only the room's commands play it.
     */
    fun loadRoomPlayback(context: WatchPartyPlaybackContext) {
        if (roomId == null || context.roomId != roomId) return
        val previous = roomContext
        if (previous != null &&
            previous.selectionRevision == context.selectionRevision &&
            previous.fileId == context.fileId
        ) {
            return
        }
        roomContext = context
        _roomRefusal.value = null
        // The old epoch is over: hold its picture still until the new one is ready.
        roomPlaying = false
        setPaused(true)
        val contentChanged = context.contentId != contentId
        val outgoingSessionId = exitSessionId.takeIf { previous != null && contentChanged }
        roomLoadJob?.cancel()
        roomLoadJob = viewModelScope.launch {
            if (outgoingSessionId != null) {
                // Another title: finish the outgoing one (final position,
                // committed tracks, server stop) the way an episode change does.
                finishCurrentEpisodeForNextUp(outgoingSessionId)
                lastAdoptedSessionId = null
            }
            if (roomContext !== context) return@launch
            if (contentChanged) resetForRoomContent(context.contentId)
            preferredFileId = context.fileId
            loadContent(
                startPositionOverride = context.positionSeconds,
                preferredFileIdOverride = context.fileId,
                suppressResumeRewind = true,
            )
        }
        publishRoomObservation()
    }

    private fun resetForRoomContent(newContentId: String) {
        contentId = newContentId
        preferredQuality = null
        qualityOverride = null
        initialAudioTrackIndex = null
        pendingInitialSubtitleIndex = null
        pendingInitialSubtitleAutoResolved = false
        pendingInitialSubtitleAttempts = 0
        autoTextSubtitleSelectionAttempted = false
        autoAdvanceHandled = false
        reachedCreditsOrEnd = false
        pendingApproachingEndVideoEnded = null
        episodeSelectionHandoffSlot.invalidate()
        _uiState.update { it.copy(contentId = newContentId, nextEpisode = null) }
    }

    /** A room seek. Maps onto the mounted stream or re-anchors; never user intent. */
    fun applyRoomSeek(sourceSeconds: Double) {
        if (roomId == null || !sourceSeconds.isFinite()) return
        seekWithoutViewerAction(sourceSeconds.coerceAtLeast(0.0))
        publishRoomObservation()
    }

    /** The room's play state. A local hold keeps this viewer paused until it clears. */
    fun applyRoomPlaying(playing: Boolean) {
        if (roomId == null) return
        roomPlaying = playing
        setPaused(!playing || roomHolds.isNotEmpty())
    }

    /** The room's temporary correction rate, or null for exactly 1x. */
    fun setRoomCorrectionRate(rate: Double?) {
        if (roomId == null) return
        _roomCorrectionRate.value = rate?.takeIf { it.isFinite() && it > 0.0 }
    }

    /**
     * Whether [sourceSeconds] is reachable without rebuilding the stream: a
     * plain native seek of the mounted item, no further ahead than the
     * buffered position, and behind the playhead anywhere in a seekable
     * window (otherwise within a second). Anything uncertain answers false.
     */
    fun isRoomPositionBuffered(sourceSeconds: Double): Boolean {
        if (roomId == null || !sourceSeconds.isFinite() || sourceSeconds < 0.0) return false
        val sample = roomPlayerSample ?: return false
        if (SystemClock.elapsedRealtime() - sample.sampledAtMs > ROOM_SAMPLE_MAX_AGE_MS) return false
        if (sample.sampledAtMs <= roomMountAppliedAtMs) return false
        if (sample.playbackState != androidx.media3.common.Player.STATE_READY &&
            sample.playbackState != androidx.media3.common.Player.STATE_BUFFERING
        ) {
            return false
        }
        val state = _uiState.value
        if (state.error != null || roomSeekPending(state)) return false
        val timeline = state.playbackPlan?.timeline
        val targetPlayerSeconds = if (timeline != null) {
            val decision = timeline.decideSeek(sourceSeconds, mountedSeekableSourceRange(state))
            (decision as? PlaybackSeekDecision.NativeSeek)?.targetPlayerPositionSeconds ?: return false
        } else {
            sourceSeconds
        }
        return tvRoomPositionBuffered(
            targetPlayerSeconds = targetPlayerSeconds,
            currentPlayerSeconds = sample.positionMs.coerceAtLeast(0L) / 1000.0,
            bufferedPlayerSeconds = sample.bufferedPositionMs.coerceAtLeast(0L) / 1000.0,
            seekableBehindPlayhead = playerWindowIsSeekable,
        )
    }

    /** What Media3 reports right now. Drives [roomObservation]. */
    fun onRoomPlayerSample(
        positionMs: Long,
        bufferedPositionMs: Long,
        playWhenReady: Boolean,
        isPlaying: Boolean,
        playbackState: Int,
        suppressed: Boolean,
        playbackSpeed: Double? = null,
    ) {
        if (roomId == null) return
        roomPlayerSample = TvRoomPlayerSample(
            positionMs = positionMs,
            bufferedPositionMs = bufferedPositionMs,
            playWhenReady = playWhenReady,
            isPlaying = isPlaying,
            playbackState = playbackState,
            suppressed = suppressed,
            sampledAtMs = SystemClock.elapsedRealtime(),
            playbackSpeed = playbackSpeed?.takeIf { it.isFinite() && it > 0.0 },
        )
        publishRoomObservation()
    }

    /** A mounted player position in source time, or null while a new mount takes over. */
    fun roomSourcePositionForPlayer(playerPositionMs: Long): Double? {
        if (transportMountGate.suppressPositionReports) return null
        val seconds = playerPositionMs.coerceAtLeast(0L) / 1000.0
        return _uiState.value.playbackPlan?.timeline?.sourcePositionForPlayer(seconds) ?: seconds
    }

    /** Playback is held locally for at least one reason. */
    val isRoomHeld: Boolean get() = roomHolds.isNotEmpty()

    /** Hold playback locally (background, audio focus, sleep timer). The room is not asked. */
    fun holdRoomPlayback(hold: TvRoomHold) {
        if (roomId == null) return
        roomHolds.add(hold)
        setPaused(true)
        publishRoomObservation()
    }

    /** Clear one hold; with none left, follow the room again. */
    fun releaseRoomPlayback(hold: TvRoomHold) {
        if (roomId == null || !roomHolds.remove(hold)) return
        if (roomHolds.isEmpty()) setPaused(!roomPlaying)
        publishRoomObservation()
    }

    /** The viewer pressed play: the holds they can clear themselves go away. */
    fun releaseUserRoomHolds() {
        if (roomId == null) return
        val focus = roomHolds.remove(TvRoomHold.AudioFocus)
        val sleep = roomHolds.remove(TvRoomHold.SleepTimer)
        if (!focus && !sleep) return
        if (roomHolds.isEmpty()) setPaused(!roomPlaying)
        publishRoomObservation()
    }

    /** Play pressed while held and the room is playing: resume here, ask nothing. */
    fun resumeRoomPlaybackLocally() {
        if (roomId == null) return
        roomHolds.remove(TvRoomHold.AudioFocus)
        roomHolds.remove(TvRoomHold.SleepTimer)
        roomPlaying = true
        if (roomHolds.isEmpty()) setPaused(false)
        publishRoomObservation()
    }

    /**
     * The room answered a refusal. When it moved everyone to another source a
     * new context follows; otherwise the refusal becomes this player's error.
     * No other file is ever chosen locally.
     */
    fun onRoomRefusalHandled(refusal: TvRoomRefusal, tookOver: Boolean) {
        if (_roomRefusal.value != refusal) return
        _roomRefusal.value = null
        if (tookOver) {
            viewModelScope.launch {
                delay(ROOM_FALLBACK_WAIT_MS)
                if (roomContext?.selectionRevision == refusal.context.selectionRevision &&
                    _uiState.value.streamUrl == null && _uiState.value.error == null
                ) {
                    fail(refusal.message, refusal.messageRes)
                }
            }
            return
        }
        if (roomContext?.selectionRevision != refusal.context.selectionRevision) return
        fail(refusal.message, refusal.messageRes)
    }

    /** A short in-player message (Watch Party notices share the remote-message toast). */
    fun showPlayerMessage(text: String, durationMs: Long = 5_000L, @StringRes textRes: Int? = null) {
        if (text.isBlank()) return
        _remoteMessage.value = RemoteMessage(++remoteMessageCounter, text, durationMs, textRes)
    }

    private fun roomSeekPending(state: UiState): Boolean =
        transportMountGate.suppressPositionReports ||
            state.isLoading ||
            state.streamUrl == null ||
            activeSeekTargetSec != null ||
            quickSkipAccumulator.pending != null ||
            pendingNativeSeekAfterMount != null ||
            seekRecoveryQueue.hasInFlight ||
            recoveryJob?.isActive == true

    private fun publishRoomObservation() {
        if (roomId == null) return
        val state = _uiState.value
        val sample = roomPlayerSample
        val hasMedia = state.streamUrl != null && state.error == null
        // Engine truth mapped to source time. While a new mount takes over, the
        // old item's position cannot be mapped through the new timeline, so
        // the last known value stands (and seekPending says it is not a decision).
        val sampled = sample != null && hasMedia && !transportMountGate.suppressPositionReports &&
            sample.sampledAtMs > roomMountAppliedAtMs
        val position = if (sample != null && sampled) {
            val raw = sample.positionMs.coerceAtLeast(0L) / 1000.0
            val mapped = state.playbackPlan?.timeline?.sourcePositionForPlayer(raw) ?: raw
            state.serverDuration.takeIf { it > 0.0 }?.let(mapped::coerceAtMost) ?: mapped
        } else {
            _roomObservation.value.sourcePositionSeconds
        }
        _roomObservation.value = RoomPlayerObservation(
            sessionId = state.sessionId?.takeIf { hasMedia },
            selectionRevision = roomPreparedRevision,
            sourcePositionSeconds = position,
            durationSeconds = state.duration,
            playWhenReady = sample?.playWhenReady ?: false,
            isPlaying = sample?.isPlaying ?: false,
            state = tvRoomPlayerState(sample?.playbackState, hasMedia),
            seekPending = roomSeekPending(state),
            suspended = roomHolds.isNotEmpty() || sample?.suppressed == true,
            sampledAtMs = sample?.sampledAtMs?.takeIf { sampled },
            playbackSpeed = sample?.playbackSpeed?.takeIf { sampled },
            mountGeneration = roomMountGeneration,
        )
    }

    // ---- Remote-control adapters (TvPlaybackRealtimeController calls these) ----
    /** True while this player belongs to a Watch Party: the room owns transport. */
    val inWatchParty: Boolean get() = roomId != null

    fun remotePause() = setPausedByViewer(true)
    fun remoteUnpause() = setPausedByViewer(false)
    fun remoteTogglePlayPause() = onPlayPause()
    fun remoteSeek(positionSeconds: Double) = seekImmediate(positionSeconds)
    fun remoteStop(notice: String? = null) { _remoteStopRequests.tryEmit(notice) }

    /**
     * The server ended this session for good: an administrator stopped it
     * while the control socket could not reach this player. Leave the way a
     * remote stop does rather than renewing into a fresh session.
     */
    private fun leaveServerEndedSession() {
        Log.i(TAG, "The server ended this playback session; leaving playback")
        remoteStop(ADMIN_ENDED_PLAYBACK_NOTICE)
    }
    fun remoteDisplayMessage(message: String) {
        _remoteMessage.value = RemoteMessage(++remoteMessageCounter, message)
    }
    fun clearRemoteMessage() { _remoteMessage.value = null }

    // Remote track commands resolve player ordinals to stable server/typed
    // identities, then enter the same transactional replan path as the HUD.
    // An unresolved command remains latched until a later track snapshot can
    // resolve it; only an explicit subtitle -1 means Off.
    fun remoteSelectAudio(index: Int) {
        val state = _uiState.value
        val selected = resolveTvRemoteAudioIntent(
            playerOrdinal = index,
            audioTracks = state.fileVersions
                .firstOrNull { it.fileId == (state.selectedFileId ?: state.mediaFileId) }
                ?.audioTracks
                .orEmpty(),
        )
        if (selected != null) {
            _pendingRemoteAudioIndex.compareAndSet(index, null)
            // Through the same intent as every other entry point. Going straight
            // to a replan left an older launch/persisted/HUD intent authoritative,
            // and it would reapply itself afterwards and undo the remote pick.
            // Staged before the switch starts: a mounted track can be
            // confirmed during setDesiredAudio itself.
            rememberSeriesAudioChoice(state, selected)
            setDesiredAudio(selected, explicit = true)
            val switchesLocally = mountedAudioFor(
                catalog = catalogAudioTracks(state),
                catalogOrdinal = selected,
                mounted = state.audioTracks.map { it.toMountedAudioTrack() },
                delivery = state.playbackPlan?.delivery,
                planAudioOrdinal = state.playbackPlan?.selectedTracks?.audioIndex,
            ) != null
            if (switchesLocally) return
            playbackMutationFence.beginReplan()
            launchSubtitleTransaction(state) {
                subtitleTransactions.selectAudio(selected)
            }
        } else {
            _pendingRemoteAudioIndex.value = index
        }
    }

    fun remoteSelectSubtitle(index: Int) {
        val state = _uiState.value
        val identity = resolveTvRemoteSubtitleIntent(
            playerOrdinal = index,
            subtitleTracks = state.subtitleTracks,
            subtitleRows = state.subtitleUrls,
        )
        if (identity != null) {
            _pendingRemoteSubtitleIndex.compareAndSet(index, null)
            subtitleChoiceGeneration += 1
            rememberSeriesSubtitleChoice(identity)
            playbackMutationFence.beginReplan()
            launchSubtitleTransaction(_uiState.value) {
                subtitleTransactions.select(identity)
            }
        } else {
            _pendingRemoteSubtitleIndex.value = index
        }
    }

    private fun retryPendingRemoteTrackIntents() {
        _pendingRemoteAudioIndex.value?.let(::remoteSelectAudio)
        _pendingRemoteSubtitleIndex.value?.let(::remoteSelectSubtitle)
    }

    private val markerReconciliationFence = MarkerReconciliationFence()
    private var markerReconcileJob: Job? = null

    /**
     * Read the playing file's markers again: after every control connection,
     * including on-demand mode, and after a replan lands on another file.
     * Naming the file makes the server fill that version's on-demand markers.
     */
    fun reconcileMarkers(expectedSessionId: String) {
        val state = _uiState.value
        val fileId = state.mediaFileId ?: return
        if (state.sessionId != expectedSessionId) return
        // The same library the start used: a room may have moved to another library's title.
        val libraryId = roomContext?.libraryId ?: launchArgs.libraryId
        val ticket = markerReconciliationFence.begin()
        markerReconcileJob?.cancel()
        markerReconcileJob = viewModelScope.launch {
            val owner = catalogRepository.captureWatchAuthority() ?: return@launch
            val detail = (catalogRepository.getWatchDetail(state.contentId, owner, libraryId, fileId) as? ApiResult.Success)
                ?.data ?: return@launch
            if (!catalogRepository.isWatchAuthorityCurrent(owner)) return@launch
            val current = _uiState.value
            if (!markerReconciliationFence.isCurrent(ticket) || current.sessionId != expectedSessionId ||
                current.contentId != state.contentId || current.mediaFileId != fileId) return@launch
            val version = detail.versions.firstOrNull { it.fileId == fileId } ?: return@launch
            applyUpdatedMarkers(version.intro, version.credits,
                version.recap, version.preview, version.markerSegments)
        }
    }

    /**
     * A `markers_updated` event. The server also sends a file's update to
     * sessions that requested that file but play another, so check the file.
     */
    fun applyMarkersUpdate(update: PlaybackMarkersUpdate) {
        if (update.fileId != null && update.fileId != _uiState.value.mediaFileId) return
        applyUpdatedMarkers(update.intro, update.credits, update.recap, update.preview, update.markerSegments)
    }

    /** A replan that lands on another file takes that file's markers, then reads them again. */
    private fun adoptFileMarkersAfterReplan(previousFileId: Int?, version: FileVersion?) {
        val state = _uiState.value
        if (state.mediaFileId == previousFileId) return
        applyUpdatedMarkers(version?.intro, version?.credits, version?.recap, version?.preview, version?.markerSegments)
        state.sessionId?.let(::reconcileMarkers)
    }

    /**
     * Adopt the playing file's marker ranges (a `markers_updated` event or a
     * reconcile read). Skip-intro and the credits-based F2 trigger read these
     * from UiState, so the update takes effect immediately; `null` clears a
     * marker the server dropped.
     */
    private fun applyUpdatedMarkers(
        intro: TimeRange?,
        credits: TimeRange?,
        recap: TimeRange?,
        preview: TimeRange?,
        markerSegments: List<MarkerSegment>?,
    ) {
        markerReconciliationFence.invalidate()
        _uiState.update {
            it.copy(intro = intro, credits = credits, recap = recap, preview = preview, markerSegments = markerSegments)
        }
    }

    // ---- Next-episode auto-advance (F2) ----

    /**
     * Resolve the next episode for this item (no-op for movies). Pools the
     * current season's episodes plus the next REGULAR season's (specials are
     * excluded, per the resolver's playback-order contract) and finds the
     * immediate next via [nextEpisodeAfter].
     */
    private var onDeckGeneration = 0L

    /**
     * Populates the Up Next overlay's On Deck row (tvOS
     * `loadNextUpOnDeckItems` and phone parity): home continue-watching pools,
     * minus the current item and its series. A Watch Party never shows it:
     * the room decides what plays.
     */
    private fun loadOnDeckItems() {
        val run = ++onDeckGeneration
        val repository = sectionRepository ?: return
        val state = _uiState.value
        val forContentId = state.contentId
        val currentSeriesId = state.seriesId
        _uiState.update { it.copy(onDeckItems = emptyList()) }
        if (roomId != null) return
        // Not keyed on the session: a startup replan swaps it for the same
        // item without reloading, and the row doesn't depend on it.
        fun stillCurrent() = run == onDeckGeneration && _uiState.value.contentId == forContentId
        viewModelScope.launch {
            val owner = repository.captureHomeAuthority() ?: return@launch
            repository.loadScopedHomeSections(owner, ::stillCurrent) { sections ->
                val pool = sections.toTvOnDeckItems(forContentId, currentSeriesId)
                _uiState.update { if (!stillCurrent()) it else it.copy(onDeckItems = pool) }
            }
        }
    }

    /**
     * An On Deck pick leaves this player for another item: an explicit choice,
     * so stop the countdown before navigation replaces the screen and its
     * disposal finishes the session as any exit does.
     */
    fun onOnDeckItemChosen() {
        nextUpCountdownJob?.cancel()
        nextUpCountdownJob = null
        _uiState.update { it.copy(nextUpCountdownSeconds = null) }
    }

    private fun resolveNextEpisode() {
        // The room owns what plays next; nothing here may offer it.
        if (roomId != null) return
        if (shufflePlayback != null) {
            resolveShuffleNext()
            return
        }
        val state = _uiState.value
        val seriesId = state.seriesId ?: return
        val curSeason = state.seasonNumber ?: return
        val curEpisode = state.episodeNumber ?: return
        val forContentId = state.contentId
        resolveNextEpisodeJob?.cancel()
        resolveNextEpisodeJob = viewModelScope.launch {
            // Current season MUST load — otherwise the pool could contain only
            // the next season and we'd skip the rest of this one. Bail (no
            // auto-advance) on failure.
            val currentSeasonEpisodes =
                (catalogRepository.getEpisodes(seriesId, curSeason, libraryId = launchArgs.libraryId) as? ApiResult.Success)
                    ?.data?.episodes ?: return@launch
            val pool = currentSeasonEpisodes.toMutableList()
            // Next regular season is best-effort — its failure just means no
            // cross-season rollover, never a skip within the current season.
            val nextRegularSeason = (catalogRepository.getSeasons(seriesId, libraryId = launchArgs.libraryId) as? ApiResult.Success)
                ?.data?.seasons
                ?.filter { !it.isSpecials && it.seasonNumber > curSeason }
                ?.minByOrNull { it.seasonNumber }
            if (nextRegularSeason != null) {
                (catalogRepository.getEpisodes(seriesId, nextRegularSeason.seasonNumber, libraryId = launchArgs.libraryId) as? ApiResult.Success)
                    ?.data?.episodes?.let { pool += it }
            }
            val next = nextEpisodeAfter(pool, curSeason, curEpisode) ?: return@launch
            val nextState = NextEpisodeState(
                contentId = next.contentId,
                seasonNumber = next.seasonNumber,
                episodeNumber = next.episodeNumber,
                title = next.title,
                stillUrl = next.stillUrl,
                stillIsEpisodeStill = next.stillIsEpisodeStill,
                overview = next.overview,
                seriesTitle = state.seriesTitle,
                runtimeMinutes = next.runtime,
                isUnwatched = org.siloserver.silo.model.settings.EpisodeSpoilers.isUnwatched(next.userData),
            )
            _uiState.update {
                if (it.contentId != forContentId) it else it.copy(nextEpisode = nextState)
            }
            if (_uiState.value.contentId != forContentId) return@launch
            // If the credits/end point already fired while we were still
            // resolving, the overlay couldn't arm — complete it now (re-arm the
            // countdown) with the strongest video-ended flag we observed.
            if (!autoAdvanceHandled) {
                pendingApproachingEndVideoEnded?.let { videoEnded ->
                    commitApproachingEnd(nextState, videoEnded)
                }
            }
        }
    }

    /**
     * Called by the screen when the credits point is reached (primary) or the
     * stream ends (fallback). Surfaces the Up-Next overlay — a 16:9 mini-player
     * beside the next-episode panel — as the end-of-playback surface (mirrors
     * tvOS PlayerNextUpScreen), replacing the old "Still watching?" dialog.
     *
     * When auto-play is on and the consecutive-auto-advance streak is below the
     * pass-out threshold, the overlay starts a countdown ring that plays the
     * next episode at zero. Once the streak hits the pass-out threshold (or
     * auto-play is off), the overlay shows with NO countdown so the user must
     * explicitly choose Play Now / Keep Watching (the pass-out gate). The credits
     * prompt is once per episode; a dismissed card reopens when playback ends.
     *
     * [videoEnded] true when the stream has actually ended (STATE_ENDED) — the
     * panel reads "End of playback" / "Playing Next" and hides Keep Watching;
     * false at the credits-crossing while video is still rolling.
     */
    fun onApproachingEnd(videoEnded: Boolean = false) {
        if (nextUpTransitionGate.isActive) return
        // Watch Together is authoritative — never auto-advance a room member
        // (it would silently leave/desync the room). Mirrors the remote-control
        // transport gate.
        if (roomId != null) return
        // Recorded before the once-per-item guard below, which Keep Watching on
        // a hand-opened Up Next also sets.
        reachedCreditsOrEnd = true
        if (shufflePlayback != null) {
            // A multi-part pick plays its later parts before the shuffle moves on.
            shuffleNextPartFileId?.let { fileId ->
                if (videoEnded) playNextShufflePart(fileId)
                return
            }
            if (!shuffleRefreshedForPostRoll) {
                shuffleRefreshedForPostRoll = true
                refreshShuffleNext()
            }
        }
        // Playback end reopens a dismissed card without restarting its timer.
        // A card still showing keeps its existing countdown.
        if (autoAdvanceHandled) {
            if (videoEnded) {
                _uiState.update { it.copy(showNextUp = true, hudOpen = false, nextUpVideoEnded = true) }
            }
            return
        }

        val next = _uiState.value.nextEpisode
        if (next == null) {
            // Next episode hasn't resolved yet — don't latch a permanent
            // no-countdown/no-next state. Record that the end point fired (and
            // whether the stream has ended) so the countdown re-arms when
            // nextEpisode arrives via [resolveNextEpisode]. If a later signal
            // upgrades to videoEnded, keep the strongest (ended) flag.
            val ended = videoEnded || (pendingApproachingEndVideoEnded == true)
            pendingApproachingEndVideoEnded = ended
            // If the stream has genuinely ended (STATE_ENDED) we still surface
            // the end-of-playback overlay now — there may be no next episode at
            // all (last episode / movie). We deliberately do NOT latch
            // autoAdvanceHandled here, so a next episode that resolves moments
            // later can still arm the countdown via resolveNextEpisode.
            if (ended) {
                _uiState.update {
                    it.copy(
                        showNextUp = true,
                        // Up Next owns the screen: the HUD is rendered purely on
                        // hudOpen, so leaving it set draws the tab row and panes
                        // underneath the overlay.
                        hudOpen = false,
                        nextUpVideoEnded = true,
                        nextUpCountdownSeconds = null,
                    )
                }
            }
            return
        }
        commitApproachingEnd(next, videoEnded)
    }

    /**
     * Whether an Up Next control has anything to show right now.
     *
     * Shared with the automatic path deliberately: a manual button that can
     * appear when the automatic trigger would find nothing is a button that
     * does nothing when pressed.
     */
    fun canShowNextUpNow(): Boolean {
        // The room owns what plays next; Play Now could never advance.
        if (roomId != null) return false
        val state = _uiState.value
        // A shuffle replaces the series order: no sequential next episode.
        return state.nextEpisode != null && !state.showNextUp && state.shuffle == null
    }

    /**
     * Surface Up Next on demand, ahead of the credits trigger.
     *
     * Routed through the same commit the automatic timing uses so the overlay,
     * the countdown gating and the auto-advance accounting behave identically —
     * the only difference is what asked for it. Mirrors silo-apple#86, which
     * added the equivalent control to the tvOS transport.
     *
     * The countdown is deliberately NOT started here: someone who opened this
     * themselves is choosing, and a timer that yanks them into the next episode
     * mid-decision is the opposite of what the press asked for.
     */
    fun onUserRequestedNextUp() {
        if (roomId != null) return
        val next = _uiState.value.nextEpisode ?: return
        if (_uiState.value.showNextUp) return
        nextUpCountdownJob?.cancel()
        nextUpCountdownJob = null
        _uiState.update {
            it.copy(showNextUp = true, hudOpen = false, nextUpCountdownSeconds = null)
        }
    }

    private fun commitApproachingEnd(next: NextEpisodeState, videoEnded: Boolean) {
        autoAdvanceHandled = true
        pendingApproachingEndVideoEnded = null
        // Threshold 0 (or less) = off: never gate, always allow auto-countdown.
        val threshold = passOutThreshold.value
        val passOutGated = threshold > 0 && autoAdvanceCount >= threshold
        val autoCountdown = autoPlayNextEnabled.value && !passOutGated
        val current = _uiState.value
        // Pre-end commits anchor the countdown to the remaining playback time
        // (see startNextUpCountdown); only an at-end commit uses the wall clock.
        val initialCountdown = when {
            !autoCountdown -> null
            videoEnded -> NEXT_UP_COUNTDOWN_SECONDS
            else -> ceil((current.duration - current.position).coerceAtLeast(0.0)).toInt()
        }

        _uiState.update {
            it.copy(
                showNextUp = true,
                hudOpen = false,
                nextUpVideoEnded = videoEnded,
                nextUpCountdownSeconds = initialCountdown,
                // The ring draws remaining/total, so a pre-end countdown longer
                // than the wall-clock default has to carry its own total or the
                // ring renders past full.
                nextUpCountdownTotalSeconds = initialCountdown?.coerceAtLeast(1)
                    ?: NEXT_UP_COUNTDOWN_SECONDS,
            )
        }
        if (autoCountdown) startNextUpCountdown()
    }

    private fun startNextUpCountdown() {
        nextUpCountdownJob?.cancel()
        nextUpCountdownJob = viewModelScope.launch {
            // Two anchors, matching phone and tvOS:
            //  - Card committed BEFORE the end (credits crossing): the countdown
            //    mirrors the remaining playback time, so it freezes on pause,
            //    grows on a backward seek, and the advance fires only once the
            //    player reports the stream ended. A fixed wall clock here cut off
            //    the final scene of anything whose credits marker sits more than
            //    ten seconds from the actual end.
            //  - Card committed AT the end (stream ended with no earlier
            //    crossing): there is no playback left to anchor to, so a short
            //    wall-clock countdown gives the viewer a window to cancel.
            val startedAtEnd = _uiState.value.nextUpVideoEnded
            var wallRemaining = NEXT_UP_COUNTDOWN_SECONDS
            while (true) {
                delay(1_000)
                // Bail if something dismissed the overlay underneath us.
                if (!_uiState.value.showNextUp) return@launch
                val remaining = if (startedAtEnd) {
                    wallRemaining -= 1
                    wallRemaining.coerceAtLeast(0)
                } else {
                    val state = _uiState.value
                    ceil((state.duration - state.position).coerceAtLeast(0.0)).toInt()
                }
                _uiState.update {
                    if (!it.showNextUp) {
                        it
                    } else {
                        it.copy(
                            nextUpCountdownSeconds = remaining,
                            // A backward seek can push the remaining time past
                            // where the ring started; grow the total with it.
                            nextUpCountdownTotalSeconds =
                                maxOf(it.nextUpCountdownTotalSeconds, remaining, 1),
                        )
                    }
                }
                if (!_uiState.value.showNextUp) return@launch
                val playbackEnded =
                    if (startedAtEnd) wallRemaining <= 0 else _uiState.value.nextUpVideoEnded
                if (!playbackEnded) continue
                // Automatic countdown-expiry advance: increment the pass-out streak
                // so a long unattended binge eventually trips the "still watching?"
                // gate. An explicit Play Now (below) resets the streak instead.
                // Counted now, not when the handoff lands, so viewer activity
                // during the handoff still resets it.
                autoAdvanceCount += 1
                advanceToNextEpisode()
                return@launch
            }
        }
    }

    /**
     * Up-Next "Play Now" / Play-Pause-on-overlay: an explicit user choice to keep
     * going. This is active watching, so it RESETS the pass-out streak to 0 —
     * the next episode starts fresh and isn't gated behind the still-watching
     * prompt. The automatic countdown-expiry path keeps incrementing the streak.
     */
    fun playNextEpisodeNow() {
        resetPassOutStreak()
        advanceToNextEpisode()
    }

    private fun advanceToNextEpisode() {
        nextUpCountdownJob?.cancel()
        nextUpCountdownJob = null
        // Watch Together owns the room timeline. The previous navigation
        // collector enforced this guard; keep it here now that TV advances
        // in place so a remote Next command cannot desynchronise the room.
        if (!shouldNavigateToLocalNext(inWatchTogetherRoom = roomId != null)) return
        if (shufflePlayback != null) {
            advanceShuffle()
            return
        }
        val next = _uiState.value.nextEpisode ?: return
        playInPlace(next.contentId, targetFileId = null)
    }

    /**
     * Replaces the mounted item in place with [targetContentId] (and
     * [targetFileId], when a specific file must play) from the beginning.
     * [showCard] keeps the Up Next overlay up through the handoff; a later
     * part of the same item plays without it.
     */
    private fun playInPlace(
        targetContentId: String,
        targetFileId: Int?,
        showCard: Boolean = true,
    ) {
        val state = _uiState.value
        if (!nextUpTransitionGate.begin(targetContentId)) return
        _uiState.update {
            it.copy(
                showNextUp = it.showNextUp || showCard,
                isNextUpTransitioning = true,
                nextUpCountdownSeconds = null,
            )
        }
        val activeVersion = state.fileVersions.firstOrNull { version ->
            version.fileId == (state.selectedFileId ?: state.mediaFileId)
        }
        val captured = captureTvEpisodeSelectionHandoff(
            activeVersion = activeVersion,
            committedSubtitleIdentity = state.committedSubtitleIdentity,
            catalogSubtitles = state.subtitleUrls,
            selectedAudioTrack = state.audioTracks.firstOrNull { it.isSelected },
            // The catalog row by ordinal — audio's contract — but the viewer's
            // CONFIRMED choice first. A direct-play local switch changes the
            // mounted track without replanning, so the plan can still name the
            // previous audio: reading it alone handed the next episode the
            // track the viewer had just switched away from, while
            // manualAudioSelectionApplied said a choice had been made.
            selectedCatalogAudio = (
                state.desiredAudioOrdinal?.takeIf { state.desiredAudioConfirmed }
                    ?: state.playbackPlan?.selectedTracks?.audioIndex
                )?.let { activeVersion?.audioTracks?.getOrNull(it) },
            hasExplicitAudioSelection = manualAudioSelectionApplied,
            hasExplicitSubtitleSelection = manualSubtitleSelectionApplied,
        )
        val handoff = carryEpisodeIntent(
            captured = captured,
            incoming = incomingEpisodeIntent,
            audioPicked = audioPickedThisEpisode,
            subtitlePicked = subtitlePickedThisEpisode,
        )
        val outgoingSessionId = exitSessionId
        resolveNextEpisodeJob?.cancel()
        viewModelScope.launch {
            // The lifecycle is process-scoped. Finish the predecessor before
            // planning the successor, but keep the PlayerView/SurfaceView in
            // place so Media3 can retain its last frame through the handoff.
            if (!finishCurrentEpisodeForNextUp(outgoingSessionId)) {
                nextUpTransitionGate.cancel()
                _uiState.update { it.copy(showNextUp = false, isNextUpTransitioning = false) }
                return@launch
            }
            if (!nextUpTransitionGate.isActive) return@launch

            lastAdoptedSessionId = null
            contentId = targetContentId
            preferredFileId = targetFileId
            versionChosen = false
            preferredQuality = null
            qualityOverride = null
            initialAudioTrackIndex = null
            pendingInitialSubtitleIndex = null
            pendingInitialSubtitleAutoResolved = false
            pendingInitialSubtitleAttempts = 0
            autoTextSubtitleSelectionAttempted = false
            autoAdvanceHandled = false
            reachedCreditsOrEnd = false
            pendingApproachingEndVideoEnded = null
            shuffleNextPartFileId = null
            shuffleRefreshedForPostRoll = false
            episodeSelectionHandoffSlot.replace(handoff)
            loadContent(
                startPositionOverride = 0.0,
                suppressResumeRewind = true,
            )
        }
    }

    /** Finalizes the outgoing episode without clearing the mounted video UI. */
    private suspend fun finishCurrentEpisodeForNextUp(expectedSessionId: String?): Boolean {
        if (!subtitleTransactions.invalidateAndAwaitSettlement()) return false
        playbackMutationFence.invalidateAll()
        contentLoadGeneration++
        resetSeekRecoveryForContentChange()
        transportMountGate.beginLoad()

        val state = _uiState.value
        val fileId = state.selectedFileId ?: state.mediaFileId
        val scope = finalPositionScope
        maybeRecordPosition(state.position, state.duration, force = true)
        if (scope != null && contentId.isNotBlank() && fileId != null) {
            finalPlaybackPositionWriter.submit(
                FinalPlaybackPosition(
                    scope = scope,
                    contentId = contentId,
                    fileId = fileId,
                    positionSeconds = state.position,
                    durationSeconds = state.duration.takeIf { it > 0.0 },
                    serverTrackedAtMs = System.currentTimeMillis()
                        .takeIf { expectedSessionId?.let(playbackSessionManager::isSequenced) == true },
                ),
            )
        }
        subtitleTransactions.persistCommittedSelectionAndFlush()
        introObserveJob?.cancel()
        introAutoSkipController.reset()
        resetBufferingQuality()
        val stopped = sessionLifecycle.stop(expectedSessionId = expectedSessionId)
        if (stopped) finalPositionScope = null
        return stopped
    }

    // ---- Shuffle ----

    private fun resolveShuffleNext() {
        val shuffle = shufflePlayback ?: return
        val state = _uiState.value
        val forContentId = state.contentId
        // The overlay waits for the last part of a multi-part pick.
        shuffleNextPartFileId = org.siloserver.silo.playback.nextPlaybackPartFileId(
            versions = state.fileVersions,
            currentFileId = state.selectedFileId ?: state.mediaFileId,
        )
        if (shuffleNextPartFileId != null) return
        resolveNextEpisodeJob?.cancel()
        // The advance that started this item already returned its next pick.
        if (shuffle.latest?.current?.contentId == forContentId) {
            publishShuffleNext(forContentId)
            return
        }
        resolveNextEpisodeJob = viewModelScope.launch {
            shuffle.refresh()
            publishShuffleNext(forContentId)
        }
    }

    /** Re-reads the shuffle as the overlay opens: the server replaces a next pick that can no longer play. */
    private fun refreshShuffleNext() {
        val shuffle = shufflePlayback ?: return
        val forContentId = _uiState.value.contentId
        viewModelScope.launch {
            shuffle.refresh()
            publishShuffleNext(forContentId)
        }
    }

    /** Shows the shuffle's pick after [forContentId], or the finished state when there is none. */
    private fun publishShuffleNext(forContentId: String) {
        val shuffle = shufflePlayback ?: return
        if (_uiState.value.contentId != forContentId || nextUpTransitionGate.isActive) return
        val next = shuffle.nextPickAfter(forContentId)?.let { pick ->
            NextEpisodeState(
                contentId = pick.contentId,
                seasonNumber = pick.seasonNumber,
                episodeNumber = pick.episodeNumber,
                title = pick.title,
                stillUrl = pick.stillUrl,
                overview = pick.overview,
                seriesTitle = pick.seriesTitle,
                runtimeMinutes = pick.runtimeMinutes,
                isUnwatched = pick.isUnwatched,
                isEpisode = pick.isEpisode,
            )
        }
        val previous = _uiState.value.nextEpisode
        _uiState.update {
            it.copy(
                nextEpisode = next,
                shuffle = it.shuffle?.copy(scopeLabel = shuffle.scopeLabel ?: it.shuffle.scopeLabel),
            )
        }
        val countingDownAtEnd = nextUpCountdownJob?.isActive == true && _uiState.value.nextUpVideoEnded
        when {
            next == null -> {
                nextUpCountdownJob?.cancel()
                nextUpCountdownJob = null
                _uiState.update { it.copy(nextUpCountdownSeconds = null) }
            }
            // A different pick, such as Pick Another, gets the full countdown
            // rather than whatever was left of the previous one.
            previous != null && previous.contentId != next.contentId && countingDownAtEnd -> {
                _uiState.update {
                    it.copy(
                        nextUpCountdownSeconds = NEXT_UP_COUNTDOWN_SECONDS,
                        nextUpCountdownTotalSeconds = NEXT_UP_COUNTDOWN_SECONDS,
                    )
                }
                startNextUpCountdown()
            }
            previous == null && !autoAdvanceHandled ->
                pendingApproachingEndVideoEnded?.let { videoEnded -> commitApproachingEnd(next, videoEnded) }
        }
    }

    /** Plays the next part of a multi-part pick from its start, without the overlay. */
    private fun playNextShufflePart(fileId: Int) {
        shuffleNextPartFileId = null
        playInPlace(contentId, targetFileId = fileId, showCard = false)
    }

    /**
     * Moves the shuffle past the item that played and plays the returned
     * pick from the beginning. The server moves on only while that item is
     * still current, so a repeated press or a retry plays the same pick.
     */
    private fun advanceShuffle() {
        val shuffle = shufflePlayback ?: return
        if (_uiState.value.nextEpisode == null) return
        if (shuffleAdvanceJob?.isActive == true || nextUpTransitionGate.isActive) return
        val fromContentId = _uiState.value.contentId
        _uiState.update { it.copy(nextUpCountdownSeconds = null) }
        val pendingPick = shufflePickJob
        shuffleAdvanceJob = viewModelScope.launch {
            // A Pick Another still in flight decides what plays; wait for it.
            pendingPick?.join()
            if (shufflePlayback !== shuffle) return@launch
            val result = shuffle.advance(fromContentId)
            if (_uiState.value.contentId != fromContentId || shufflePlayback !== shuffle) return@launch
            val target = (result as? ApiResult.Success)?.data?.current?.contentId
            if (target == null) {
                if (shuffle.exhausted) publishShuffleNext(fromContentId) else showShuffleMessage(SHUFFLE_CONTINUE_FAILED)
                return@launch
            }
            // Like the first pick, every shuffled item plays from the start.
            playInPlace(target, targetFileId = null)
        }
    }

    /** Up Next "Pick Another": the server replaces the announced pick. */
    fun pickAnotherShuffle() {
        val shuffle = shufflePlayback ?: return
        if (shufflePickJob?.isActive == true || shuffleAdvanceJob?.isActive == true || nextUpTransitionGate.isActive) return
        val forContentId = _uiState.value.contentId
        _uiState.update { it.copy(shuffle = it.shuffle?.copy(pickingAnother = true)) }
        shufflePickJob = viewModelScope.launch {
            val result = shuffle.pickAnother()
            _uiState.update { it.copy(shuffle = it.shuffle?.copy(pickingAnother = false)) }
            if (_uiState.value.contentId != forContentId || shufflePlayback !== shuffle) return@launch
            if (result !is ApiResult.Success && !shuffle.exhausted) {
                showShuffleMessage(SHUFFLE_PICK_FAILED)
                return@launch
            }
            publishShuffleNext(forContentId)
        }
    }

    /**
     * Up Next "Stop shuffling": ends the shuffle on the server. The screen
     * leaves the player right after, back to where the shuffle started.
     */
    fun stopShuffling() {
        val shuffle = shufflePlayback ?: return
        shufflePlayback = null
        shuffleAdvanceJob?.cancel()
        shufflePickJob?.cancel()
        nextUpCountdownJob?.cancel()
        nextUpCountdownJob = null
        shuffle.stopInBackground()
        _uiState.update { it.copy(shuffle = null, nextEpisode = null, nextUpCountdownSeconds = null) }
    }

    private fun showShuffleMessage(message: String) {
        shuffleMessageJob?.cancel()
        _uiState.update { it.copy(shuffle = it.shuffle?.copy(message = message)) }
        shuffleMessageJob = viewModelScope.launch {
            delay(4_000)
            _uiState.update { it.copy(shuffle = it.shuffle?.copy(message = null)) }
        }
    }

    /** Up-Next "Keep Watching" — dismiss the overlay and stay on the current episode. */
    fun dismissNextUp() {
        if (nextUpTransitionGate.isActive) return
        autoAdvanceHandled = true
        nextUpCountdownJob?.cancel()
        nextUpCountdownJob = null
        _uiState.update { it.copy(showNextUp = false, nextUpCountdownSeconds = null) }
    }

    /**
     * Push the fresh list of audio / subtitle tracks up from the screen. Called
     * from a `Player.Listener.onTracksChanged` callback — we keep the list in
     * ViewModel state so the menu composables can read it directly.
     */
    fun onTracksChanged(audio: List<PlayerTrackEntry>, subtitle: List<PlayerTrackEntry>) {
        _uiState.update { it.copy(audioTracks = audio, subtitleTracks = subtitle) }
        reconcileDesiredAudio(audio)
        resolveSubtitleRemountReselection(subtitle)
        // The detail-page explicit pick resolves FIRST so a resolved pick can
        // suppress the persisted/auto fallback (and an unresolvable one lets it
        // proceed) before persisted reads its fingerprint.
        resolvePendingInitialSubtitle(subtitle)
        if (_pendingRemoteAudioIndex.value != null) {
            pendingPersistedAudioFingerprint = null
        }
        resolvePendingPersistedTrackSelection(audio)
        retryPendingRemoteTrackIntents()
        resolveAutoPreferredTextSubtitle(audio, subtitle)
        reconcileExternallySelectedSubtitle(subtitle)
    }

    fun onTracksChanged(
        audio: List<PlayerTrackEntry>,
        subtitle: List<PlayerTrackEntry>,
        video: List<PlayerTrackEntry>,
    ) {
        // videoQualities is the server-transcode ladder built at session load
        // (see loadContent) — NOT derived from the mounted adaptive variants, so
        // it is intentionally not touched here.
        _uiState.update {
            it.copy(
                audioTracks = audio,
                subtitleTracks = subtitle,
                videoTracks = video,
            )
        }
        reconcileDesiredAudio(audio)
        resolveSubtitleRemountReselection(subtitle)
        // The detail-page explicit pick resolves FIRST so a resolved pick can
        // suppress the persisted/auto fallback (and an unresolvable one lets it
        // proceed) before persisted reads its fingerprint.
        resolvePendingInitialSubtitle(subtitle)
        if (_pendingRemoteAudioIndex.value != null) {
            pendingPersistedAudioFingerprint = null
        }
        resolvePendingPersistedTrackSelection(audio)
        retryPendingRemoteTrackIntents()
        resolveAutoPreferredTextSubtitle(audio, subtitle)
        reconcileExternallySelectedSubtitle(subtitle)
    }

    /**
     * Restores the persisted AUDIO choice once tracks land.
     *
     * The subtitle half of this used to live here too, resolving a saved
     * fingerprint onto a Media3 ordinal and pushing it straight at the player.
     * The durable subtitle preference is now restored through the transaction
     * adapter at load (`restoreFreshPreference`), which is why the fingerprint
     * it read was already being cleared unconditionally on every load — it
     * could never fire again.
     */
    private fun resolvePendingPersistedTrackSelection(audio: List<PlayerTrackEntry>) {
        pendingPersistedAudioFingerprint?.let { fingerprint ->
            if (audio.isNotEmpty()) {
                // Resolve to a CATALOG ordinal and hand it to the desired-audio
                // resolver. This used to resolve a MOUNTED ordinal and push it
                // into _pendingRemoteAudioIndex, which is read back as a catalog
                // ordinal — so whenever mounted and catalog order disagreed it
                // restored the wrong language.
                //
                // The fingerprint is kept when it does not resolve: clearing it
                // on a partial first snapshot silently abandoned the restore.
                resolveAudioTrackOrdinal(catalogAudioTracks(_uiState.value), fingerprint)
                    ?.takeIf { it >= 0 }
                    ?.let { catalogOrdinal ->
                        pendingPersistedAudioFingerprint = null
                        setDesiredAudio(catalogOrdinal, explicit = false)
                    }
            }
        }
    }

    private fun resolveAutoPreferredTextSubtitle(
        audio: List<PlayerTrackEntry>,
        subtitle: List<PlayerTrackEntry>,
    ) {
        // Fallback ONLY. Any launch that carried a decision (detail-page pick or
        // its Auto preview, an episode intent, a recovery restore) has already
        // applied it, and re-deciding here is exactly the bug: this path can
        // only see what Media3 has mounted.
        if (launchSubtitleSelectionApplied) return
        // A launch pick that has not resolved YET is still the decision: it
        // retries across the next few track callbacks (a late sidecar, a
        // second Media3 snapshot). Deciding here in the meantime mounted the
        // auto pick over the viewer's — seen on a Shield where the detail-page
        // "English SRT" resolved a callback late and Auto had already put the
        // Forced track on. resolvePendingInitialSubtitle clears the index when
        // it resolves or gives up, and both happen before this runs on the
        // same callback, so nothing is stranded.
        if (pendingInitialSubtitleIndex != null) return
        // manualSubtitleSelectionApplied is set when a persisted choice OR a
        // RESOLVED explicit detail-page pick was applied — that (not the bare
        // launch intent) is what suppresses auto. An explicit pick that failed to
        // resolve leaves the flag clear, so auto still runs instead of stranding
        // subtitles Off.
        if (manualSubtitleSelectionApplied) return
        // Reached only by launches with no handoff at all (deep link, cast,
        // remote/realtime start). The latch stays because the fallback still
        // runs on every onTracksChanged: without it a second snapshot would
        // re-run auto over a longer track list and override a selection the
        // viewer has since made.
        if (autoTextSubtitleSelectionAttempted) return
        // A replacement load keeps the outgoing media playing until its own
        // mount applies. Deciding on the outgoing tracks would spend this
        // load's only attempt on the wrong file.
        if (transportMountGate.suppressPositionReports) return
        // Wait for the player to report SOMETHING: an empty snapshot carries no
        // selected audio language for the resolver to rank a subtitle against.
        if (audio.isEmpty() && subtitle.isEmpty()) return

        val state = _uiState.value
        // Media3 only knows what is MOUNTED. A launch whose server inventory is
        // all external sidecars has an empty text-track list until one of them
        // is mounted, so standing down on that alone left a deep link, cast or
        // remote start with subtitles Off even for an Always profile — with the
        // intended track sitting in subtitleUrls. Stand down only when neither
        // inventory offers anything to choose from.
        if (subtitle.isEmpty() && state.subtitleUrls.isEmpty()) return
        // Resolve over the SERVER inventory, not the mounted text tracks: an
        // external sidecar the initial plan did not mount is invisible to
        // Media3, which is how "Auto - <external SRT>" started playing the
        // embedded PGS track instead. The adapter mounts the winner if it is
        // not mounted yet — a legitimate replan for a launch nobody decided.
        val identity = resolveTvAutoSubtitleIdentity(
            audioTracks = audio,
            subtitleTracks = subtitle,
            subtitleRows = state.subtitleUrls,
            preferredLanguage = state.preferredTextLanguage,
            subtitleMode = state.preferredSubtitleMode,
            showForced = state.showForcedSubtitles,
            trackSignature = state.preferredSubtitleTrackSignature,
            intendedAudioLanguage = state.desiredAudioOrdinal
                ?.let { catalogAudioTracks(state).getOrNull(it) }
                ?.language,
        )
        autoTextSubtitleSelectionAttempted = true
        SubDiag.log("AUTO subtitle -> $identity")
        applyAutomaticSubtitleSelection(identity, state)
    }

    /**
     * Drives an app-derived selection through the adapter — the single owner —
     * rather than at the player directly. Selecting behind the adapter's back
     * is what left the HUD reporting "Off" over subtitles plainly on screen.
     */
    private fun applyAutomaticSubtitleSelection(
        identity: SubtitleIdentity,
        state: UiState,
        priority: TvSubtitleMountPriority = TvSubtitleMountPriority.Auto,
    ) {
        // Provenance is recorded BEFORE the already-committed shortcut below,
        // which publishes no transaction and returns. Exit persistence reads
        // this marker to tell an app-made choice from the viewer's, so leaving
        // it unset there wrote the plan's own pick — commonly the detail row's
        // "Auto - None" — back as a durable manual preference, and every later
        // launch restored that instead of re-running Auto.
        autoSelectedSubtitleIdentity = identity
        if (identity == state.committedSubtitleIdentity && state.pendingSubtitleIdentity == null) {
            // Committed is what the adapter BELIEVES is on. At load it is seeded
            // straight from the plan (resetContent) before the player has
            // selected any text track, so "already committed" is not evidence
            // the track is mounted — the launch handoff of a plan-selected
            // sidecar reached this line and returned, and nobody ever told the
            // player. Ask the adapter to mount its committed identity through
            // the same local-restore path the replan/recovery loads use.
            //
            // Off too: until text is disabled, Media3 turns on a track the file
            // flags Default, now or on a later snapshot, and
            // reconcileExternallySelectedSubtitle adopted it over "Auto - None".
            if (identity == SubtitleIdentity.Off) {
                SubDiag.log("AUTO committed Off -> restoreCommittedOff")
                nextSubtitleMountPriority = priority
                if (!subtitleTransactions.restoreCommittedOff()) {
                    nextSubtitleMountPriority = TvSubtitleMountPriority.UserTransaction
                }
            } else if (!playerHasSelectedSubtitle(identity, state)) {
                SubDiag.log("AUTO committed-but-unmounted -> restoreCommittedLocalMount $identity")
                nextSubtitleMountPriority = priority
                subtitleTransactions.restoreCommittedLocalMount()
            }
            return
        }
        autoSubtitleSelectionInFlight = true
        nextSubtitleMountPriority = priority
        launchSubtitleTransaction(state) {
            subtitleTransactions.selectAuto(identity)
        }
    }

    /** True when the player's currently selected text track carries [identity]. */
    private fun playerHasSelectedSubtitle(identity: SubtitleIdentity, state: UiState): Boolean {
        val selected = state.subtitleTracks.firstOrNull { it.isSelected } ?: return false
        return tvMountedSubtitleIdentity(selected, state.subtitleTracks, state.subtitleUrls) == identity
    }

    /**
     * Applies the detail page's pre-selected subtitle through the adapter.
     *
     * Restore authority, and deliberately NOT persisted: the pick arrives as a
     * launch argument the detail screen already owns the preference for, so
     * re-writing it here could only ever overwrite it with a stale echo. It is
     * still a resolved decision, which is why it outranks the auto heuristics.
     */
    private fun applyRestoredSubtitleSelection(identity: SubtitleIdentity) {
        applyAutomaticSubtitleSelection(
            identity = identity,
            state = _uiState.value,
            priority = TvSubtitleMountPriority.Restore,
        )
    }

    /**
     * Safety net, not the mechanism: if Media3 reports a text track selected
     * whose identity is not the adapter's committed one, something outside the
     * app enabled it (device caption settings, a selector quirk, a renderer
     * default). Adopt it so the HUD cannot disagree with the screen, and say so
     * loudly — reaching this means an authority we thought we had removed is
     * still selecting subtitles.
     */
    private fun reconcileExternallySelectedSubtitle(subtitle: List<PlayerTrackEntry>) {
        val state = _uiState.value
        // Converge the in-flight latch on observed state as well as on the
        // adapter snapshot: an automatic selection the adapter treats as a
        // no-op publishes nothing, and a latch that only the snapshot could
        // clear would disable this safety net for the rest of the session.
        if (autoSubtitleSelectionInFlight &&
            state.pendingSubtitleIdentity == null &&
            state.committedSubtitleIdentity == autoSelectedSubtitleIdentity
        ) {
            autoSubtitleSelectionInFlight = false
        }
        val observed = tvExternalSubtitleAdoption(
            subtitleTracks = subtitle,
            subtitleRows = state.subtitleUrls,
            committedIdentity = state.committedSubtitleIdentity,
            pendingIdentity = state.pendingSubtitleIdentity,
            selectionInFlight = autoSubtitleSelectionInFlight ||
                subtitleRemountReselection.hasPendingOwner,
        ) ?: return

        Log.w(
            TV_SUBTITLE_LOG_TAG,
            "Adopting externally selected text track: " +
                "observed=$observed committed=${state.committedSubtitleIdentity}",
        )
        applyAutomaticSubtitleSelection(observed, state)
    }

    /**
     * Apply the detail screen's pre-selected subtitle once the player's tracks
     * land.
     *
     * -1 = Off, applied immediately.
     *
     * A positive value is a COMBINED-space subtitle index (externals first,
     * embedded after — the identity mounted subtitle_urls carry and
     * subtitle_track_index requests resolve), not Media3's flattened
     * text-track ordinal. Resolve it through the mounted server subtitle
     * metadata first so embedded CEA-608 or other player-discovered tracks do
     * not shift the target, then hand the resolved track to the transaction
     * adapter as a typed identity — it is the only thing that may mount one.
     */
    private fun resolvePendingInitialSubtitle(subtitle: List<PlayerTrackEntry>) {
        val index = pendingInitialSubtitleIndex ?: return
        val autoResolved = pendingInitialSubtitleAutoResolved
        if (index == -1) {
            pendingInitialSubtitleIndex = null
            // Off from the detail page is a resolved decision — the row showed
            // it — so it suppresses the auto fallback. Only an EXPLICIT Off is
            // also a manual selection; an "Auto - None" preview is not.
            launchSubtitleSelectionApplied = true
            if (!autoResolved) manualSubtitleSelectionApplied = true
            applyRestoredSubtitleSelection(SubtitleIdentity.Off)
            return
        }
        // Wait for a non-empty track list. The pick is only CONSUMED when it
        // embedded tracks land (Media3 reports everything immediately), so the
        // first non-empty callback may not contain the picked sidecar yet.
        if (subtitle.isEmpty()) return
        val resolved = resolveInitialSubtitleTrackIndex(
            requestedOrdinal = index,
            subtitleTracks = subtitle,
            mountedSubtitles = _uiState.value.subtitleUrls,
        )
        // Suppress the auto fallback ONLY when the explicit pick actually
        // resolves onto a mounted track. An unresolvable pick leaves the manual
        // flag clear, so it falls through to auto instead of being silently
        // dropped (subtitles Off all session).
        if (resolved != null) {
            pendingInitialSubtitleIndex = null
            pendingInitialSubtitleAttempts = 0
            launchSubtitleSelectionApplied = true
            if (!autoResolved) manualSubtitleSelectionApplied = true
            subtitle.firstOrNull { it.index == resolved }
                ?.let { track ->
                    applyRestoredSubtitleSelection(
                        tvMountedSubtitleIdentity(track, subtitle, _uiState.value.subtitleUrls),
                    )
                }
            return
        }
        // Bounded retry: keep the pick pending across a few callbacks so a
        // late-mounting sidecar can still honor it, then give up so we only
        // act during initial load (persisted/auto proceed as usual).
        pendingInitialSubtitleAttempts += 1
        if (pendingInitialSubtitleAttempts >= MAX_PENDING_INITIAL_SUBTITLE_ATTEMPTS) {
            pendingInitialSubtitleIndex = null
            pendingInitialSubtitleAttempts = 0
        }
    }

    internal fun canApplySubtitleMount(request: TvSubtitleMountRequest): Boolean =
        !transportMountGate.suppressPositionReports &&
            subtitleRemountReselection.ownsResolved(request.owner.generation)

    internal fun onSubtitleSelectionApplied(request: TvSubtitleMountRequest) {
        if (!subtitleRemountReselection.ownsResolved(request.owner.generation)) return
        // MediaController accepted the override, but its player may not have
        // selected that group yet. A synchronous callback may already have
        // published it; otherwise onTracksChanged will confirm it later.
        resolveSubtitleRemountReselection(_uiState.value.subtitleTracks)
    }

    /**
     * Selects audio by ORDINAL into the active version's `audio_tracks`, which
     * is the server's contract for audio (see [selectedServerAudioTrackIndex]).
     *
     * The ordinal goes to the replan untouched. It used to be mapped through
     * `AudioTrack.index`, a field the server never sends for audio, so every
     * pick collapsed to 0.
     */
    fun selectAudioOption(catalogOrdinal: Int) {
        val state = _uiState.value
        val catalog = catalogAudioTracks(state)
        if (catalogOrdinal !in catalog.indices) return

        // If the mounted stream already carries this track, switch it on the
        // player. A replan would rebuild the whole session to deliver audio the
        // viewer is already receiving -- and because audio selection only ever
        // staged a replan, a direct-play stream carrying several audio tracks
        // never actually switched: the plan moved, the renderer did not.
        // Record the intent first: the resolver applies it locally when the
        // mounted stream already carries the track, which is the common
        // direct-play case and needs no replan at all.
        // Staged before the switch starts: a mounted track can be confirmed
        // during setDesiredAudio itself.
        rememberSeriesAudioChoice(state, catalogOrdinal)
        setDesiredAudio(catalogOrdinal, explicit = true)
        val switchesLocally = mountedAudioFor(
            catalog = catalog,
            catalogOrdinal = catalogOrdinal,
            mounted = state.audioTracks.map { it.toMountedAudioTrack() },
            delivery = state.playbackPlan?.delivery,
            planAudioOrdinal = state.playbackPlan?.selectedTracks?.audioIndex,
        ) != null
        if (switchesLocally) return

        // manualAudioSelectionApplied is deliberately NOT raised here: it is
        // raised on commit via CommittedSubtitle.audioPreferenceSpecified, so a
        // request that fails or rolls back never becomes an episode preference.
        playbackMutationFence.beginReplan()
        launchSubtitleTransaction(state) {
            subtitleTransactions.selectAudio(catalogOrdinal)
        }
    }

    fun selectSubtitleOption(identity: SubtitleIdentity) {
        manualSubtitleSelectionApplied = true
        subtitleChoiceGeneration += 1
        // The viewer is choosing: drop the automatic marker so this commit
        // writes the durable per-item preference.
        autoSelectedSubtitleIdentity = null
        autoSubtitleSelectionInFlight = false
        rememberSeriesSubtitleChoice(identity)
        playbackMutationFence.beginReplan()
        launchSubtitleTransaction(_uiState.value) {
            subtitleTransactions.select(identity)
        }
    }

    /**
     * A manual pick (a track or Off) applies to the whole series — or the
     * movie — and to the profile's other devices: it is saved on the server,
     * which hands it back as `effective_subtitle_*` on every later load.
     *
     * Saved only once the change commits: a pick whose request fails or rolls
     * back never becomes a preference. A pick of what already plays has
     * nothing to commit and is saved at once.
     */
    private fun rememberSeriesSubtitleChoice(identity: SubtitleIdentity) {
        val state = _uiState.value
        // Counted as this episode's pick (handed to Next Up) and saved only
        // once the change commits: a pick that fails to replan or mount is
        // undone. One that cannot be saved still counts once it commits.
        val write = StagedSubtitleWrite(
            contentId = state.contentId,
            key = trackChoiceKey(state),
            choice = org.siloserver.silo.model.playback.SeriesSubtitleChoice.of(identity, state.subtitleUrls),
            owner = trackChoiceOwner,
            identity = identity,
        )
        if (state.pendingSubtitleIdentity == null && state.committedSubtitleIdentity == identity) {
            stagedSubtitleWrite.set(null)
            saveSeriesSubtitle(write)
        } else {
            stagedSubtitleWrite.set(write)
        }
    }

    /**
     * A manual audio pick applies to the whole series (or the movie) and the
     * profile's other devices, like a subtitle pick. It is staged here and
     * saved once the track plays: confirmed on the player
     * ([confirmDesiredAudio]) or committed by its replan, so a switch the
     * watchdog gives up on is never saved. Restores, carried choices and
     * fallbacks never come through here.
     */
    private fun rememberSeriesAudioChoice(state: UiState, catalogOrdinal: Int) {
        val write = StagedAudioWrite(
            contentId = state.contentId,
            key = trackChoiceKey(state),
            choice = org.siloserver.silo.model.playback.SeriesAudioChoice.of(catalogAudioTracks(state), catalogOrdinal),
            owner = trackChoiceOwner,
            catalogOrdinal = catalogOrdinal,
            fileId = state.selectedFileId ?: state.mediaFileId,
        )
        stagedAudioWrite.set(write)
    }

    /**
     * The id a pick in this player is remembered under. Null for an episode
     * whose series is unknown: keying it by the episode would save a choice no
     * other episode reads.
     */
    private fun trackChoiceKey(state: UiState): String? {
        if (state.contentType == "episode" && state.seriesId.isNullOrBlank()) return null
        return org.siloserver.silo.model.playback.seriesTrackChoiceKey(state.seriesId, state.contentId)
    }

    /**
     * A pick waiting for its change to commit. On commit it counts as this
     * episode's pick and, when [key], [choice] and [owner] are known, is
     * saved as the series choice.
     */
    private data class StagedSubtitleWrite(
        val contentId: String,
        val key: String?,
        val choice: org.siloserver.silo.model.playback.SeriesSubtitleChoice?,
        val owner: org.siloserver.silo.network.AuthScopeSnapshot?,
        val identity: SubtitleIdentity,
    )

    private data class StagedAudioWrite(
        val contentId: String,
        val key: String?,
        val choice: org.siloserver.silo.model.playback.SeriesAudioChoice?,
        val owner: org.siloserver.silo.network.AuthScopeSnapshot?,
        val catalogOrdinal: Int,
        /** The file it was picked on; a replan can commit it on another. */
        val fileId: Int?,
    )

    /**
     * Whether [identity], committed over [rows], is the pick [write] staged:
     * the same identity, or the same track described again — a change that
     * restarted playback (a delivery change, such as a subtitle added to a
     * plan that had none) commits it from the new plan's rows.
     */
    private fun stagedSubtitleCommitted(
        write: StagedSubtitleWrite,
        identity: SubtitleIdentity,
        rows: List<org.siloserver.silo.model.playback.PlayerSubtitleInfo>,
    ): Boolean {
        if (identity == write.identity) return true
        val staged = write.choice ?: return false
        val described = org.siloserver.silo.model.playback.SeriesSubtitleChoice.of(identity, rows) ?: return false
        return described.subtitleMode == staged.subtitleMode &&
            described.trackSignature == staged.trackSignature
    }

    /**
     * Sends a staged subtitle pick once the item on screen has committed it,
     * whichever path got it there (a local mount, a replan, a restart).
     */
    private fun sendStagedSubtitleIfCommitted(contentId: String, committed: SubtitleIdentity, pending: SubtitleIdentity?, rows: List<org.siloserver.silo.model.playback.PlayerSubtitleInfo>) {
        val write = stagedSubtitleWrite.get() ?: return
        if (pending != null || write.contentId != contentId) return
        if (!stagedSubtitleCommitted(write, committed, rows)) return
        if (stagedSubtitleWrite.compareAndSet(write, null)) saveSeriesSubtitle(write)
    }

    /** Sends the staged picks [committed] made final; each goes out once. */
    private fun sendCommittedSeriesWrites(committed: org.siloserver.silo.model.playback.CommittedSubtitle) {
        stagedSubtitleWrite.get()
            ?.takeIf { it.identity == committed.identity && stagedSubtitleWrite.compareAndSet(it, null) }
            ?.let(::saveSeriesSubtitle)
        if (committed.audioPreferenceSpecified) {
            val state = _uiState.value
            stagedAudioWrite.get()
                ?.takeIf {
                    it.choice.isCommittedAt(
                        committedOrdinal = committed.audioTrackIndex,
                        committedTracks = catalogAudioTracks(state),
                        pickedOrdinal = it.catalogOrdinal,
                        sameFile = it.fileId == (state.selectedFileId ?: state.mediaFileId),
                    ) && stagedAudioWrite.compareAndSet(it, null)
                }
                ?.let(::saveSeriesAudio)
        }
    }

    /**
     * Drops staged picks when a new load replaces the playback they were
     * made in, except those for [keepContentId] (null drops all): the restart
     * that finishes a pick whose adoption failed inherits it.
     */
    private fun clearStagedSeriesWrites(keepContentId: String?) {
        stagedSubtitleWrite.updateAndGet { it?.takeIf { write -> write.contentId == keepContentId } }
        stagedAudioWrite.updateAndGet { it?.takeIf { write -> write.contentId == keepContentId } }
    }

    private fun saveSeriesSubtitle(write: StagedSubtitleWrite) {
        if (write.contentId == _uiState.value.contentId) subtitlePickedThisEpisode = true
        val key = write.key ?: return
        val choice = write.choice ?: return
        val owner = write.owner ?: return
        val writer = seriesTrackChoiceWriter ?: return
        viewModelScope.launch { writer.saveSubtitle(key, choice, owner) }
    }

    private fun saveSeriesAudio(write: StagedAudioWrite) {
        if (write.contentId == _uiState.value.contentId) audioPickedThisEpisode = true
        val key = write.key ?: return
        val choice = write.choice ?: return
        val owner = write.owner ?: return
        val writer = seriesTrackChoiceWriter ?: return
        viewModelScope.launch { writer.saveAudio(key, choice, owner) }
    }

    fun selectSubtitleOption(serverIndex: Int) {
        if (serverIndex == -1) {
            selectSubtitleOption(SubtitleIdentity.Off)
            return
        }
        val row = _uiState.value.subtitleUrls.firstOrNull { it.index == serverIndex } ?: return
        selectSubtitleOption(tvSubtitleIdentity(row))
    }

    internal fun onSubtitleSelectionFailed(request: TvSubtitleMountRequest) {
        val owner = request.owner
        if (!subtitleRemountReselection.acknowledgeResolved(owner.generation)) return
        Log.w(
            TV_SUBTITLE_LOG_TAG,
            "Subtitle mount rejected by the player: track=${request.trackIndex} " +
                "identity=${owner.identity}",
        )
        subtitleTransactions.reportMountedSelection(
            identity = owner.identity,
            selected = false,
            snapshotKey = "tv-mount-failed:${owner.generation}:${request.trackIndex}",
            settled = true,
        )
    }

    /**
     * Abandons an in-flight catalog-subtitle materialization (user turned
     * subtitles Off, or otherwise changed their mind) so the pending pick can't
     * re-enable itself when a later track refresh arrives.
     */
    fun cancelPendingCatalogSubtitle() {
        subtitleRemountReselection.clear()
        subtitleRemountReselection.releaseResolved()
        subtitleSnapshotSettlement.reset()
    }

    private fun resolveSubtitleRemountReselection(subtitle: List<PlayerTrackEntry>) {
        val snapshotKey = subtitle
            .takeIf(List<PlayerTrackEntry>::isNotEmpty)
            ?.joinToString("|") { "${it.index}:${it.trackId}:${it.isSelected}" }
        when (
            val event = subtitleRemountReselection.consume(
                subtitleTracks = subtitle,
                subtitleRows = _uiState.value.subtitleUrls,
                snapshotKey = snapshotKey,
                settled = subtitleSnapshotSettlement.observe(subtitle),
                transportMounted = !transportMountGate.suppressPositionReports,
            )
        ) {
            is TvSubtitleRemountEvent.Select -> _subtitleMountRequests.tryEmit(
                TvSubtitleMountRequest(owner = event.owner, trackIndex = event.trackIndex),
            )
            is TvSubtitleRemountEvent.Confirmed -> subtitleTransactions.reportMountedSelection(
                identity = event.owner.identity,
                selected = true,
                snapshotKey = snapshotKey ?: "tv-subtitles-off:${event.owner.generation}",
                settled = true,
            )
            is TvSubtitleRemountEvent.Failed -> subtitleTransactions.reportMountedSelection(
                identity = event.owner.identity,
                selected = false,
                snapshotKey = snapshotKey,
                settled = true,
            )
            null -> Unit
        }
    }

    /** Start scrubbing from [originSec], or the playback position when null. */
    fun beginScrub(originSec: Double? = null) {
        _uiState.update {
            it.copy(isScrubbing = true, scrubPreviewSec = originSec ?: it.position, showControls = true)
        }
    }

    fun updateScrubPreview(sec: Double) {
        _uiState.update {
            it.copy(scrubPreviewSec = clampTvScrubPreview(sec, it.duration))
        }
    }

    fun commitScrub(): Double {
        resetPassOutStreak()
        val target = _uiState.value.scrubPreviewSec
        _uiState.update { it.copy(isScrubbing = false) }
        return target
    }

    fun cancelScrub() {
        _uiState.update { it.copy(isScrubbing = false, scrubPreviewSec = 0.0) }
    }

    fun setControlsVisible(visible: Boolean) {
        _uiState.update {
            it.copy(
                showControls = visible,
                controlsVisibilityNonce = if (visible) {
                    it.controlsVisibilityNonce + 1
                } else {
                    it.controlsVisibilityNonce
                },
                // Hiding chrome tears down the scrubber; drop any in-flight scrub
                // so the scrubber's blur-safety effect (cancelOnBlur=false) can't
                // auto-commit a stale seek the instant controls reopen. The
                // auto-hide timer is gated on !isScrubbing, so this only clears a
                // scrub the user is no longer actively dragging.
                isScrubbing = if (visible) it.isScrubbing else false,
                scrubPreviewSec = if (visible) it.scrubPreviewSec else 0.0,
            )
        }
    }

    /**
     * Whether the transport overlay was on screen when the HUD opened.
     *
     * [openHUD] forces `showControls` true, which is invisible while the HUD is
     * up — the overlay is gated on `!hudOpen` — but closing has to put the
     * chrome back the way it found it. Without this, a HUD opened from clean
     * playback closed onto a transport overlay nobody asked for, and Back had
     * to be pressed twice to get back to the picture.
     */
    private var controlsVisibleBeforeHud = false

    fun openHUD() {
        // Only record on a real open. A second openHUD while the HUD is already
        // up would otherwise capture the forced `true` and lose the real origin.
        if (!_uiState.value.hudOpen) {
            controlsVisibleBeforeHud = _uiState.value.showControls
        }
        Log.d(TAG, "hud open (controlsBefore=$controlsVisibleBeforeHud, wasOpen=${_uiState.value.hudOpen})")
        _uiState.update { it.copy(hudOpen = true, showControls = true) }
    }

    fun closeHUD() {
        Log.d(TAG, "hud close (restoreControls=$controlsVisibleBeforeHud, wasOpen=${_uiState.value.hudOpen})")
        _uiState.update {
            it.copy(hudOpen = false, showControls = controlsVisibleBeforeHud)
        }
    }

    fun onVideoFillModeChanged(mode: VideoFillMode) {
        _uiState.update { it.copy(videoFillMode = mode) }
    }

    /**
     * The preference the session plays at: a pick, the route's, or the saved
     * setting the session started with. Auto lights in the menu only when
     * this is "auto".
     */
    private fun sessionQualityPreference(): String? =
        qualityOverride ?: preferredQuality ?: playbackSessionManager.activeVideoQualityPair()?.qualityPreference

    /**
     * Switch the in-player video quality (tvOS ApplePlaybackQuality parity): pin
     * a session-level [qualityOverride] and request a protocol-v3 replan at the
     * current position so the server transcodes to the chosen rung (or returns to
     * Auto, which plays the source when it can). [wireValue] is a plan entry's
     * label or "auto".
     */
    fun switchQuality(wireValue: String): Boolean {
        val current = sessionQualityPreference() ?: PlaybackQuality.Auto.wireValue
        if (wireValue == current) return false
        // The viewer's own pick (the HUD menu or a phone remote) replaces a
        // waiting Restore. Once its plan plays it is a quality change
        // (adoptBufferingQualityPlan); a refused pick is none. The
        // controller's replans never come through here.
        cancelBufferingRestore()
        val state = _uiState.value
        playbackMutationFence.beginReplan()
        launchSubtitleTransaction(state) {
            // Any buffering pill hides as the pick is sent.
            val wanted = videoQualityPreference(wireValue) ?: PLAYBACK_QUALITY_AUTO
            lastMenuPick = bufferingPicks.sent(
                matches = { it.quality == wanted },
                outstanding = { subtitleTransactions.hasActiveTransaction },
            )
            subtitleTransactions.selectQuality(wireValue)
        }
        return true
    }

    /**
     * The intro pill's Select: skip the intro (`ask`) or play it after all
     * (`always`'s undo). Returns the seek target in seconds so the screen can
     * call MediaController.seekTo, or null when no pill is showing.
     *
     * Returning the value (instead of seeking internally) keeps the VM free
     * of MediaController references — the screen owns the controller — and is
     * what lets a room route the seek through its transport gate.
     */
    fun onSelectIntroPrompt(): Double? {
        val target = introAutoSkipController.select() ?: return null
        // Pre-write the resolved source position so the credits crossing check
        // treats this as a deliberate jump. The caller routes the actual seek
        // through either the room controller or seekImmediate; the latter owns
        // the pending-position guard for solo playback.
        _uiState.update { it.copy(position = target) }
        return target
    }

    /**
     * Back while the intro pill is showing: take it down and resolve the intro
     * without moving playback. True when a pill was actually dismissed, so the
     * caller consumes the press only then.
     */
    fun onDismissIntroPrompt(): Boolean = introAutoSkipController.dismiss()

    // ---- Buffering quality ----------------------------------------------------

    private fun startBufferingQuality() {
        // In a Watch Party the room's own lower-quality offer applies.
        bufferingQualityController.setSuspended(roomId != null)
        // The session manager reads the stored mode itself; the controller
        // follows it here.
        viewModelScope.launch {
            playerSettingsStore.bufferingQualityModeFlow
                .distinctUntilChanged()
                .collect { mode -> bufferingQualityController.setMode(mode) }
        }
        // A failed plan's summary goes out when the error shows, not at Retry
        // or exit.
        viewModelScope.launch {
            _uiState.map { it.error != null }
                .distinctUntilChanged()
                .collect { failed -> if (failed) bufferingQualityController.onPlaybackStopped() }
        }
        // Picture in picture shows no pill: a prompt waits, and an undo pill
        // runs on unseen so it never holds off a later lowering.
        viewModelScope.launch {
            playerViewHidden.collect { bufferingQualityController.setViewHidden(it) }
        }
        networkEvidence?.let { evidence ->
            viewModelScope.launch {
                // Connected, not validated: a captive or unvalidated network
                // still carries media, and only its absence is an outage.
                evidence.updates
                    .map { it.connected }
                    .distinctUntilChanged()
                    .collect { connected -> bufferingQualityAdapter.onNetworkAvailable(connected) }
            }
        }
        viewModelScope.launch {
            var shownKind: String? = null
            bufferingPill
                .map { pill ->
                    when (pill) {
                        BufferingQualityPill.Hidden -> null
                        is BufferingQualityPill.Prompt -> "prompt"
                        is BufferingQualityPill.Undo -> "undo"
                    }
                }
                .distinctUntilChanged()
                .collect { kind ->
                    if (kind != null) {
                        Log.i(TAG, "buffering_quality pill_shown kind=$kind")
                    } else if (shownKind != null) {
                        Log.i(TAG, "buffering_quality pill_hidden kind=$shownKind")
                    }
                    shownKind = kind
                }
        }
    }

    /**
     * The mount [nonce] replaced the media item. A client-side same-plan
     * remount (a `client_retry` copy) is a reload of the plan the controller
     * already has; any other mount is a newly published plan, so a new
     * adoption, even when the server repeated its plan_id.
     */
    private fun adoptBufferingQualityPlan(nonce: Long) {
        val reload = pendingBufferingReloadNonce == nonce
        pendingBufferingReloadNonce = null
        val controllerInitiated = bufferingReplanNonce == nonce
        bufferingReplanNonce = null
        if (reload && bufferingAdoptionId != null) {
            bufferingQualityAdapter.reset(_uiState.value.playbackPlan?.delivery)
            bufferingQualityAdapter.markReload()
            return
        }
        val state = _uiState.value
        val shown = state.playbackPlan ?: return
        val adoptionId = "${shown.planId}#$nonce"
        bufferingAdoptionId = adoptionId
        bufferingAdoptedMountNonce = nonce
        // What the mounted plan was requested at, session pick included. The
        // session manager's pair comes first because it also carries a fixed
        // rung saved in Settings, which must never be treated as Auto.
        // videoQualityPreference reads "original" and its aliases as Auto.
        val quality = videoQualityPreference(
            playbackSessionManager.activeVideoQualityPair()?.qualityPreference
                ?: state.videoQualityPreference
                ?: sessionQualityPreference(),
        ) ?: PLAYBACK_QUALITY_AUTO
        val adopted = shown.toBufferingQualityPlan(quality, adoptionId)
        Log.i(
            TAG,
            "buffering_quality plan_adopted adoption_id=$adoptionId plan_id=${shown.planId} " +
                "delivered_kbps=${adopted.deliveredKbps} quality=${adopted.quality} " +
                "bandwidth_limit_kbps=${shown.bandwidthLimit?.kbps}",
        )
        _bufferingAutoLimited.value = shown.bandwidthLimit != null && adopted.quality == PLAYBACK_QUALITY_AUTO
        val key = BufferingQualityKey(
            adopted.quality,
            playbackSessionManager.activeVideoQualityPair()?.bandwidthCapKbps,
            state.mediaFileId,
        )
        val pickStillPending = bufferingPicks.stillPendingAfter(key)
        if (bufferingQualityKey.isViewerChangeTo(key, controllerInitiated)) {
            bufferingQualityController.onViewerQualityChange()
        }
        bufferingQualityKey = key
        if (!bufferingQualityController.hasPlan) playbackSessionManager.restartPlanThroughput()
        bufferingQualityController.onPlanAdopted(adopted, controllerInitiated, pickStillPending)
        // After adoption: re-announces the player's phase to the new plan.
        bufferingQualityAdapter.reset(shown.delivery)
    }

    /**
     * The controller's own `quality_change`. It rides the subtitle
     * transaction like a menu pick, so subtitle state survives it, but it is
     * not the viewer's quality change. A picked-rung lowering applies to this
     * playback only: the committed transaction moves [qualityOverride], and
     * the saved preference never changes. While another replan or
     * transaction is in flight a lowering is refused, and the controller
     * watches the plan again later; a Restore quality waits for its turn.
     */
    private fun requestBufferingQualityReplan(replan: BufferingQualityReplan) {
        Log.i(
            TAG,
            "buffering_quality replan_requested quality_preference=${replan.qualityPreference} " +
                "bandwidth_estimate_kbps=${replan.bandwidthEstimateKbps} " +
                "bandwidth_estimate_source=${replan.bandwidthEstimateSource} " +
                "learned_limit=${replan.learnedLimit}",
        )
        val state = _uiState.value
        val blocked = bufferingReplanBlockedReason(state)
        if (blocked != null && replan.learnedLimit == LEARNED_LIMIT_CLEAR && state.sessionId != null) {
            // A Restore quality waits for its turn, as on the phone: the kept
            // estimate goes at once, and the session manager owes its `clear`
            // to the next request, so whatever replaces it carries it, once.
            Log.i(TAG, "buffering_quality restore_waits_for_replan reason=$blocked")
            playbackSessionManager.discardStepDownEstimate()
            playbackSessionManager.oweLearnedLimitClear()
            bufferingRestoreJob?.cancel()
            bufferingRestoreJob = viewModelScope.launch {
                while (bufferingReplanBlockedReason(_uiState.value) != null) delay(BUFFERING_RESTORE_POLL_MS)
                bufferingRestoreJob = null
                if (playbackSessionManager.learnedLimitClearOwed) {
                    requestBufferingQualityReplan(replan)
                } else {
                    // A replan sent meanwhile carried the clear, and no estimate.
                    Log.i(TAG, "buffering_quality restore_rode_on_replan")
                    bufferingQualityController.onReplanFailed()
                }
            }
            return
        }
        if (blocked != null) {
            Log.i(TAG, "buffering_quality replan_not_sent reason=$blocked")
            bufferingQualityController.onReplanFailed()
            return
        }
        playbackMutationFence.beginReplan()
        val adoptionId = bufferingAdoptionId
        launchSubtitleTransaction(state) {
            // The launch waits on the transaction mutex: never send a replan
            // meant for a plan that has since been replaced.
            if (adoptionId == null || adoptionId != bufferingAdoptionId) {
                Log.i(TAG, "buffering_quality replan_not_sent reason=plan_changed")
                bufferingQualityController.onReplanFailed()
                return@launchSubtitleTransaction
            }
            subtitleTransactions.selectQuality(replan.qualityPreference, bufferingQuality = replan)
        }
    }

    /** Why the controller's replan can't go now, or null when it can. */
    private fun bufferingReplanBlockedReason(state: UiState): String? = when {
        state.sessionId == null || state.playbackPlan == null -> "no_active_session"
        state.isLoading || state.isNextUpTransitioning -> "load_in_flight"
        transportMountGate.suppressPositionReports -> "mount_pending"
        recoveryJob?.isActive == true -> "recovery_in_flight"
        seekRecoveryQueue.hasInFlight -> "seek_recovery_in_flight"
        subtitleTransactions.hasActiveTransaction -> "transaction_in_flight"
        else -> null
    }

    /**
     * A quality change or other content supersedes a waiting Restore quality;
     * its owed `clear` rides on the request that replaces it.
     */
    private fun cancelBufferingRestore() {
        bufferingRestoreJob?.cancel()
        bufferingRestoreJob = null
    }

    private fun showBufferingQualityNotice(notice: BufferingQualityNotice) {
        Log.i(TAG, "buffering_quality notice key=${notice.key}")
        bufferingNoticeSlot.show(notice)
    }

    /**
     * A load of [contentId] starts. Another attempt at the same title keeps
     * the controller's answer, notice and re-offer wait, which belong to the
     * title; other content starts fresh.
     */
    private fun beginBufferingQualityLoad() {
        if (contentId != bufferingQualityContentId) {
            resetBufferingQuality()
            bufferingQualityContentId = contentId
            return
        }
        bufferingQualityController.onNewAttempt()
        forgetBufferingPlan()
    }

    /** Clears the controller and its notice for different content or an exit. */
    private fun resetBufferingQuality() {
        bufferingQualityController.reset()
        bufferingQualityContentId = null
        bufferingQualityKey = null
        bufferingPicks.clear()
        forgetBufferingPlan()
        bufferingNoticeSlot.clear()
    }

    /** Forgets what this screen tracked about the controller's playing plan. */
    private fun forgetBufferingPlan() {
        bufferingAdoptionId = null
        bufferingAdoptedMountNonce = null
        pendingBufferingReloadNonce = null
        bufferingReplanNonce = null
        cancelBufferingRestore()
        _bufferingAutoLimited.value = false
    }

    /** "Lower quality" on the buffering prompt. */
    fun onBufferingLower() {
        bufferingQualityController.selectLower()
    }

    /** "Keep quality" on the buffering prompt. */
    fun onBufferingKeep() {
        bufferingQualityController.selectKeep()
    }

    /** "Restore quality" on the undo pill. */
    fun onBufferingRestore() {
        bufferingQualityController.selectRestore()
    }

    /**
     * At most one actionable pill: the intro, recap and credits skip pills
     * and Next Up outrank the buffering pill. The screen reports them as
     * displayed, since only it knows which are on screen.
     */
    fun onOtherPillDisplayed(displayed: Boolean) {
        bufferingQualityController.setOtherPillVisible(displayed)
    }

    /** The screen reports picture in picture, where no buffering pill or notice shows. */
    fun onPlayerViewHiddenChanged(hidden: Boolean) {
        playerViewHidden.value = hidden
    }

    /** Back while a buffering pill shows. True when the pill consumed it. */
    fun onBufferingBack(): Boolean = bufferingQualityController.back()

    /** Select at the player root: the visible pill's primary action. True when consumed. */
    fun onBufferingSelectPrimary(): Boolean = bufferingQualityController.selectPrimary()

    /**
     * HUD Chapters pane picked a row. Returns the seek target in seconds;
     * the screen owns the MediaController and performs the actual seek.
     * Returns null when the supplied index is out of range (shouldn't
     * happen — the row list is built from the same `chapters` field — but
     * guarded for safety).
     */
    fun onSeekToChapter(chapterIndex: Int): Double? =
        _uiState.value.chapters.getOrNull(chapterIndex)?.startSeconds

    // ---- Subtitle suite: AI status probe + dialog visibility --------------------

    /**
     * Lazy once-per-player-session AI status probe, fired by the HUD the
     * first time the Subtitles pane is shown. On any failure both flags stay
     * false → the "Translate with AI" row is simply hidden (web parity; no
     * error surfaced).
     */
    fun onSubtitlesPaneShown() {
        // Opening re-reads sync state so a job that finished meanwhile shows.
        subtitleSync.reload()
        if (aiStatusRequested) return
        aiStatusRequested = true
        viewModelScope.launch {
            val status = when (val r = subtitlesRepository.aiStatus()) {
                is ApiResult.Success -> r.data
                else -> SubtitleAiStatus(enabled = false, transcribeEnabled = false)
            }
            _aiTranslate.update { it.copy(statusLoaded = true, status = status) }
        }
    }

    fun openSubtitleSearchDialog() {
        val defaultLang = LanguageNames.searchCode(_uiState.value.preferredTextLanguage)
        _subtitleSearch.update {
            // Keep prior results/language when reopening mid-session.
            if (it.hasSearched) it else it.copy(language = defaultLang)
        }
        _uiState.update { it.copy(showSubtitleSearchDialog = true) }
    }

    fun closeSubtitleSearchDialog() {
        subtitleDownloadGeneration++
        _subtitleSearch.update { it.copy(downloadingResultId = null) }
        _uiState.update { it.copy(showSubtitleSearchDialog = false) }
    }

    fun openAiTranslateDialog() {
        refreshAiQuota() // spec: quota refreshed on open
        // Keep the phase: a running job shows its progress and a failure keeps
        // its reason; the form stays usable for a new request in both cases.
        _uiState.update { it.copy(showAiTranslateDialog = true) }
    }

    /** Dismiss the dialog. A running job keeps polling — reopening shows live progress. */
    /**
     * Fork: applies one live AI subtitle event from the session socket. Events
     * for another session, file or job are ignored. The first batch of cues
     * closes the AI dialog so the viewer sees them over the picture.
     */
    internal fun applyLiveSubtitleEvent(event: PlaybackLiveSubtitleEvent) {
        val state = _uiState.value
        if (event.sessionId != null && event.sessionId != state.sessionId) return
        if (event.fileId != null && state.mediaFileId != null && event.fileId != state.mediaFileId) return
        activeAiJobId?.let { if (it != event.jobId) return }
        when (event) {
            is PlaybackLiveSubtitleEvent.Started -> {
                liveSubtitleFallbackClear?.cancel()
                _liveSubtitle.value = LiveSubtitleTrack(
                    sessionId = state.sessionId,
                    jobId = event.jobId,
                    trackKey = event.trackKey,
                    language = event.language,
                    label = event.label,
                    total = event.totalCues,
                )
            }
            is PlaybackLiveSubtitleEvent.Cues -> {
                val current = _liveSubtitle.value?.takeIf { it.jobId == event.jobId }
                    ?: LiveSubtitleTrack(sessionId = state.sessionId, jobId = event.jobId, trackKey = event.trackKey)
                val firstCues = current.cues.isEmpty() && event.cues.isNotEmpty()
                _liveSubtitle.value = current.plus(event.cues, event.done, event.total)
                if (firstCues && _uiState.value.showAiTranslateDialog) closeAiTranslateDialog()
            }
            is PlaybackLiveSubtitleEvent.Completed -> {
                _liveSubtitle.update { live -> live?.takeIf { it.jobId == event.jobId }?.copy(completed = true) ?: live }
                // The job poll normally loads and selects the finished track
                // and clears this within a second or two. If that poll isn't
                // running (it was abandoned), don't draw the live copy forever.
                liveSubtitleFallbackClear?.cancel()
                liveSubtitleFallbackClear = viewModelScope.launch {
                    delay(LIVE_SUBTITLE_COMPLETED_GRACE_MS)
                    clearLiveSubtitle(event.jobId)
                }
            }
            is PlaybackLiveSubtitleEvent.Failed -> clearLiveSubtitle(event.jobId)
        }
    }

    /** Stops drawing live AI subtitles (for [jobId] only, when given). */
    fun clearLiveSubtitle(jobId: Long? = null) {
        _liveSubtitle.update { live -> if (live == null || (jobId != null && live.jobId != jobId)) live else null }
    }

    /** Source (file) seconds for a player position, matching the live cues' clock. */
    fun liveSubtitleSourceSeconds(playerPositionMs: Long): Double {
        val seconds = playerPositionMs.coerceAtLeast(0L) / 1000.0
        return _uiState.value.playbackPlan?.timeline?.sourcePositionForPlayer(seconds) ?: seconds
    }

    fun closeAiTranslateDialog() {
        _uiState.update { it.copy(showAiTranslateDialog = false) }
    }

    // ---- Subtitle suite: provider search / download ------------------------------

    fun setSubtitleSearchLanguage(code: String) {
        _subtitleSearch.update { it.copy(language = code) }
    }

    fun searchSubtitles() {
        val mediaFileId = _uiState.value.mediaFileId ?: return
        if (_subtitleSearch.value.isSearching) return
        val language = _subtitleSearch.value.language
        _subtitleSearch.update {
            it.copy(isSearching = true, hasSearched = true, error = null, results = emptyList(), warnings = emptyList())
        }
        viewModelScope.launch {
            val request = SubtitleSearchRequest(mediaFileId = mediaFileId, languages = listOf(language))
            when (val r = subtitlesRepository.search(request)) {
                is ApiResult.Success -> _subtitleSearch.update {
                    it.copy(isSearching = false, results = r.data.results, warnings = r.data.warnings)
                }
                // No capability probe exists — "no providers configured" arrives
                // here as a plain server error; surface its text verbatim.
                is ApiResult.Error, is ApiResult.NetworkError -> _subtitleSearch.update {
                    it.copy(isSearching = false, error = r.errorMessage(TvPlayerErrors.SUBTITLE_SEARCH_FAILED))
                }
            }
        }
    }

    private var subtitleDownloadGeneration = 0L

    fun downloadSubtitle(result: SubtitleResult) {
        val mediaFileId = _uiState.value.mediaFileId ?: return
        val sessionId = _uiState.value.sessionId
        if (_subtitleSearch.value.downloadingResultId != null) return
        _subtitleSearch.update { it.copy(downloadingResultId = result.id, error = null) }
        val generation = ++subtitleDownloadGeneration
        viewModelScope.launch {
            val request = SubtitleDownloadRequest(
                mediaFileId = mediaFileId,
                provider = result.provider,
                subtitleId = result.id,
                language = result.language,
                releaseName = result.releaseName,
                format = result.format,
                score = result.score,
                hearingImpaired = result.hearingImpaired,
            )
            val r = subtitlesRepository.download(request)
            if (generation != subtitleDownloadGeneration || _uiState.value.mediaFileId != mediaFileId || _uiState.value.sessionId != sessionId) return@launch
            when (r) {
                is ApiResult.Success -> {
                    // Follows the automatic sync the server starts for a new download.
                    subtitleSync.remember(r.data.subtitle)
                    val merged = refreshSubtitles(
                        autoSelectSubtitleId = r.data.subtitle.id,
                        source = TvSubtitleRefreshSource.Download,
                    )
                    if (generation != subtitleDownloadGeneration || _uiState.value.mediaFileId != mediaFileId || _uiState.value.sessionId != sessionId) return@launch
                    _subtitleSearch.update {
                        if (merged) {
                            it.copy(downloadingResultId = null, completedNonce = it.completedNonce + 1)
                        } else {
                            // Downloaded on the server, but we could not list it
                            // back — say so rather than closing as a success.
                            it.copy(
                                downloadingResultId = null,
                                error = TvPlayerErrors.SUBTITLE_DOWNLOADED_NOT_REFRESHED,
                            )
                        }
                    }
                }
                is ApiResult.Error, is ApiResult.NetworkError -> _subtitleSearch.update {
                    it.copy(downloadingResultId = null, error = r.errorMessage(TvPlayerErrors.SUBTITLE_DOWNLOAD_FAILED))
                }
            }
        }
    }

    // ---- Subtitle suite: track refresh (web-parity, no session restart) ---------

    /**
     * Refetch the downloaded-subtitle list, merge it into
     * [UiState.subtitleUrls] via the shared pure merge, and bump
     * [UiState.subtitleRefreshNonce] so the screen re-prepares the MediaItem
     * (same stream URL + session — only the sidecar list changes). Selection
     * is label-driven: the freshly downloaded track's label when
     * [autoSelectSubtitleId] matches, otherwise the currently selected track's
     * label so the rebuild preserves the user's choice (Media3 track-group
     * overrides don't survive a re-prepare — groups are new instances).
     */
    /**
     * Re-list subtitles after a download or AI job, returning whether it worked.
     *
     * It used to return Unit, so callers bumped completedNonce regardless — and
     * both dialogs read that nonce as "the track merged and was selected" and
     * dismissed themselves. A server-side job that succeeded followed by a
     * failed list request therefore closed as a success with no new subtitle
     * anywhere, which is indistinguishable from the feature not working.
     */
    internal suspend fun refreshSubtitles(
        autoSelectSubtitleId: Int?,
        source: TvSubtitleRefreshSource = TvSubtitleRefreshSource.Realtime,
    ): Boolean {
        val state = _uiState.value
        val mediaFileId = state.mediaFileId ?: return false
        val sessionId = state.sessionId ?: return false
        subtitleTransactions.updatePlaybackContext(subtitlePlaybackContext(state))
        val owner = subtitleTransactions.beginRefresh(source)
        if (state.playbackPlan != null) {
            pendingAuthoritativeSubtitleDownloadId = autoSelectSubtitleId
            val readyRow = autoSelectSubtitleId?.let { id ->
                authoritativeSubtitleReadyRows[sessionId to id]
            }
            if (readyRow != null) {
                val selected = subtitleTransactions.selectFromRefresh(
                    owner,
                    tvSubtitleIdentity(readyRow),
                )
                if (selected) pendingAuthoritativeSubtitleDownloadId = null
            } else if (source == TvSubtitleRefreshSource.AiCompletion && autoSelectSubtitleId != null) {
                // Fork: the new track normally arrives as a realtime
                // subtitle_ready event. If that event is missed, the job
                // finished but the track never appeared. Replan once after a
                // short wait so the session's inventory picks it up.
                viewModelScope.launch {
                    delay(AI_SUBTITLE_READY_FALLBACK_MS)
                    val current = _uiState.value
                    if (current.sessionId == sessionId &&
                        pendingAuthoritativeSubtitleDownloadId == autoSelectSubtitleId &&
                        authoritativeSubtitleReadyRows[sessionId to autoSelectSubtitleId] == null
                    ) {
                        startProtocolV3Replan(
                            classification = "subtitle_inventory_changed",
                            notice = "Subtitle inventory changed. Refreshing playback metadata.",
                            state = current,
                        )
                    }
                }
            }
            return true
        }
        val downloaded = try {
            when (val r = subtitlesRepository.list(mediaFileId)) {
            is ApiResult.Success -> r.data.subtitles
            is ApiResult.Error -> {
                Log.w(TAG, "refreshSubtitles failed: ${r.code} ${r.message}")
                subtitleTransactions.completeRefreshFailure(owner, r.message)
                return false
            }
            is ApiResult.NetworkError -> {
                Log.w(TAG, "refreshSubtitles network error", r.exception)
                subtitleTransactions.completeRefreshFailure(
                    owner,
                    r.exception.message ?: "Subtitle refresh failed.",
                )
                return false
            }
            }
        } catch (cancellation: CancellationException) {
            subtitleTransactions.cancelRefresh(owner)
            throw cancellation
        }
        val downloadedRows = mergeDownloadedSubtitles(
            existing = state.subtitleUrls,
            downloaded = downloaded,
            sessionId = sessionId,
        )
        // The adapter's answer, not an assumption. applyRefresh returns false
        // when the refresh lost ownership before it could be applied — so a
        // list request that SUCCEEDED but went stale in flight would otherwise
        // still be reported as merged, and the dialog would close on a track
        // that was never installed.
        return subtitleTransactions.applyRefresh(
            owner = owner,
            subtitleTracks = downloadedRows,
            autoSelectDownloadId = autoSelectSubtitleId,
        )
    }

    /** Applies one exact server-minted V3 inventory row from realtime. */
    internal suspend fun applySubtitleReady(update: PlaybackSubtitleReady): Boolean {
        val state = _uiState.value
        val sessionId = state.sessionId ?: return false
        if (update.sessionId != null && update.sessionId != sessionId) return false
        if (update.mediaFileId != null && update.mediaFileId != state.mediaFileId) return false
        val rows = applyAuthoritativeSubtitleReadyTrack(state.subtitleUrls, update)
        if (rows == null) {
            startProtocolV3Replan(
                classification = "subtitle_inventory_changed",
                notice = "Subtitle inventory changed. Refreshing playback metadata.",
                state = state,
            )
            return false
        }
        subtitleTransactions.updatePlaybackContext(subtitlePlaybackContext(state))
        val owner = subtitleTransactions.beginRefresh(TvSubtitleRefreshSource.Realtime)
        val subtitleId = update.subtitleId
        val added = update.track?.trackId?.let { trackId ->
            rows.singleOrNull { it.serverTrackId == trackId }
        }
        if (subtitleId != null && added != null) {
            authoritativeSubtitleReadyRows[sessionId to subtitleId] = added
        }
        val autoSelectId = subtitleId.takeIf { it == pendingAuthoritativeSubtitleDownloadId }
        val applied = subtitleTransactions.applyRefresh(
            owner = owner,
            subtitleTracks = rows,
            autoSelectDownloadId = autoSelectId,
        )
        if (applied && autoSelectId != null) pendingAuthoritativeSubtitleDownloadId = null
        return applied
    }

    /**
     * The server retimed a subtitle of the file, stored or a sidecar (a sync,
     * or a timing set or reset). The sync controller re-reads it and reports
     * the change through [onSubtitleSyncTimingChanged].
     */
    internal fun applySubtitleTimingChanged(update: PlaybackSubtitleTimingChanged) {
        val state = _uiState.value
        val sessionId = state.sessionId ?: return
        if (update.sessionId != null && update.sessionId != sessionId) return
        if (update.mediaFileId != null && update.mediaFileId != state.mediaFileId) return
        val key = update.syncKey ?: update.subtitleId?.let(SubtitleSyncState::storedKey) ?: return
        subtitleSync.timingChanged(key)
    }

    /** A step of a sync job of the file (realtime): progress, then the outcome. */
    internal fun applySubtitleSyncUpdated(update: PlaybackSubtitleSyncUpdated?) {
        update ?: return
        val state = _uiState.value
        val sessionId = state.sessionId ?: return
        if (update.sessionId != null && update.sessionId != sessionId) return
        if (update.mediaFileId != null && update.mediaFileId != state.mediaFileId) return
        subtitleSync.syncUpdated(update)
    }

    fun dismissSubtitleSyncNotice() = subtitleSyncFeedback.dismiss()

    private fun mountedSubtitles(state: UiState): List<PlayerSubtitleInfo> =
        if (state.sessionId == null) {
            emptyList()
        } else {
            subtitlesForVideoMediaMount(
                subtitles = state.subtitleUrls,
                playbackPlan = state.playbackPlan,
                subtitleIdentity = state.pendingSubtitleIdentity ?: state.committedSubtitleIdentity,
                preferMuxedTracks = true,
            )
        }

    private fun activeSubtitleSyncKey(state: UiState): String? =
        state.subtitleUrls.activeSyncKey(
            state.pendingSubtitleIdentity ?: state.committedSubtitleIdentity,
            mounted = mountedSubtitles(state),
        )

    /**
     * A syncable subtitle's timing changed. Media3 keeps the cues it already
     * parsed, so when that subtitle is the mounted sidecar, remount the same
     * item at the same position to fetch it again. Its cue revision tells the
     * sync feedback when the new cues show.
     */
    private fun onSubtitleSyncTimingChanged(key: String) {
        _uiState.update {
            it.copy(subtitleCueRevisions = it.subtitleCueRevisions + (key to (it.subtitleCueRevisions[key] ?: 0) + 1))
        }
        if (mountedSubtitles(_uiState.value).includesSyncKey(key)) subtitleTransactions.remountSubtitles()
    }

    // ---- Subtitle suite: AI translate / transcribe -------------------------------

    fun refreshAiQuota() {
        viewModelScope.launch {
            val owner = subtitlesRepository.captureJobAuthority() ?: return@launch
            val result = subtitlesRepository.aiQuota()
            val now = subtitlesRepository.captureJobAuthority()
            if (!owner.isSameIdentityAs(now) || owner.profileId != now?.profileId || owner.profileToken != now?.profileToken) return@launch
            if (result is ApiResult.Success) _aiTranslate.update { it.copy(quota = result.data) }
        }
    }

    /**
     * Submit an AI job and poll to completion. `start_position` = current
     * playhead and `session_id` = the playback session (web parity), so the
     * server can run it as a foreground job; Android polls instead of showing
     * live cues. Runs in viewModelScope so player exit cancels the poll via
     * structured concurrency (the server job itself keeps running).
     */
    private var aiCreationInFlight = false
    private var aiCancelOwner: Pair<Long, org.siloserver.silo.network.AuthScopeSnapshot>? = null

    fun submitAiTranslate(
        kind: String,
        sourceIndex: Int,
        sourceLanguage: String?,
        targetLanguage: String,
    ) {
        val state = _uiState.value
        val generation = contentLoadGeneration
        val mediaFileId = state.mediaFileId ?: return
        val phase = _aiTranslate.value.phase
        if (aiCreationInFlight || phase is AiJobPhase.Submitting || phase is AiJobPhase.Running) return
        aiCreationInFlight = true
        _aiTranslate.update { it.copy(phase = AiJobPhase.Submitting) }
        aiJobPollJob?.cancel()
        aiJobPollJob = viewModelScope.launch(start = kotlinx.coroutines.CoroutineStart.UNDISPATCHED) {
            val owner = subtitlesRepository.captureJobAuthority() ?: run {
                _aiTranslate.update { it.copy(phase = AiJobPhase.Failed(TvPlayerErrors.SUBTITLE_SIGN_IN_REQUIRED)) }
                return@launch
            }
            fun samePlayback() = generation == contentLoadGeneration && _uiState.value.mediaFileId == mediaFileId && _uiState.value.sessionId == state.sessionId
            suspend fun ownsRequest(): Boolean {
                val now = subtitlesRepository.captureJobAuthority()
                return samePlayback() && owner.isSameIdentityAs(now) && owner.profileId == now?.profileId && owner.profileToken == now?.profileToken
            }
            if (!ownsRequest()) return@launch
            val request = SubtitleTranslateRequest(
                mediaFileId = mediaFileId,
                kind = kind,
                sourceIndex = sourceIndex,
                sourceLanguage = sourceLanguage?.ifBlank { null },
                targetLanguage = targetLanguage.ifBlank { null },
                startPosition = state.position,
                sessionId = state.sessionId,
            )
            val r = subtitlesRepository.translate(request, owner)
            if (!ownsRequest()) return@launch
            val job = when (r) {
                is ApiResult.Success -> r.data.job.let { job ->
                    if (!r.data.liveDeliveryAttached && job.progressMessage.isBlank()) job.copy(progressMessage = TvPlayerErrors.PROCESSING_IN_BACKGROUND) else job
                }
                is ApiResult.Error -> {
                    // 429 = quota exhausted → refresh quota so the dialog
                    // flips to the exhausted state; 503 = engine unconfigured.
                    if (r.code == 429) refreshAiQuota()
                    _aiTranslate.update {
                        it.copy(phase = AiJobPhase.Failed(r.errorMessage(TvPlayerErrors.TRANSLATION_FAILED)))
                    }
                    return@launch
                }
                is ApiResult.NetworkError -> {
                    _aiTranslate.update {
                        it.copy(phase = AiJobPhase.Failed(r.errorMessage(TvPlayerErrors.TRANSLATION_FAILED)))
                    }
                    return@launch
                }
            }
            aiCancelOwner = job.id to owner
            activeAiJobId = job.id
            _aiTranslate.update {
                it.copy(phase = AiJobPhase.Running(job.progress, job.progressMessage.ifBlank { null }))
            }
            val outcome = subtitlesRepository.pollJob(
                jobId = job.id,
                expectedScope = owner,
                onUpdate = { update ->
                    if (samePlayback()) _aiTranslate.update {
                        it.copy(
                            phase = AiJobPhase.Running(
                                update.progress,
                                update.progressMessage.ifBlank { null },
                            ),
                        )
                    }
                },
            )
            if (!ownsRequest()) {
                clearLiveSubtitle(job.id)
                return@launch
            }
            activeAiJobId = null
            when (outcome) {
                is SubtitlesRepository.SubtitleJobOutcome.Completed -> {
                    val merged = refreshSubtitles(
                        autoSelectSubtitleId = outcome.resultSubtitleId,
                        source = TvSubtitleRefreshSource.AiCompletion,
                    )
                    // The finished track is selected now (or the replan
                    // fallback will load it); stop drawing the live copy.
                    clearLiveSubtitle(job.id)
                    if (!ownsRequest()) return@launch
                    _aiTranslate.update {
                        if (merged) {
                            it.copy(phase = AiJobPhase.Idle, completedNonce = it.completedNonce + 1)
                        } else {
                            it.copy(
                                phase = AiJobPhase.Failed(
                                    TvPlayerErrors.TRANSLATED_NOT_REFRESHED,
                                ),
                            )
                        }
                    }
                }
                is SubtitlesRepository.SubtitleJobOutcome.Failed -> {
                    clearLiveSubtitle(job.id)
                    val message = outcome.message ?: TvPlayerErrors.TRANSLATION_FAILED
                    _aiTranslate.update { it.copy(phase = AiJobPhase.Failed(message)) }
                    // The dialog may have been closed while the job ran; a reason
                    // is a full sentence, so it stays up long enough to read on a TV.
                    if (!_uiState.value.showAiTranslateDialog) showPlayerMessage(aiFailureNotice(message), 10_000L)
                }
                SubtitlesRepository.SubtitleJobOutcome.Cancelled -> {
                    clearLiveSubtitle(job.id)
                    _aiTranslate.update { it.copy(phase = AiJobPhase.Idle) }
                }
            }
        }.also { job -> job.invokeOnCompletion { aiCreationInFlight = false } }
    }

    /** Dialog Cancel row: stop polling, ask the server to cancel, return to the form. */
    fun cancelAiTranslateJob() {
        val jobId = activeAiJobId
        val owner = aiCancelOwner?.takeIf { it.first == jobId }?.second
        aiJobPollJob?.cancel()
        aiJobPollJob = null
        activeAiJobId = null
        clearLiveSubtitle()
        _aiTranslate.update { it.copy(phase = AiJobPhase.Idle) }
        if (jobId != null && owner != null) {
            viewModelScope.launch { subtitlesRepository.cancelJob(jobId, owner) }
        }
    }

    /** Failed phase → back to the form after the user acknowledges the error. */
    fun clearAiTranslateError() {
        _aiTranslate.update { it.copy(phase = AiJobPhase.Idle) }
    }

    // ---- Settings setters (forward to per-profile DataStore) -------------------
    fun onSetPlaybackSpeed(value: Double) {
        // A Watch Party plays at 1x; its correction rate is never a user
        // speed, and the saved preference stays untouched for solo playback.
        if (roomId != null) return
        viewModelScope.launch { playerSettingsStore.setPlaybackSpeed(value) }
    }

    fun onSetIntroSkipMode(value: IntroSkipMode) {
        viewModelScope.launch { playerSettingsStore.setIntroSkipMode(value) }
    }

    fun onSetAutoPlayNext(value: Boolean) {
        viewModelScope.launch { playerSettingsStore.setAutoPlayNext(value) }
    }

    fun onSetHdrEnabled(value: Boolean) {
        viewModelScope.launch { playerSettingsStore.setHdrEnabled(value) }
    }

    /**
     * Applies to local track selection immediately, but the part that matters
     * for a single-track DV file — base layer vs DV delivery — is decided in
     * the server's plan from the capability snapshot sent at load. So once the
     * setting is written, restart the session in place at the current position
     * if the current file is Dolby Vision: the viewer sees the layer they just
     * chose instead of having to back out and resume to get it. A non-DV file
     * has nothing to re-plan and is left alone.
     */
    fun onSetDolbyVisionEnabled(value: Boolean) {
        viewModelScope.launch {
            playerSettingsStore.setDolbyVisionEnabled(value)
            // A Watch Party never restarts its session for a local setting;
            // the choice applies from the next start.
            if (roomId != null) return@launch
            val state = _uiState.value
            if (state.streamUrl == null) return@launch
            val fileId = state.selectedFileId ?: state.mediaFileId
            val currentIsDolbyVision = state.fileVersions
                .firstOrNull { it.fileId == fileId }
                ?.let(org.siloserver.silo.tv.ui.screens.detail.TvPlaybackFormatting::isDolbyVision)
                ?: (state.playbackPlan?.claims?.video?.dolbyVision == true)
            if (!currentIsDolbyVision) return@launch
            Log.i(TAG, "dolby_vision_toggle value=$value restart_in_place file_id=$fileId")
            // "In flight" until the replacement session is adopted AND has
            // frames moving — adoption is quick (~1s) but the viewer's wait is
            // the rebuffer after it, so the cue must outlast that. If the
            // replacement never arrives (the old session is kept on failure),
            // stop claiming progress after a bounded wait.
            val previousSessionId = state.sessionId
            // The replacement publishes isPaused = false (loadContent) and the
            // screen mirrors that to playWhenReady, so changing the setting
            // while paused resumed the video behind the HUD. Carry the
            // pre-switch intent across and re-assert it once the replacement is
            // adopted — the publication that clears it is the same update that
            // clears isLoading.
            val wasPaused = state.isPaused
            _dolbyVisionSwitchInFlight.value = true
            dolbyVisionSwitchWatch?.cancel()
            dolbyVisionSwitchWatch = launch {
                try {
                    withTimeoutOrNull(OUTPUT_SWITCH_FEEDBACK_TIMEOUT_MS) {
                        if (wasPaused) {
                            // A restored pause never reaches isPlaying, so the
                            // cue ends at adoption rather than at first frames.
                            _uiState.first {
                                it.sessionId != previousSessionId && !it.isLoading
                            }
                            setPaused(true)
                        } else {
                            _uiState.first {
                                it.sessionId != previousSessionId &&
                                    !it.isLoading && !it.isBuffering && it.isPlaying
                            }
                        }
                    }
                } finally {
                    _dolbyVisionSwitchInFlight.value = false
                }
            }
            // The same file again: pinned only if the playing session was.
            restartSessionInPlace(fileId, pinVersion = sessionLifecycle.sessionPinsVersion)
        }
    }

    private val _dolbyVisionSwitchInFlight = MutableStateFlow(false)
    private var dolbyVisionSwitchWatch: Job? = null

    /**
     * True from a Dolby Vision toggle that restarted the session until the
     * replacement is adopted and playing. Drives the row's "Applying…" cue
     * and makes a second press a no-op mid-switch — without disabling the row,
     * which would drop focus off it.
     */
    val dolbyVisionSwitchInFlight: StateFlow<Boolean> = _dolbyVisionSwitchInFlight.asStateFlow()

    fun onSetSubtitleAppearance(value: SubtitleAppearance) {
        viewModelScope.launch { playerSettingsStore.setSubtitleAppearance(value) }
    }

    /**
     * HUD Audio pane stepper handler. Coerced to ±500ms in the store; the
     * service binding (E T3) picks up the new value and pushes it into the
     * shared [org.siloserver.silo.common.player.audio.DelayAudioProcessor]
     * (forcing a flush via `seekTo(currentPosition)` so the change applies
     * mid-playback).
     */
    fun onAudioDelayChanged(delayMs: Int) {
        viewModelScope.launch { playerSettingsStore.setAudioSyncMs(delayMs) }
    }

    /**
     * HUD Subtitles pane stepper handler. Coerced to ±10000ms in the store; the
     * service binding (A.3f T2) picks up the new value and pushes it into the
     * shared [org.siloserver.silo.common.player.subtitle.SubtitleOffsetHolder]
     * while reparsing the current media item so the change applies to already-
     * buffered cues.
     */
    fun onSubtitleDelayChanged(delayMs: Int) {
        viewModelScope.launch { playerSettingsStore.setSubtitleSyncMs(delayMs) }
    }

    // ---- Sleep timer setters ---------------------------------------------------
    fun onStartSleepTimer(minutes: Int) {
        sleepTimer.start(minutes)
        if (minutes > 0) {
            viewModelScope.launch { playerSettingsStore.setSleepTimerDefaultMinutes(minutes) }
        }
    }

    fun onCancelSleepTimer() {
        sleepTimer.cancel()
    }

    @Volatile
    private var lastAdoptedSessionId: String? = null

    /**
     * Retained token first, UI second.
     *
     * The token tracks *lifecycle ownership*, which is what teardown has to
     * name, and it moves in both directions: forward at each adoption and at
     * the load publication, back to the predecessor on either rollback path.
     * That is strictly better than UI state here, because the three adoption
     * paths take ownership before they publish and a cancellation in between
     * would otherwise leave teardown naming a session the lifecycle has already
     * let go of.
     */
    private val exitSessionId: String?
        get() = lastAdoptedSessionId ?: _uiState.value.sessionId

    /**
     * Keeps this screen's lifecycle teardown to exactly one stop. Without it,
     * [onCleared]'s deferred stop lands after the *next* episode's start has
     * captured its ownership epoch, bumps stopEpoch, and gets that start
     * rejected as "Playback start was superseded" — auto-advance dying on every
     * episode transition.
     */
    private val lifecycleTeardown = PlaybackTeardownGate(sessionLifecycle)

    private fun prepareSessionExit() {
        contentLoadGeneration++
        nextUpTransitionGate.cancel()
        resolveNextEpisodeJob?.cancel()
        episodeSelectionHandoffSlot.invalidate()
        subtitleSnapshotSettlement.reset()
        resetSeekRecoveryForContentChange()
        transportMountGate.reset()
        val state = _uiState.value
        val fileId = _uiState.value.selectedFileId ?: _uiState.value.mediaFileId
        val scope = finalPositionScope
        if (scope != null && contentId.isNotBlank() && fileId != null) {
            finalPlaybackPositionWriter.submit(
                FinalPlaybackPosition(
                    scope = scope,
                    contentId = contentId,
                    fileId = fileId,
                    positionSeconds = state.position,
                    durationSeconds = state.duration.takeIf { it > 0.0 },
                    serverTrackedAtMs = System.currentTimeMillis()
                        .takeIf { (lastAdoptedSessionId ?: state.sessionId)?.let(playbackSessionManager::isSequenced) == true },
                ),
            )
        }
        introObserveJob?.cancel()
        nextUpCountdownJob?.cancel()
        introAutoSkipController.reset()
        resetBufferingQuality()
        // Only fills a gap; never overwrites. The adoption paths publish this
        // token ahead of UI state on purpose, and taking the UI value here would
        // put the older id back.
        if (lastAdoptedSessionId == null) {
            _uiState.value.sessionId?.let { lastAdoptedSessionId = it }
        }
        _uiState.update {
            it.copy(
                isLoading = false,
                sessionId = null,
                playMethod = null,
                playbackPlan = null,
                delivery = null,
                streamUrl = null,
                container = null,
                subtitleUrls = emptyList(),
                isPaused = true,
                isPlaying = false,
            )
        }
    }

    /** Ordinary Back/remote-stop path: snapshot locally and return to detail immediately. */
    fun stopSessionForExitAsync(
        positionMs: Long? = null,
        durationMs: Long? = null,
    ) {
        // This is the controller's final sample. It must bypass transient
        // seek/mount presentation gates, while still mapping a shortened
        // Media3 timeline back onto source/movie time.
        _uiState.update { current ->
            val snapshot = resolveTvPlaybackExitSnapshot(
                currentPositionSeconds = current.position,
                currentDurationSeconds = current.duration,
                positionMs = positionMs,
                durationMs = durationMs,
                timeline = current.playbackPlan?.timeline,
                serverDurationSeconds = current.serverDuration,
                allowPlayerDuration = current.playbackPlan == null,
            )
            current.copy(
                position = snapshot.positionSeconds,
                duration = snapshot.durationSeconds,
            )
        }
        val subtitlePersistenceReservation =
            subtitleTransactions.reserveDurableFinalPersistence()
        val state = _uiState.value
        TvDetailTrackSelectionSession.rememberPlaybackReturn(
            contentId = contentId,
            fileId = state.selectedFileId ?: state.mediaFileId,
            audio = null,
            subtitle = selectedSubtitleTrackIndex(state),
            positionSeconds = state.position,
            durationSeconds = state.duration.takeIf { it > 0.0 },
        )
        // Recorded only while the launching identity is still current, so a
        // player left over from an earlier identity never replaces a newer return.
        val identityGeneration = launchIdentityGeneration
            ?.takeIf { it == identityTransitions?.generation?.value }
        state.seriesId?.takeIf {
            it.isNotBlank() && contentId.isNotBlank() && identityGeneration != null
        }?.let { seriesId ->
            // The series page lands on the episode on screen (auto-advance may
            // have moved past the one it launched), or on the next one once this
            // one reached its credits or end. A shuffle's next pick is not the
            // series' next episode, so shuffle always lands on the one on screen.
            val next = state.nextEpisode?.takeIf {
                shufflePlayback == null && (reachedCreditsOrEnd || state.nextUpVideoEnded)
            }
            TvDetailTrackSelectionSession.rememberSeriesReturn(
                TvDetailTrackSelectionSession.SeriesReturn(
                    seriesId = seriesId,
                    episodeId = next?.contentId ?: contentId,
                    seasonNumber = if (next != null) next.seasonNumber else state.seasonNumber,
                    identityGeneration = identityGeneration,
                ),
            )
        }
        subtitleTransactions.invalidate()
        playbackMutationFence.invalidateAll()
        prepareSessionExit()
        subtitlePersistenceReservation?.let(
            subtitleTransactions::requestDurableFinalPersistence,
        )
        // A player route can be stopped before its asynchronous start has
        // adopted a server session. Never issue an unqualified detached stop:
        // a replacement session could be adopted before the queued teardown
        // runs and then be stopped by this old route.
        exitSessionId?.let { lifecycleTeardown.stopDetached(expectedSessionId = it) }
    }

    fun onExit() {
        stopSessionForExitAsync()
    }

    /**
     * Surfaces a player runtime error (decoder init, source, network/401 after
     * prepare). Without this the screen can sit on a stale spinner instead of
     * an actionable error. The error UI offers [retry].
     */
    /**
     * @param servicePlayer the in-process player the error came from, when the
     * screen has it. The controller-side [error] has lost its renderer
     * attribution; the service player still knows which renderer failed.
     */
    fun onPlayerError(
        error: androidx.media3.common.PlaybackException,
        servicePlayer: androidx.media3.common.Player? = null,
        transportMountNonce: Long? = null,
    ) {
        val state = _uiState.value
        if (state.isNextUpTransitioning &&
            (state.isLoading || transportMountNonce != state.transportMountNonce)
        ) {
            return
        }
        val message = error.localizedMessage?.takeIf { msg -> msg.isNotBlank() }
            ?: "Playback failed. Please try again."
        val pendingSeekTarget = activeSeekTargetSec
        if (pendingSeekTarget != null &&
            (seekRecoveryQueue.hasInFlight ||
                recoveryJob?.isActive == true ||
                transportMountGate.suppressPositionReports)
        ) {
            Log.i(
                TAG,
                "seek_recovery seek_id=$activeSeekId action=ignore_stale_player_error " +
                    "error=${error.errorCodeName}",
            )
            DiagnosticsPlaybackLogger.seek(DiagnosticsSeekEvent.PlayerErrorIgnored, reason = error.errorCodeName)
            seekRecoveryRollbackInvalidated = true
            return
        }
        val isAudioSinkFailure = error.errorCode in setOf(
            androidx.media3.common.PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED,
            androidx.media3.common.PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED,
            androidx.media3.common.PlaybackException.ERROR_CODE_AUDIO_TRACK_OFFLOAD_INIT_FAILED,
            androidx.media3.common.PlaybackException.ERROR_CODE_AUDIO_TRACK_OFFLOAD_WRITE_FAILED,
        )
        if (isAudioSinkFailure) {
            val selectedTrack = state.audioTracks.firstOrNull { it.isSelected }
            val mime = selectedTrack?.codecOrMime.toAudioMimeType()
            val plan = state.playbackPlan
            if (mime != null && plan != null &&
                playbackSessionManager.trySingleLocalPcmRetry(mime, selectedTrack?.channelCount ?: 0)
            ) {
                val transportMountNonce = nextTransportMountNonce(selectedSubtitleTrackIndex(state))
                // The same plan, remounted for PCM: a reload for the buffering controller.
                pendingBufferingReloadNonce = transportMountNonce
                _uiState.update {
                    it.copy(
                        error = null,
                        playbackPlan = plan.copy(
                            timeline = plan.timeline.copy(
                                playerStartSeconds = plan.timeline.playerPositionForSource(state.position)
                                    ?: plan.timeline.playerStartSeconds,
                            ),
                            claims = plan.claims.copy(
                                audio = plan.claims.audio.copy(
                                    passthrough = false,
                                    reason = "client_pcm_retry",
                                ),
                            ),
                            decisionTrace = plan.decisionTrace + "client_retry=pcm_decode:$mime",
                        ),
                        startPosition = plan.timeline.playerPositionForSource(state.position)
                            ?: plan.timeline.playerStartSeconds,
                        transportMountNonce = transportMountNonce,
                    )
                }
                return
            }
        }
        if (state.sessionId != null && pendingSeekTarget != null &&
            hasRenderedFirstFrame &&
            !sameRouteSeekRecoveryAttempted && error.isSameRouteSeekReanchorCandidate()
        ) {
            sameRouteSeekRecoveryAttempted = true
            Log.w(
                TAG,
                "seek_recovery seek_id=$activeSeekId action=same_route_reanchor " +
                    "target_source_seconds=$pendingSeekTarget error=${error.errorCodeName}",
                error,
            )
            DiagnosticsPlaybackLogger.seek(DiagnosticsSeekEvent.PlayerErrorReanchor, reason = error.errorCodeName)
            startSeekReanchor(
                targetSourceSec = pendingSeekTarget,
                reason = "player_error_same_route",
                rollbackAllowed = false,
                diagnostics = mapOf(
                    "error_code" to error.errorCode.toString(),
                    "error_code_name" to error.errorCodeName,
                    "error_cause" to (error.cause?.javaClass?.simpleName ?: "unknown"),
                ),
            )
            return
        }
        // #8: a transient network blip shouldn't immediately demote a healthy
        // direct stream to a server transcode for the rest of playback. Retry the
        // SAME route a bounded number of times first; transientNetworkRetries
        // resets to 0 once playback actually progresses (onPositionChanged), so a
        // persistent outage still falls through to the recovery ladder below.
        val isTransientNetwork =
            error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
        if (isTransientNetwork &&
            state.sessionId != null &&
            state.playbackPlan != null &&
            transientNetworkRetries < MAX_TRANSIENT_NETWORK_RETRIES &&
            playbackSessionManager.recordTransportReopen()
        ) {
            transientNetworkRetries++
            Log.i(TAG, "Transient network error; retrying same route ($transientNetworkRetries/$MAX_TRANSIENT_NETWORK_RETRIES)")
            reopenSameRoute(state, "client_retry=transient_network:$transientNetworkRetries")
            return
        }
        if (state.sessionId != null) {
            val diagnostics = mapOf(
                "error_code" to error.errorCode.toString(),
                "error_code_name" to error.errorCodeName,
                "error_cause" to (error.cause?.javaClass?.simpleName ?: "unknown"),
            )
            val failedTrackType = error.failedRendererTrackType(servicePlayer)
            fun recover() {
                if (pendingSeekTarget != null) {
                    startSeekFailureRecovery(
                        targetSourceSec = pendingSeekTarget,
                        classification = error.failureClassification(),
                        notice = message,
                        diagnostics = diagnostics,
                    )
                } else {
                    startProtocolV3Replan(
                        error.failureClassification(),
                        message,
                        _uiState.value,
                        diagnostics = diagnostics,
                        failedTrackType = failedTrackType,
                    )
                }
            }
            if (isTransientNetwork && state.playbackPlan != null) {
                waitOutOutage(routeFailed = if (reopenedAfterOutage) ::recover else null)
            } else {
                recover()
            }
            return
        }
        Log.w(TAG, "Player error without a session: $message")
        _uiState.update {
            it.copy(
                isLoading = false,
                error = PLAYBACK_FAILED_MESSAGE,
            )
        }
    }

    /**
     * Reopens the playing plan at the current position, a reload for the
     * buffering controller. The new transport mount nonce re-runs the
     * screen's mount effect: a same-route remount, without a server
     * round-trip. [trace] goes on the decision trace to record why.
     */
    private fun reopenSameRoute(state: UiState, trace: String, endLoading: Boolean = true) {
        val plan = state.playbackPlan ?: return
        val start = plan.timeline.playerPositionForSource(state.position) ?: plan.timeline.playerStartSeconds
        val transportMountNonce = when (
            val restore = tvReopenSubtitleRestore(
                adapterMountIdentity = lastAdapterMountIdentity,
                adapterMountGeneration = lastAdapterMountGeneration,
                playerSelectedServerIndex = selectedSubtitleTrackIndex(state),
            )
        ) {
            is TvReopenSubtitleRestore.AdapterMount -> nextTransportMountNonce(subtitleServerIndexToRestore = null).also {
                subtitleSnapshotSettlement.reset()
                subtitleRemountReselection.arm(restore.identity, restore.generation)
            }
            is TvReopenSubtitleRestore.PlayerSelection -> nextTransportMountNonce(restore.serverIndex)
        }
        pendingBufferingReloadNonce = transportMountNonce
        _uiState.update {
            it.copy(
                isLoading = it.isLoading && !endLoading,
                error = null,
                playbackPlan = plan.copy(
                    timeline = plan.timeline.copy(playerStartSeconds = start),
                    decisionTrace = plan.decisionTrace + trace,
                ),
                startPosition = start,
                transportMountNonce = transportMountNonce,
            )
        }
    }

    /**
     * Media requests failed, or went silent, and the player gave up: an
     * outage. It never ends playback by itself, and a failure replan sent
     * into it would tell the server the route failed (the server then has
     * nothing left to plan). So nothing is sent: once the device is online
     * and the server answers again, the same route reopens.
     *
     * [routeFailed] is the failure recovery of an error after that reopen,
     * before playing. It runs only while no outage is in progress: the
     * device is online and the server answers, so the route itself fails.
     * The media loads' own trouble cannot tell, because the failed request
     * that raised the error is one. Otherwise the wait goes on.
     */
    private fun waitOutOutage(routeFailed: (() -> Unit)? = null) {
        // The wait belongs to the mount that failed: a newer mount's error
        // replaces it, and it never acts on a mount that replaced its own.
        val mount = _uiState.value.transportMountNonce
        if (outageRecoveryJob?.isActive == true && outageMount == mount) return
        outageRecoveryJob?.cancel()
        outageMount = mount
        Log.i(TAG, "outage: waiting for the network and the server before reopening the same route")
        _uiState.update { it.copy(isLoading = false, isBuffering = true, error = null) }
        outageRecoveryJob = viewModelScope.launch {
            if (routeFailed != null && networkEvidence?.snapshot()?.connected != false && serverAnswers()) {
                if (_uiState.value.transportMountNonce != mount) return@launch
                Log.i(TAG, "outage: the reopened route failed while the server answers; recovering")
                routeFailed()
                return@launch
            }
            var attempt = 0
            do {
                awaitNetworkRetry(networkEvidence?.updates ?: emptyFlow(), attempt++)
            } while (!serverAnswers())
            if (_uiState.value.transportMountNonce != mount) {
                Log.i(TAG, "outage: over, but another mount replaced the failed one; not reopening")
                return@launch
            }
            Log.i(TAG, "outage: over after $attempt checks; reopening the same route")
            reopenedAfterOutage = true
            reopenSameRoute(_uiState.value, "client_retry=outage_end")
        }
    }

    private suspend fun serverAnswers(): Boolean =
        withTimeoutOrNull(SERVER_CHECK_TIMEOUT_MS) {
            runCatching { serverReachabilityMonitor.retryNow() }.getOrNull()?.status ==
                org.siloserver.silo.common.network.ServerReachabilityStatus.Reachable
        } == true

    /**
     * In-player version switch (QA 2026-07-08 / tvOS parity): restart the
     * session on the chosen server file version at the current position.
     */
    fun onSelectFileVersion(fileId: Int) {
        // A Watch Party plays exactly the room's file.
        if (roomId != null) return
        val state = _uiState.value
        // Validate BEFORE mutating. A no-op or unknown id used to fall through
        // after the audio intent had already been dropped, silently losing the
        // choice without switching anything.
        if (fileId == (state.selectedFileId ?: state.mediaFileId)) return
        if (state.fileVersions.none { it.fileId == fileId }) return
        // A pick: it replaces a waiting Restore, hides any pill and holds the
        // controller until the version plays (a quality change) or fails.
        cancelBufferingRestore()
        lastVersionPick = bufferingPicks.sent(
            matches = { it.fileId == fileId },
            outstanding = { versionSwitchJob?.isActive == true || _uiState.value.isLoading },
        )
        restartSessionInPlace(fileId, pinVersion = true)
    }

    /**
     * Restart the session on [fileId] at the current position, keeping the
     * current session mounted and playable until the replacement is ready
     * (lifecycle adoption replaces A only after B is ready, including when B
     * fails). Shared by the in-player version switch and by settings whose
     * effect is decided in the server's plan rather than locally.
     *
     * A manual audio choice is translated by identity onto a different file;
     * automatic choices are re-resolved from that file's persisted/language
     * chain. Raw ordinals never cross a file boundary.
     *
     * [pinVersion] pins [fileId] for the new session: the viewer's version
     * pick does, and a settings restart keeps the playing session's pin.
     */
    private fun restartSessionInPlace(fileId: Int?, pinVersion: Boolean) {
        // Version and Dolby Vision restarts would choose playback locally.
        if (roomId != null) return
        val state = _uiState.value
        val currentFileId = state.selectedFileId ?: state.mediaFileId
        val sourceVersion = state.fileVersions.firstOrNull { it.fileId == currentFileId }
        val targetVersion = state.fileVersions.firstOrNull { it.fileId == fileId }
        val currentDesired = desiredAudio?.takeIf { it.fileId == currentFileId }
        val audioTrackIndexOverride = when {
            fileId == null -> null
            fileId == currentFileId -> currentDesired?.catalogOrdinal
            currentDesired?.explicit == true -> resolveAudioSelectionAcrossVersions(
                sourceTracks = sourceVersion?.audioTracks.orEmpty(),
                selectedSourceOrdinal = currentDesired.catalogOrdinal,
                targetTracks = targetVersion?.audioTracks.orEmpty(),
            )
            else -> null
        }
        episodeSelectionHandoffSlot.invalidate()
        resetSeekRecoveryForContentChange()
        transportMountGate.beginLoad()
        val resumeAt = state.position.takeIf { it > 0.0 }
        versionSwitchJob?.cancel()
        versionSwitchJob = viewModelScope.launch {
            coroutineContext.ensureActive()
            loadContent(
                startPositionOverride = resumeAt,
                preferredFileIdOverride = fileId,
                versionChosen = fileId != null && pinVersion,
                audioTrackIndexOverride = audioTrackIndexOverride,
                audioTrackIndexOverrideSpecified = fileId != null,
                suppressResumeRewind = true,
                preserveCurrentPlaybackOnFailure = true,
            )
        }
    }

    /** Reload the current content from the last known position (error-screen retry). */
    /**
     * Retry after a "Can't reach server": issue one fresh health probe, then
     * reload. A recovered server flips the monitor to Reachable so the reload
     * passes the gate; while still offline the probe fails fast.
     */
    fun retryServerReachability() {
        viewModelScope.launch {
            runCatching { serverReachabilityMonitor.retryNow() }
            loadContent()
        }
    }

    /** "Try Anyway" escape hatch: reload bypassing the reachability gate. */
    fun playIgnoringServerReachability() {
        loadContent(force = true)
    }

    fun retry() {
        resetSeekRecoveryForContentChange()
        transportMountGate.beginLoad()
        val resumeAt = _uiState.value.position.takeIf { it > 0.0 }
        val staleSessionId = _uiState.value.sessionId
        // Share the version-switch single-flight guard: retry also restarts the
        // session, so a retry and a version pick must not run competing pipelines.
        versionSwitchJob?.cancel()
        versionSwitchJob = viewModelScope.launch {
            // Stop the previous server session first so a retry can't orphan it
            // until timeout (loadContent's adoptActiveSession replaces local
            // reporter state but does not stop the old server session).
            if (staleSessionId != null) {
                runCatching { playbackSessionManager.stopSession(staleSessionId) }
            }
            // Same stale-coroutine guard as onSelectFileVersion: safeApiCall
            // eats the cancellation, so check the flag before loading.
            coroutineContext.ensureActive()
            // Retry resumes exactly where it failed — no skip-back nudge.
            loadContent(startPositionOverride = resumeAt, suppressResumeRewind = true)
        }
    }

    override fun onCleared() {
        episodeSelectionHandoffSlot.invalidate()
        val subtitlePersistenceReservation =
            subtitleTransactions.reserveDurableFinalPersistence()
        subtitleTransactions.invalidateAndSettleAsync(restoreUi = false) {
            subtitlePersistenceReservation?.let(
                subtitleTransactions::requestDurableFinalPersistence,
            )
            playbackMutationFence.invalidateAll()
            // Read AFTER settlement, not snapshotted before it. Settlement can
            // roll a subtitle publication back, and that rollback returns
            // ownership to the predecessor — so a value captured before this
            // callback names the discarded replacement, and the predecessor is
            // left running with the one-shot gate already consumed.
            //
            // Never unqualified either. A null expectedSessionId disables the
            // lifecycle's ownership guard entirely, and this callback is
            // deliberately delayed behind subtitle settlement — long enough for
            // a newer screen to have adopted its own session. A screen that
            // never owned one has nothing to tear down.
            exitSessionId?.let { lifecycleTeardown.stopDetached(expectedSessionId = it) }
        }
        subtitleSnapshotSettlement.reset()
        org.siloserver.silo.common.player.debug.PlaybackDebugState.screenError = null
        org.siloserver.silo.common.player.ActivePlaybackFile.clear(
            _uiState.value.selectedFileId ?: _uiState.value.mediaFileId,
        )
        super.onCleared()
        // The application-owned writer survives ViewModel cancellation and
        // preserves the final local resume point without blocking main.
        val cid = contentId.takeIf { it.isNotBlank() }
        val fid = _uiState.value.selectedFileId ?: _uiState.value.mediaFileId
        val scope = finalPositionScope
        if (scope != null && cid != null && fid != null) {
            finalPlaybackPositionWriter.submit(
                FinalPlaybackPosition(
                    scope = scope,
                    contentId = cid,
                    fileId = fid,
                    positionSeconds = _uiState.value.position,
                    durationSeconds = _uiState.value.duration.takeIf { it > 0.0 },
                    serverTrackedAtMs = System.currentTimeMillis()
                        .takeIf { exitSessionId?.let(playbackSessionManager::isSequenced) == true },
                ),
            )
        }
        introObserveJob?.cancel()
        lifecycleObserveJob?.cancel()
        nextUpCountdownJob?.cancel()
        introAutoSkipController.reset()
        resetBufferingQuality()
    }

}

internal data class TvPlaybackExitSnapshot(
    val positionSeconds: Double,
    val durationSeconds: Double,
)

internal fun resolveTvPlaybackExitSnapshot(
    currentPositionSeconds: Double,
    currentDurationSeconds: Double,
    positionMs: Long?,
    durationMs: Long?,
    timeline: PlaybackTimeline?,
    serverDurationSeconds: Double,
    allowPlayerDuration: Boolean = true,
): TvPlaybackExitSnapshot {
    if (positionMs == null || durationMs == null || positionMs < 0L) {
        return TvPlaybackExitSnapshot(currentPositionSeconds, currentDurationSeconds)
    }

    val serverDuration = serverDurationSeconds.takeIf { it.isFinite() && it > 0.0 }
    val playerPositionSeconds = positionMs / 1_000.0
    val sourcePositionSeconds = (
        timeline?.sourcePositionForPlayer(playerPositionSeconds) ?: playerPositionSeconds
        ).let { position -> serverDuration?.let(position::coerceAtMost) ?: position }
    val sourceDurationSeconds = if (!allowPlayerDuration) {
        serverDuration ?: 0.0
    } else if (durationMs > 0L) {
        val playerDurationSeconds = durationMs / 1_000.0
        timeline?.sourcePositionForPlayer(playerDurationSeconds) ?: playerDurationSeconds
    } else {
        currentDurationSeconds
    }.let { duration -> serverDuration?.let(duration::coerceAtMost) ?: duration }

    return TvPlaybackExitSnapshot(
        positionSeconds = sourcePositionSeconds.coerceAtLeast(0.0),
        durationSeconds = if (allowPlayerDuration) {
            maxOf(currentDurationSeconds, sourceDurationSeconds)
        } else {
            sourceDurationSeconds
        },
    )
}

data class PlaybackClock(
    val position: Double,
    val duration: Double,
)

internal fun TvPlayerViewModel.UiState.withoutPlaybackClock(): TvPlayerViewModel.UiState =
    copy(position = 0.0, duration = 0.0)

internal fun TvPlayerViewModel.UiState.toPlaybackClock(): PlaybackClock =
    PlaybackClock(position = position, duration = duration)
