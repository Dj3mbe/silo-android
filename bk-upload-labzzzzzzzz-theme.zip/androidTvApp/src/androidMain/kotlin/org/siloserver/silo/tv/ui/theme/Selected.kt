package org.siloserver.silo.tv.ui.theme

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb

/**
 * The fill and outline that mark the current choice: the open top-bar tab, the
 * chosen season, the highlighted row in a menu.
 *
 * It is chosen independently of the focus accent, from the same colour list.
 * By default it follows the accent ([MatchId]).
 *
 * Read it through [SelectedFill], [SelectedStroke] and [SelectedContent]. It is
 * backed by Compose state, so changing the choice recolours the open screen at
 * once.
 */
object TvSelected {
    /** [selectedId] while the colour follows the accent. */
    const val MatchId = "match"

    /** [selectedId] when the viewer chose their own colour. */
    const val CustomId = "custom"

    private const val PrefsName = "tv_appearance"
    private const val KeySelectedId = "selected_id"
    private const val KeyCustomColor = "selected_custom_argb"

    /** Text on a light fill is this dark tone instead of white. */
    private val DarkContent = Color(0xFF111318)

    private var prefs: SharedPreferences? = null

    /** [MatchId], [CustomId], or the id of an [AccentPreset]. */
    var selectedId by mutableStateOf(MatchId)
        private set

    /** The viewer's own colour; used when [selectedId] is [CustomId]. */
    var customColor by mutableStateOf(Color(0xFF4F7CE0))
        private set

    /** The chosen colour, exactly as picked. */
    val fill: Color
        get() = when (selectedId) {
            MatchId -> TvAccent.color
            CustomId -> customColor
            else -> AccentPreset.fromId(selectedId)?.color ?: TvAccent.color
        }

    /** The outline: the fill, lightened so it reads against the dark background. */
    val stroke: Color
        get() = lerp(fill, Color.White, 0.55f)

    /** Text and icons that sit on [fill]: dark on light colours, white on dark ones. */
    val content: Color
        get() = if (fill.luminance() > 0.40f) DarkContent else Color.White

    val label: String
        get() = when (selectedId) {
            MatchId -> "Same as accent"
            CustomId -> "Custom"
            else -> AccentPreset.fromId(selectedId)?.label ?: "Same as accent"
        }

    /** Loads the saved choice. Call once from [android.app.Application.onCreate]. */
    fun init(context: Context) {
        val stored = context.getSharedPreferences(PrefsName, Context.MODE_PRIVATE)
        prefs = stored
        if (stored.contains(KeyCustomColor)) {
            customColor = Color(stored.getInt(KeyCustomColor, customColor.toArgb()))
        }
        val savedId = stored.getString(KeySelectedId, null)
        if (savedId == MatchId || savedId == CustomId || AccentPreset.fromId(savedId) != null) {
            selectedId = savedId!!
        }
    }

    fun matchAccent() {
        selectedId = MatchId
        prefs?.edit()?.putString(KeySelectedId, MatchId)?.apply()
    }

    fun select(preset: AccentPreset) {
        selectedId = preset.id
        prefs?.edit()?.putString(KeySelectedId, preset.id)?.apply()
    }

    fun selectCustom(color: Color) {
        customColor = color
        selectedId = CustomId
        prefs?.edit()
            ?.putString(KeySelectedId, CustomId)
            ?.putInt(KeyCustomColor, color.toArgb())
            ?.apply()
    }
}
